<template>
    <AppLayout title="Manajemen Isolir">
        <!-- Header & Stats -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card class="flex items-center p-4">
                <div class="p-4 rounded-lg bg-red-50 text-red-600 mr-4">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                </div>
                <div>
                    <div class="text-3xl font-bold text-slate-800 dark:text-white">{{ stats.total_isolated }}</div>
                    <div class="text-sm font-medium text-slate-500 dark:text-slate-400">Pelanggan Diisolir</div>
                </div>
            </Card>

            <Card class="flex items-center p-4">
                <div class="p-4 rounded-lg bg-emerald-50 text-emerald-600 mr-4">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div>
                    <div class="text-3xl font-bold text-slate-800 dark:text-white">{{ stats.total_active }}</div>
                    <div class="text-sm font-medium text-slate-500 dark:text-slate-400">Pelanggan Aktif</div>
                </div>
            </Card>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Manual Isolir -->
            <div class="lg:col-span-1">
                <Card title="Isolir Manual">
                    <p class="text-sm text-slate-500 mb-4">Pilih pelanggan aktif untuk diisolir secara manual.</p>
                    <form @submit.prevent="submitIsolate">
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Pelanggan Aktif</label>
                            <select v-model="form.customer_id" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Pilih Pelanggan --</option>
                                <option v-for="c in candidates" :key="c.id" :value="c.id">
                                    {{ c.name }} ({{ c.package?.name || '-' }})
                                </option>
                            </select>
                        </div>
                        <Button type="submit" variant="danger" class="w-full" :disabled="!form.customer_id || form.processing">
                            🔒 Isolir Sekarang
                        </Button>
                    </form>
                </Card>
            </div>

            <!-- List Isolir -->
            <div class="lg:col-span-2">
                <Card title="Daftar Pelanggan Diisolir" bodyClass="!p-0">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                            <thead class="bg-slate-50 dark:bg-slate-800">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama & Kontak</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Paket</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Diisolir Sejak</th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                <tr v-for="c in isolated.data" :key="c.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="font-medium text-slate-900 dark:text-white">{{ c.name }}</div>
                                        <div class="text-sm text-slate-500">{{ c.phone || '-' }}</div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                                        {{ c.package?.name || '-' }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                                        {{ formatDate(c.isolated_since) }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <button @click="release(c)" class="inline-flex items-center px-3 py-1 bg-emerald-100 text-emerald-700 hover:bg-emerald-200 rounded-md text-xs font-semibold transition-colors">
                                            🔓 Lepas Isolir
                                        </button>
                                    </td>
                                </tr>
                                <tr v-if="isolated.data.length === 0">
                                    <td colspan="4" class="px-6 py-8 text-center text-slate-500">
                                        Tidak ada pelanggan yang sedang diisolir.
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50" v-if="isolated.links.length > 3">
                        <div class="flex flex-wrap gap-1">
                            <template v-for="(link, p) in isolated.links" :key="p">
                                <Link v-if="link.url" :href="link.url" :class="['px-3 py-1 rounded border text-sm', link.active ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600']" v-html="link.label"></Link>
                                <span v-else class="px-3 py-1 rounded border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 text-slate-400 text-sm cursor-not-allowed" v-html="link.label"></span>
                            </template>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    </AppLayout>
</template>

<script setup>
import { useForm, router, Link } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';

const props = defineProps({
    isolated: Object,
    candidates: Array,
    stats: Object,
    capabilities: Object,
});

const form = useForm({
    customer_id: '',
});

const submitIsolate = () => {
    if (!form.customer_id) return;
    form.post(route('isolir.isolate', form.customer_id), {
        preserveScroll: true,
        onSuccess: () => form.reset(),
    });
};

const release = (customer) => {
    if (confirm(`Apakah Anda yakin ingin melepas isolir untuk pelanggan ${customer.name}?`)) {
        router.post(route('isolir.release', customer.id), {}, { preserveScroll: true });
    }
};

const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('id-ID', {
        day: 'numeric', month: 'short', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });
};
</script>
