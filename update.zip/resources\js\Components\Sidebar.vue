<template>
    <aside class="sidebar" :class="{ 'open': isOpen }" id="sidebar">
        <div class="sidebar-brand">
            <div class="brand-icon">
                <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
            </div>
            <div>
                <div class="brand-text">LadaPala-Bill</div>
                <div class="brand-version">v2.0 &mdash; {{ $page.props.tenant?.name ?? 'ISP' }}</div>
            </div>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Utama</div>
                <Link :href="route('dashboard')" class="nav-item" :class="{ 'active': route().current('dashboard') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                    Dashboard
                </Link>

                <Link v-if="isAdmin || role?.can_view_all_customers" :href="route('customers.index')" class="nav-item" :class="{ 'active': route().current('customers.*') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    Pelanggan
                </Link>

                <Link v-if="isAdmin || role?.can_manage_cuti" :href="route('cuti.index')" class="nav-item" :class="{ 'active': route().current('cuti.*') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
                    Pelanggan Cuti
                </Link>

                <Link v-if="isAdmin || role?.can_manage_isolir" :href="route('isolir.index')" class="nav-item" :class="{ 'active': route().current('isolir.*') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                    Isolir
                </Link>
            </div>

            <div class="nav-section" v-if="isAdmin || role?.can_view_reports || role?.can_view_finance">
                <div class="nav-section-title">Laporan</div>
                
                <Link v-if="isAdmin || role?.can_view_reports" :href="route('reports.detail-pendapatan')" class="nav-item" :class="{ 'active': route().current('reports.detail-pendapatan') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    Detail Pendapatan
                </Link>

                <template v-if="isAdmin || role?.can_view_finance">
                    <Link :href="route('expenses.index')" class="nav-item" :class="{ 'active': route().current('expenses.*') }">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        Pengeluaran Operasional
                    </Link>
                    <Link :href="route('reports.ppn')" class="nav-item" :class="{ 'active': route().current('reports.ppn') }">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                        PPN
                    </Link>
                    <Link :href="route('reports.total')" class="nav-item" :class="{ 'active': route().current('reports.total') }">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
                        Total/Rekapitulasi
                    </Link>
                    <Link :href="route('statistics.index')" class="nav-item" :class="{ 'active': route().current('statistics.*') }">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                        Statistik Bisnis
                    </Link>
                    <Link :href="route('reports.cashflow')" class="nav-item" :class="{ 'active': route().current('reports.cashflow') }">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                        Arus Kas
                    </Link>
                </template>
            </div>

            <div class="nav-section" v-if="isAdmin || role?.can_view_finance || role?.can_manage_deposits">
                <div class="nav-section-title">Laporan Sales</div>
                
                <Link v-if="isAdmin || role?.can_view_finance" :href="route('fee_withdrawals.index')" class="nav-item" :class="{ 'active': route().current('fee_withdrawals.*') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M15 9.5a3 3 0 0 0-6 0c0 2 6 3 6 6a3 3 0 0 1-6 0"/></svg>
                    Fee & Pencairan
                </Link>
                <Link v-if="isAdmin || role?.can_manage_deposits" :href="route('reports.setoran')" class="nav-item" :class="{ 'active': route().current('reports.setoran') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 7V5a4 4 0 0 0-8 0v2"/></svg>
                    Setoran
                </Link>
                <Link v-if="isAdmin || role?.can_view_finance" :href="route('reports.mitra')" class="nav-item" :class="{ 'active': route().current('reports.mitra') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    Mitra
                </Link>
            </div>

            <div class="nav-section" v-if="isAdmin || role?.can_manage_packages || role?.can_manage_areas || role?.can_manage_odp">
                <div class="nav-section-title">Master</div>
                
                <Link v-if="isAdmin || role?.can_manage_packages" :href="route('settings.packages')" class="nav-item" :class="{ 'active': route().current('settings.packages*') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 7V5a4 4 0 0 0-8 0v2"/></svg>
                    Master Paket
                </Link>
                <Link v-if="isAdmin || role?.can_manage_areas" :href="route('settings.areas')" class="nav-item" :class="{ 'active': route().current('settings.areas*') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    Master Area
                </Link>
                <Link v-if="isAdmin || role?.can_manage_odp" :href="route('settings.odps')" class="nav-item" :class="{ 'active': route().current('settings.odps*') }">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="3"/><line x1="12" y1="8" x2="12" y2="16"/><circle cx="6" cy="19" r="3"/><circle cx="18" cy="19" r="3"/><line x1="12" y1="16" x2="6" y2="16"/><line x1="12" y1="16" x2="18" y2="16"/></svg>
                    Master ODP
                </Link>
            </div>
        </nav>

        <div class="sidebar-footer">
            <a href="/app-gateway" style="display:flex;align-items:center;gap:8px;padding:8px 16px;margin-bottom:8px;font-size:13px;color:var(--text-sidebar);text-decoration:none;border-radius:8px;transition:all .2s;border:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.03);" onmouseover="this.style.background='rgba(255,255,255,.08)'" onmouseout="this.style.background='rgba(255,255,255,.03)'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Pilih Modul
            </a>
            <div class="user-card">
                <div class="user-avatar">{{ userInitial }}</div>
                <div class="user-info">
                    <div class="user-name">{{ user?.name }}</div>
                    <div class="user-role">{{ role?.name ?? 'User' }}</div>
                </div>
            </div>
        </div>
    </aside>
</template>

<script setup>
import { computed } from 'vue';
import { usePage, Link } from '@inertiajs/vue3';

defineProps({
    isOpen: {
        type: Boolean,
        default: false
    }
});

const page = usePage();
const user = computed(() => page.props.auth.user);
const role = computed(() => page.props.auth.role);
const isAdmin = computed(() => page.props.auth.isAdmin);
const userInitial = computed(() => user.value?.name ? user.value.name.substring(0, 1).toUpperCase() : 'U');
</script>
