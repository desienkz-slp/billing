<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Payment;
use App\Models\Area;
use App\Models\Package;
use App\Services\PermissionService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;
use Inertia\Response;

class DashboardController extends Controller
{
    public function __construct(
        private PermissionService $permissionService
    ) {}

    public function index(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;

        // Real stats
        $stats = [
            'total_customers' => Customer::count(),
            'active_customers' => Customer::where('status', 'active')->where('is_isolated', false)->count(),
            'isolated' => Customer::where('is_isolated', true)->count(),
            'new_this_month' => Customer::whereMonth('registration_date', now()->month)
                ->whereYear('registration_date', now()->year)->count(),
        ];

        // Revenue this month
        $currentMonth = Payment::where('status', 'paid')
            ->whereMonth('payment_date', now()->month)
            ->whereYear('payment_date', now()->year);
        $stats['revenue_this_month'] = $currentMonth->sum('paid_amount');
        $stats['payments_this_month'] = $currentMonth->count();

        // Revenue last month for comparison
        $lastMonth = Payment::where('status', 'paid')
            ->whereMonth('payment_date', now()->subMonth()->month)
            ->whereYear('payment_date', now()->subMonth()->year);
        $stats['revenue_last_month'] = $lastMonth->sum('paid_amount');

        // Revenue trend (6 months)
        $revenueTrend = Payment::where('status', 'paid')
            ->where('payment_date', '>=', now()->subMonths(6)->startOfMonth())
            ->selectRaw("to_char(payment_date, 'YYYY-MM') as period, SUM(paid_amount) as total")
            ->groupByRaw("to_char(payment_date, 'YYYY-MM')")
            ->orderBy('period')
            ->pluck('total', 'period');

        // Payment method breakdown
        $methodBreakdown = Payment::where('status', 'paid')
            ->whereMonth('payment_date', now()->month)
            ->whereYear('payment_date', now()->year)
            ->selectRaw('payment_method, COUNT(*) as count, SUM(paid_amount) as total')
            ->groupBy('payment_method')
            ->get();

        // Recent payments
        $recentPayments = Payment::with('customer')
            ->where('status', 'paid')
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();

        // Customers Data for Table
        $query = Customer::with(['package', 'area']);

        if ($search = $request->get('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'ilike', "%{$search}%")
                  ->orWhere('username', 'ilike', "%{$search}%")
                  ->orWhere('phone', 'ilike', "%{$search}%")
                  ->orWhere('address', 'ilike', "%{$search}%");
            });
        }
        if ($areaId = $request->get('area_id')) $query->where('area_id', $areaId);
        if ($packageId = $request->get('package_id')) $query->where('package_id', $packageId);
        if ($request->filled('status')) $query->where('status', $request->get('status'));
        if ($request->filled('is_isolated')) $query->where('is_isolated', $request->boolean('is_isolated'));

        $sortBy = $request->get('sort', 'name');
        $sortDir = $request->get('dir', 'asc');
        $query->orderBy($sortBy, $sortDir);

        $customers = $query->paginate(25)->withQueryString();
        $areas = Area::orderBy('name')->get();
        $packages = Package::orderBy('name')->get();

        return Inertia::render('Dashboard', compact(
            'capabilities', 'stats',
            'revenueTrend', 'methodBreakdown', 'recentPayments',
            'customers', 'areas', 'packages'
        ));
    }
}
