@php
    $user = $user ?? auth()->user()?->load('role', 'tenant');
    $tenant = $tenant ?? ($user->tenant ?? null);
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="color-scheme" content="dark">
    <title>{{ $tenant->name ?? 'Config' }} · Config</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0b1120;
            --bg-card: rgba(15,23,42,.7);
            --bg-sidebar: rgba(15,23,42,.95);
            --border: rgba(255,255,255,.08);
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --accent: #0ea5e9;
            --accent-glow: rgba(14,165,233,.15);
            --success: #22c55e;
            --danger: #ef4444;
            --warning: #f59e0b;
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Inter',system-ui,sans-serif;background:var(--bg-primary);color:var(--text-primary);min-height:100vh;display:flex;overflow:hidden}

        /* Sidebar */
        .cfg-sidebar{width:260px;background:var(--bg-sidebar);border-right:1px solid var(--border);display:flex;flex-direction:column;height:100vh;position:fixed;z-index:50;transition:transform .3s}
        .cfg-sidebar-header{padding:20px;border-bottom:1px solid var(--border)}
        .cfg-sidebar-header h2{font-size:1rem;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px}
        .cfg-sidebar-header h2 span{background:linear-gradient(135deg,#f59e0b,#f97316);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-size:1.1rem}
        .cfg-sidebar-header p{font-size:.75rem;color:var(--text-muted);margin-top:4px}
        .cfg-nav{flex:1;overflow-y:auto;padding:12px}
        .cfg-nav-section{font-size:.65rem;text-transform:uppercase;letter-spacing:.08em;color:var(--text-muted);padding:12px 12px 6px;font-weight:600}
        .cfg-nav-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:8px;color:var(--text-secondary);text-decoration:none;font-size:.85rem;font-weight:500;transition:all .2s;margin-bottom:2px}
        .cfg-nav-item:hover{background:rgba(255,255,255,.06);color:var(--text-primary)}
        .cfg-nav-item.active{background:var(--accent-glow);color:var(--accent);border:1px solid rgba(14,165,233,.2)}
        .cfg-nav-item svg{width:18px;height:18px;flex-shrink:0}
        .cfg-nav-sep{height:1px;background:var(--border);margin:8px 12px}
        .cfg-sidebar-footer{padding:16px;border-top:1px solid var(--border)}
        .cfg-sidebar-footer .user-info{display:flex;align-items:center;gap:10px;font-size:.8rem;color:var(--text-secondary)}
        .cfg-sidebar-footer .user-avatar{width:32px;height:32px;border-radius:8px;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff}

        /* Main */
        .cfg-main{flex:1;margin-left:260px;height:100vh;overflow-y:auto;padding:0}
        .cfg-header{position:sticky;top:0;z-index:10;background:rgba(11,17,32,.85);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);padding:16px 28px;display:flex;align-items:center;justify-content:space-between}
        .cfg-header h1{font-size:1.1rem;font-weight:700;display:flex;align-items:center;gap:8px}
        .cfg-content{padding:24px 28px}

        /* Cards */
        .cfg-card{background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px;backdrop-filter:blur(8px)}
        .cfg-card-title{font-size:.9rem;font-weight:700;color:#fff;margin-bottom:12px;display:flex;align-items:center;gap:8px}
        .cfg-label{font-size:.78rem;color:var(--text-secondary);margin-bottom:4px;font-weight:500}
        .cfg-input{width:100%;padding:8px 12px;background:rgba(0,0,0,.3);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);font-size:.85rem;font-family:inherit;outline:none;transition:border-color .2s}
        .cfg-input:focus{border-color:var(--accent)}
        select.cfg-input{cursor:pointer}
        textarea.cfg-input{resize:vertical}

        /* Buttons */
        .cfg-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:8px;border:none;font-size:.82rem;font-weight:600;cursor:pointer;transition:all .2s;font-family:inherit}
        .cfg-btn-primary{background:linear-gradient(135deg,#0ea5e9,#6366f1);color:#fff}
        .cfg-btn-primary:hover{opacity:.9;transform:translateY(-1px)}
        .cfg-btn-danger{background:rgba(239,68,68,.15);color:#f87171;border:1px solid rgba(239,68,68,.3)}
        .cfg-btn-danger:hover{background:rgba(239,68,68,.25)}
        .cfg-btn-secondary{background:rgba(255,255,255,.06);color:var(--text-secondary);border:1px solid var(--border)}
        .cfg-btn-secondary:hover{background:rgba(255,255,255,.1)}

        /* Table */
        .cfg-table{width:100%;border-collapse:collapse;font-size:.82rem}
        .cfg-table th{text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid var(--border)}
        .cfg-table td{padding:10px 12px;border-bottom:1px solid rgba(255,255,255,.04);color:var(--text-secondary)}
        .cfg-table tr:hover td{background:rgba(255,255,255,.02)}
        .cfg-table code{font-size:.78rem;color:var(--accent);background:rgba(14,165,233,.1);padding:2px 6px;border-radius:4px}

        /* Alerts */
        .cfg-alert{padding:10px 14px;border-radius:8px;font-size:.82rem;margin-bottom:12px;display:none}
        .cfg-alert.ok{display:block;background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
        .cfg-alert.err{display:block;background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2)}

        /* Grid */
        .cfg-grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
        @media(max-width:800px){.cfg-grid-2{grid-template-columns:1fr}}

        /* Checkbox */
        .cfg-check{display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;margin-bottom:4px}
        .cfg-check input[type=checkbox]{accent-color:var(--accent)}

        /* Mobile */
        .cfg-hamburger{display:none;position:fixed;top:12px;left:12px;z-index:60;background:rgba(15,23,42,.9);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);padding:8px;cursor:pointer;font-size:1.2rem}
        .cfg-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:40}
        @media(max-width:768px){
            .cfg-sidebar{transform:translateX(-100%)}
            .cfg-sidebar.open{transform:translateX(0)}
            .cfg-main{margin-left:0}
            .cfg-hamburger{display:block}
            .cfg-overlay.show{display:block}
            .cfg-content{padding:16px}
        }

        /* Modal */
        .cfg-modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:999;align-items:center;justify-content:center}
        .cfg-modal-overlay.show{display:flex}
        .cfg-modal{background:#0d1117;border:1px solid var(--border);border-radius:16px;padding:24px;width:100%;max-width:480px;max-height:90vh;overflow-y:auto}
        .cfg-modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
        .cfg-modal-header h3{font-size:1rem;font-weight:700;color:#fff}
        .cfg-modal-close{background:none;border:none;color:var(--text-muted);font-size:1.2rem;cursor:pointer}
    </style>
    @stack('styles')
</head>
<body>
    <button class="cfg-hamburger" onclick="document.querySelector('.cfg-sidebar').classList.toggle('open');document.querySelector('.cfg-overlay').classList.toggle('show')">☰</button>
    <div class="cfg-overlay" onclick="document.querySelector('.cfg-sidebar').classList.remove('open');this.classList.remove('show')"></div>

    <aside class="cfg-sidebar">
        <div class="cfg-sidebar-header">
            <h2><span>⚙</span> {{ $tenant->name ?? 'Config' }}</h2>
            <p>Konfigurasi Sistem</p>
        </div>
        <nav class="cfg-nav">
            <div class="cfg-nav-section">Pengguna</div>
            <a href="{{ route('config.users') }}" class="cfg-nav-item {{ request()->routeIs('config.users*') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                Kelola User
            </a>
            <a href="{{ route('config.roles') }}" class="cfg-nav-item {{ request()->routeIs('config.roles*') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                Role & Permission
            </a>

            <div class="cfg-nav-section">Pengaturan</div>
            <a href="{{ route('config.setting-nota') }}" class="cfg-nav-item {{ request()->routeIs('config.setting-nota') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                Setting Nota
            </a>
            <a href="{{ route('config.wa-gateway') }}" class="cfg-nav-item {{ request()->routeIs('config.wa-gateway') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
                WA Gateway
            </a>
            <a href="{{ route('config.router') }}" class="cfg-nav-item {{ request()->routeIs('config.router') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="14" width="20" height="6" rx="2"/><line x1="6" y1="17" x2="6" y2="17"/><line x1="10" y1="17" x2="10" y2="17"/><path d="M6 14V8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v6"/></svg>
                Config Router
            </a>
            <a href="{{ route('config.server') }}" class="cfg-nav-item {{ request()->routeIs('config.server') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><circle cx="6" cy="6" r="1"/><circle cx="6" cy="18" r="1"/></svg>
                Server Geniacs
            </a>
            <a href="{{ route('config.radius-server') }}" class="cfg-nav-item {{ request()->routeIs('config.radius-server') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/></svg>
                Server RADIUS
            </a>
            <a href="{{ route('config.db-pusat') }}" class="cfg-nav-item {{ request()->routeIs('config.db-pusat') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>
                DB Pusat
            </a>

            <div class="cfg-nav-section">Sistem</div>
            <a href="{{ route('config.backup') }}" class="cfg-nav-item {{ request()->routeIs('config.backup') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Backup & Restore
            </a>
            <a href="{{ route('config.log-sistem') }}" class="cfg-nav-item {{ request()->routeIs('config.log-sistem') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                Log Sistem
            </a>

            <div class="cfg-nav-sep"></div>
            <a href="{{ route('app-gateway') }}" class="cfg-nav-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
                Kembali
            </a>
        </nav>
        <div class="cfg-sidebar-footer">
            <div class="user-info">
                <div class="user-avatar">{{ strtoupper(substr($user->name ?? 'U', 0, 1)) }}</div>
                <div>
                    <div style="font-weight:600;color:var(--text-primary)">{{ $user->name }}</div>
                    <div style="font-size:.7rem">{{ $user->role->name ?? 'User' }}</div>
                </div>
            </div>
        </div>
    </aside>

    <div class="cfg-main">
        <header class="cfg-header">
            <h1>@yield('page-title', 'Config')</h1>
            <div style="font-size:.8rem;color:var(--text-muted)">{{ $tenant->name ?? '' }}</div>
        </header>
        <div class="cfg-content">
            @yield('content')
        </div>
    </div>

    @stack('scripts')
</body>
</html>
