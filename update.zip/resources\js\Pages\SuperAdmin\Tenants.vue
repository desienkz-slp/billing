<template>
    <AppLayout title="Kelola Tenant (SuperAdmin)">
        <!-- Stats -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card class="text-center p-6">
                <div class="text-3xl font-bold text-indigo-600">{{ tenants.length }}</div>
                <div class="text-sm text-slate-500 mt-1">Total Tenant</div>
            </Card>
            <Card class="text-center p-6">
                <div class="text-3xl font-bold text-emerald-600">{{ tenants.filter(t => t.is_active).length }}</div>
                <div class="text-sm text-slate-500 mt-1">Tenant Aktif</div>
            </Card>
            <Card class="text-center p-6">
                <div class="text-3xl font-bold text-amber-600">{{ tenants.reduce((sum, t) => sum + t.users_count, 0) }}</div>
                <div class="text-sm text-slate-500 mt-1">Total User</div>
            </Card>
            <Card class="text-center p-6">
                <div class="text-3xl font-bold text-purple-600">{{ tenants.reduce((sum, t) => sum + t.customers_count, 0) }}</div>
                <div class="text-sm text-slate-500 mt-1">Total Pelanggan</div>
            </Card>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Form Tambah Tenant -->
            <div class="lg:col-span-1">
                <Card title="➕ Tambah Tenant Baru">
                    <form @submit.prevent="submit" class="space-y-4">
                        <div class="border-b border-slate-200 dark:border-slate-700 pb-4">
                            <h4 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Info Tenant</h4>
                            <Input label="Nama ISP *" v-model="form.name" required placeholder="LadaPala Net Kediri" class="mb-3" :error="form.errors.name" />
                            <Input label="Slug (URL)" v-model="form.slug" placeholder="otomatis" class="mb-3" :error="form.errors.slug" />
                            <Input label="Custom Domain" v-model="form.domain" placeholder="billing.ladapala.com" class="mb-3" :error="form.errors.domain" />
                            
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Timezone</label>
                            <select v-model="form.timezone" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="Asia/Jakarta">WIB (Asia/Jakarta)</option>
                                <option value="Asia/Makassar">WITA (Asia/Makassar)</option>
                                <option value="Asia/Jayapura">WIT (Asia/Jayapura)</option>
                            </select>
                            <p v-if="form.errors.timezone" class="mt-1 text-sm text-red-600">{{ form.errors.timezone }}</p>
                        </div>

                        <div class="border-b border-slate-200 dark:border-slate-700 pb-4">
                            <h4 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Profil Perusahaan</h4>
                            <Input label="Nama Perusahaan" v-model="form.company_name" placeholder="Sama dengan nama ISP jika kosong" class="mb-3" />
                            <Input label="Alamat" v-model="form.company_address" class="mb-3" />
                            <Input label="Telepon" v-model="form.company_phone" />
                        </div>

                        <div class="pb-2">
                            <h4 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">User Admin Pertama</h4>
                            <Input label="Nama Lengkap *" v-model="form.admin_name" required class="mb-3" :error="form.errors.admin_name" />
                            <Input label="Username *" v-model="form.admin_username" required class="mb-3" :error="form.errors.admin_username" />
                            <Input label="Password *" type="password" v-model="form.admin_password" required minlength="6" class="mb-3" :error="form.errors.admin_password" />
                        </div>

                        <Button type="submit" class="w-full" :disabled="form.processing">
                            🏢 Buat Tenant + User Admin
                        </Button>
                    </form>
                </Card>
            </div>

            <!-- Daftar Tenant -->
            <div class="lg:col-span-2">
                <Card :title="`📋 Daftar Tenant (${tenants.length})`" bodyClass="!p-0">
                    <div class="overflow-x-auto max-h-[70vh]">
                        <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                            <thead class="bg-slate-50 dark:bg-slate-800 sticky top-0 z-10">
                                <tr>
                                    <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">#</th>
                                    <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tenant</th>
                                    <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Slug</th>
                                    <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                                    <th scope="col" class="px-4 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Users</th>
                                    <th scope="col" class="px-4 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Pelanggan</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                                <tr v-for="(t, i) in tenants" :key="t.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                    <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{{ i + 1 }}</td>
                                    <td class="px-4 py-3 whitespace-nowrap">
                                        <div class="font-medium text-slate-900 dark:text-white">{{ t.name }}</div>
                                        <div v-if="t.domain" class="text-xs text-slate-500">{{ t.domain }}</div>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-500">
                                        <code class="bg-slate-100 dark:bg-slate-900 px-2 py-1 rounded text-xs">{{ t.slug }}</code>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap">
                                        <span v-if="t.is_active" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-emerald-100 text-emerald-800">Aktif</span>
                                        <span v-else class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Non-Aktif</span>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm text-center text-slate-500">{{ t.users_count }}</td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm text-center text-slate-500">{{ t.customers_count }}</td>
                                </tr>
                                <tr v-if="tenants.length === 0">
                                    <td colspan="6" class="px-4 py-8 text-center text-slate-500">
                                        Belum ada tenant.
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </Card>
            </div>
        </div>
    </AppLayout>
</template>

<script setup>
import { useForm } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';

defineProps({
    tenants: Array,
});

const form = useForm({
    name: '',
    slug: '',
    domain: '',
    timezone: 'Asia/Jakarta',
    company_name: '',
    company_address: '',
    company_phone: '',
    admin_name: '',
    admin_username: '',
    admin_password: '',
});

const submit = () => {
    form.post(route('superadmin.tenants.store'), {
        preserveScroll: true,
        onSuccess: () => form.reset(),
    });
};
</script>
