@extends('layouts.app')
@section('title', 'Monitoring')
@section('content')
<div style="margin-bottom:24px">
    <h2 style="font-size:1.3rem;font-weight:700;display:flex;align-items:center;gap:8px">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
        Monitoring Router
    </h2>
    <p style="color:var(--text-secondary);font-size:.85rem;margin-top:4px">Status koneksi & PPPoE management</p>
</div>

@if($routers->isEmpty())
<div style="text-align:center;padding:60px 20px;color:var(--text-muted)">
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 12px"><rect x="2" y="14" width="20" height="6" rx="2"/><path d="M6 14V8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v6"/></svg>
    <p>Belum ada router aktif.</p>
    <a href="{{ route('config.router') }}" style="color:var(--accent);font-size:.85rem">Tambah router di Config →</a>
</div>
@else
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px">
    @foreach($routers as $router)
    <div class="card" style="padding:0;overflow:hidden;border:1px solid var(--border);border-radius:var(--radius)" id="router-{{ $router->id }}">
        <div style="padding:20px">
            <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:12px">
                <div>
                    <h3 style="font-size:1rem;font-weight:700">{{ $router->name }}</h3>
                    <span style="font-size:.78rem;color:var(--text-muted)">{{ $router->host }}:{{ $router->port }}</span>
                </div>
                <span class="router-status" id="status-{{ $router->id }}" style="display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:99px;font-size:.72rem;font-weight:600;background:rgba(100,116,139,.15);color:#94a3b8">
                    <span style="width:6px;height:6px;border-radius:50%;background:currentColor"></span>
                    Cek...
                </span>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
                <div style="background:var(--accent-bg);padding:10px;border-radius:8px;text-align:center">
                    <div style="font-size:1.2rem;font-weight:700;color:var(--accent)" id="clients-{{ $router->id }}">{{ $router->customers_count }}</div>
                    <div style="font-size:.68rem;color:var(--text-muted)">Pelanggan</div>
                </div>
                <div style="background:rgba(34,197,94,.08);padding:10px;border-radius:8px;text-align:center">
                    <div style="font-size:1.2rem;font-weight:700;color:var(--success)" id="active-{{ $router->id }}">—</div>
                    <div style="font-size:.68rem;color:var(--text-muted)">Online</div>
                </div>
            </div>

            <div style="font-size:.75rem;color:var(--text-muted);margin-bottom:12px" id="resources-{{ $router->id }}">
                Loading system info...
            </div>

            <div style="display:flex;gap:8px">
                <a href="{{ route('monitoring.router.detail', $router) }}" style="flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:8px;border-radius:8px;background:var(--gradient);color:#fff;font-size:.82rem;font-weight:600;text-decoration:none;transition:opacity .2s" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                    Detail
                </a>
                <button onclick="syncRouter({{ $router->id }})" style="padding:8px 14px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.06);color:var(--text-secondary);font-size:.78rem;cursor:pointer;font-family:inherit;transition:all .2s" onmouseover="this.style.background='rgba(255,255,255,.12)'" onmouseout="this.style.background='rgba(255,255,255,.06)'">
                    🔄 Sync
                </button>
            </div>
        </div>
    </div>
    @endforeach
</div>
@endif

@push('scripts')
<script>
var routers = @json($routers->pluck('id'));
var csrfToken = '{{ csrf_token() }}';

// Check active connections for each router
routers.forEach(function(id) {
    fetch('/monitoring/router/' + id + '/active-json')
        .then(function(r) { return r.json(); })
        .then(function(res) {
            var el = document.getElementById('active-' + id);
            var statusEl = document.getElementById('status-' + id);
            if (res.status === 'success') {
                el.textContent = res.count;
                statusEl.innerHTML = '<span style="width:6px;height:6px;border-radius:50%;background:currentColor"></span> Online';
                statusEl.style.background = 'rgba(34,197,94,.15)';
                statusEl.style.color = '#4ade80';
            } else {
                el.textContent = '—';
                statusEl.innerHTML = '<span style="width:6px;height:6px;border-radius:50%;background:currentColor"></span> Offline';
                statusEl.style.background = 'rgba(239,68,68,.15)';
                statusEl.style.color = '#f87171';
            }
        })
        .catch(function() {
            var statusEl = document.getElementById('status-' + id);
            statusEl.innerHTML = '<span style="width:6px;height:6px;border-radius:50%;background:currentColor"></span> Error';
            statusEl.style.background = 'rgba(239,68,68,.15)';
            statusEl.style.color = '#f87171';
        });

    // System resources
    fetch('/monitoring/router/' + id + '/resources-json')
        .then(function(r) { return r.json(); })
        .then(function(res) {
            var el = document.getElementById('resources-' + id);
            if (res.status === 'success' && res.data) {
                var d = res.data;
                var cpuLoad = d['cpu-load'] || '—';
                var freeRam = d['free-memory'] ? Math.round(parseInt(d['free-memory']) / 1024 / 1024) : '—';
                var totalRam = d['total-memory'] ? Math.round(parseInt(d['total-memory']) / 1024 / 1024) : '—';
                var uptime = d['uptime'] || '—';
                var version = d['version'] || '';
                el.innerHTML = 'CPU: <strong>' + cpuLoad + '%</strong> · RAM: <strong>' + freeRam + '/' + totalRam + ' MB</strong> · Uptime: <strong>' + uptime + '</strong>' + (version ? ' · v' + version : '');
            } else {
                el.textContent = 'Tidak bisa ambil info sistem';
            }
        })
        .catch(function() {
            document.getElementById('resources-' + id).textContent = 'Koneksi gagal';
        });
});

function syncRouter(id) {
    if (!confirm('Sync PPPoE data dari router ini?')) return;
    fetch('/monitoring/router/' + id + '/sync', {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken},
    })
    .then(function(r) { return r.json(); })
    .then(function(res) {
        alert(res.message || 'Sync selesai');
    })
    .catch(function() {
        alert('Gagal sync');
    });
}
</script>
@endpush
@endsection
