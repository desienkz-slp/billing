@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
WA Gateway
@endsection
@section('content')
<div id="waMsg" class="cfg-alert"></div>
<div class="cfg-card">
    <div class="cfg-card-title">📱 Konfigurasi WhatsApp Gateway</div>
    <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:16px">Konfigurasi koneksi ke GOWA (go-whatsapp-web-multidevice) untuk pengiriman pesan WA otomatis.</p>
    <div style="display:flex;flex-direction:column;gap:12px;max-width:500px">
        <div><div class="cfg-label">URL Gateway</div><input type="text" id="waUrl" class="cfg-input" placeholder="http://172.18.20.241:3000" value="{{ $configs['wa_gateway_url'] ?? '' }}"></div>
        <div><div class="cfg-label">Device ID (kosongkan jika 1 device)</div><input type="text" id="waDevice" class="cfg-input" placeholder="" value="{{ $configs['wa_gateway_device_id'] ?? '' }}"></div>
        <div><div class="cfg-label">Auth User (Basic Auth)</div><input type="text" id="waUser" class="cfg-input" placeholder="" value="{{ $configs['wa_gateway_auth_user'] ?? '' }}"></div>
        <div><div class="cfg-label">Auth Password</div><input type="password" id="waPass" class="cfg-input" placeholder="" value="{{ $configs['wa_gateway_auth_pass'] ?? '' }}"></div>
        <div><div class="cfg-label">Timeout (detik)</div><input type="number" id="waTimeout" class="cfg-input" min="5" max="60" value="{{ $configs['wa_gateway_timeout'] ?? 10 }}" style="width:120px"></div>
        <div>
            <label class="cfg-check"><input type="checkbox" id="waEnabled" value="1" {{ ($configs['wa_gateway_enabled'] ?? '0') === '1' ? 'checked' : '' }}> <strong>WA Gateway Aktif</strong></label>
        </div>
        <div style="display:flex;gap:8px">
            <button class="cfg-btn cfg-btn-primary" onclick="saveWA()">✓ Simpan</button>
            <button class="cfg-btn cfg-btn-secondary" onclick="testWA()">🔗 Test Koneksi</button>
        </div>
    </div>
</div>
@push('scripts')
<script>
function saveWA() {
    var data = {
        wa_gateway_url: document.getElementById('waUrl').value,
        wa_gateway_device_id: document.getElementById('waDevice').value,
        wa_gateway_auth_user: document.getElementById('waUser').value,
        wa_gateway_auth_pass: document.getElementById('waPass').value,
        wa_gateway_timeout: document.getElementById('waTimeout').value,
        wa_gateway_enabled: document.getElementById('waEnabled').checked ? '1' : '0'
    };
    fetch('{{ route("config.setting-nota.update") }}', {
        method:'POST', headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}'},
        body: JSON.stringify(data)
    }).then(r=>r.json()).then(res => {
        var el = document.getElementById('waMsg');
        el.className = 'cfg-alert ' + (res.status==='success'?'ok':'err');
        el.textContent = res.message || 'Berhasil disimpan';
    });
}
function testWA() {
    var url = document.getElementById('waUrl').value;
    if (!url) { alert('URL belum diisi'); return; }
    var el = document.getElementById('waMsg');
    el.className = 'cfg-alert ok'; el.textContent = 'Testing koneksi ke ' + url + '...';
}
</script>
@endpush
@endsection
