@extends('layouts.app')
@section('title', 'Isolir')
@section('content')
<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px;">
    <div class="stat-card" style="border-left:4px solid var(--danger);">
        <div class="stat-value" style="color:var(--danger);">{{ $stats['total_isolated'] }}</div>
        <div class="stat-label">Pelanggan Terisolir</div>
    </div>
    <div class="stat-card" style="border-left:4px solid var(--success);">
        <div class="stat-value" style="color:var(--success);">{{ $stats['total_active'] }}</div>
        <div class="stat-label">Pelanggan Aktif</div>
    </div>
</div>

@if(session('success'))
<div style="padding:12px 16px; background:rgba(34,197,94,.1); border:1px solid rgba(34,197,94,.2); border-radius:10px; color:#22c55e; margin-bottom:16px; font-size:14px;">✅ {{ session('success') }}</div>
@endif

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
    <h2 style="font-size:18px; font-weight:600;">🚫 Pelanggan Terisolir</h2>
    <button class="btn-primary" onclick="document.getElementById('isolirModal').style.display='flex'">Isolir Pelanggan</button>
</div>

<div class="card" style="padding:0; overflow:hidden; margin-bottom:28px;">
    <table class="data-table">
        <thead><tr><th>Pelanggan</th><th>Paket</th><th>Area</th><th>Sejak</th><th>Durasi</th><th>Aksi</th></tr></thead>
        <tbody>
        @forelse($isolated as $c)
        <tr>
            <td><strong>{{ $c->name }}</strong></td>
            <td><span class="badge">{{ $c->package?->name ?? '-' }}</span></td>
            <td>{{ $c->area?->name ?? '-' }}</td>
            <td style="font-size:13px; color:var(--text-muted);">{{ $c->isolated_since?->format('d M Y') ?? '-' }}</td>
            <td style="font-size:13px;">{{ $c->isolated_since ? $c->isolated_since->diffForHumans(null, true) : '-' }}</td>
            <td>
                <form method="POST" action="{{ route('isolir.release', $c) }}" style="display:inline;" onsubmit="return confirm('Lepas isolir {{ $c->name }}?')">
                    @csrf
                    <button type="submit" style="padding:6px 14px; background:rgba(34,197,94,.1); border:1px solid rgba(34,197,94,.3); border-radius:8px; color:#22c55e; font-size:12px; font-weight:600; cursor:pointer;">✓ Lepas</button>
                </form>
            </td>
        </tr>
        @empty
        <tr><td colspan="6" style="text-align:center; padding:48px; color:var(--text-muted);">Tidak ada pelanggan yang terisolir 🎉</td></tr>
        @endforelse
        </tbody>
    </table>
</div>

<div id="isolirModal" class="modal-overlay" style="display:none;" onclick="if(event.target===this)this.style.display='none'">
    <div class="modal-content">
        <div class="modal-header"><h3>🚫 Isolir Pelanggan</h3><button onclick="this.closest('.modal-overlay').style.display='none'" class="modal-close">&times;</button></div>
        <div class="modal-body">
            <p style="color:var(--text-muted); font-size:13px; margin-bottom:16px;">Pilih pelanggan yang akan diisolir:</p>
            @foreach($candidates->take(20) as $c)
            <form method="POST" action="{{ route('isolir.isolate', $c) }}" style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid var(--border);" onsubmit="return confirm('Isolir {{ $c->name }}?')">
                @csrf
                <div><strong>{{ $c->name }}</strong><br><span style="font-size:12px; color:var(--text-muted);">{{ $c->package?->name ?? '' }}</span></div>
                <button type="submit" style="padding:6px 14px; background:rgba(239,68,68,.1); border:1px solid rgba(239,68,68,.3); border-radius:8px; color:#ef4444; font-size:12px; font-weight:600; cursor:pointer;">Isolir</button>
            </form>
            @endforeach
        </div>
    </div>
</div>
@endsection
@push('styles')
<style>
.stat-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:20px 24px;box-shadow:var(--shadow-sm)}
.stat-value{font-size:28px;font-weight:700}.stat-label{font-size:13px;color:var(--text-muted)}
.btn-primary{padding:10px 20px;background:var(--gradient);border:none;border-radius:10px;color:white;font-size:14px;font-weight:600;cursor:pointer}
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow-sm)}
.data-table{width:100%;border-collapse:collapse;font-size:14px}
.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}
.data-table td{padding:14px 16px;border-bottom:1px solid var(--border)}
.data-table tbody tr:hover{background:var(--accent-bg)}
.badge{display:inline-block;padding:3px 10px;border-radius:6px;font-size:12px;font-weight:500;background:rgba(99,102,241,.1);color:var(--accent)}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}
.modal-content{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;width:100%;max-width:480px;max-height:80vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.3)}
.modal-header{display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid var(--border)}
.modal-close{width:32px;height:32px;border:none;background:none;font-size:24px;color:var(--text-muted);cursor:pointer}
.modal-body{padding:24px}
</style>
@endpush
