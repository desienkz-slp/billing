@extends('layouts.app')
@section('title', 'Master Pelanggan')

@section('content')
<div class="header-action" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <div>
        <h2 style="font-size:18px; font-weight:700;">Data Master Pelanggan</h2>
        <p style="font-size:13px; color:var(--text-muted); margin-top:4px;">Kelola data pelanggan secara keseluruhan.</p>
    </div>
    <a href="{{ route('customers.create') }}" class="btn-primary" style="text-decoration:none;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Tambah Pelanggan
    </a>
</div>

@if(session('success'))
<div style="background:rgba(34,197,94,0.1); border:1px solid #22c55e; color:#166534; padding:12px 16px; border-radius:8px; margin-bottom:20px; font-size:14px; display:flex; align-items:center; gap:8px;">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
    {{ session('success') }}
</div>
@endif

{{-- Filters --}}
<div class="card" style="margin-bottom:20px; padding:16px 20px;">
    <form method="GET" action="{{ route('customers.index') }}" style="display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
        <div style="flex:1; min-width:200px;">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari nama, username, HP..."
                class="input-field" style="width:100%;">
        </div>
        <button type="submit" class="btn-secondary">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            Cari
        </button>
        @if(request('search'))
            <a href="{{ route('customers.index') }}" class="btn-ghost">Reset</a>
        @endif
        
        <div style="width:1px; height:24px; background:var(--border); margin:0 8px;"></div>
        
        <button type="button" class="btn-diagnostic" id="btnCheckPppoeList" style="border-color:rgba(245,158,11,.6);color:#fcd34d;" title="Deteksi 1 PPPoE user dipakai 2+ pelanggan">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            PPP
        </button>
        <button type="button" class="btn-diagnostic" id="btnCheckPaketMismatch" style="border-color:rgba(16,185,129,.6);color:#34d399;" title="Cek pelanggan dengan paket tidak sesuai antara billing dan router">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
            Paket
        </button>
        <button type="button" class="btn-diagnostic" id="btnCheckSync" style="border-color:rgba(59,130,246,.6);color:#60a5fa;" title="Cek pelanggan belum terhubung PPPoE user">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 8v8"/><path d="M16 8v8"/><path d="M4 12h16"/><path d="M12 4v16"/></svg>
            Sync
        </button>
    </form>
</div>

{{-- Table --}}
<div class="card" style="padding:0; overflow:hidden;">
    <div style="overflow-x:auto; min-height:300px;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Nama & Username</th>
                    <th>Kontak</th>
                    <th>Paket / Harga</th>
                    <th>Area</th>
                    <th>Status</th>
                    <th style="width:120px; text-align:right;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($customers as $c)
                <tr>
                    <td>
                        <div style="font-weight:600; display:flex; align-items:center; gap:6px;">
                            {{ $c->name }}
                            @if($c->sync_db_pusat)
                                <span title="Tersinkronisasi ke DB Pusat (API)" style="display:inline-flex; align-items:center; justify-content:center; width:18px; height:18px; border-radius:50%; background:#eff6ff; color:#3b82f6; border:1px solid #bfdbfe;">
                                    <svg viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path></svg>
                                </span>
                            @endif
                        </div>
                        <div style="font-size:12px; color:var(--text-muted);">{{ $c->username ?? '-' }}</div>
                    </td>
                    <td>
                        <div style="font-size:13px;">{{ $c->phone ?? '-' }}</div>
                    </td>
                    <td>
                        <span class="badge">{{ $c->package?->name ?? '-' }}</span>
                        <div style="font-size:12px; color:var(--text-muted); margin-top:2px;">
                            Rp {{ number_format($c->getEffectivePrice(),0,',','.') }} ({{ ucfirst($c->jenis_bayar ?? 'prabayar') }})
                        </div>
                    </td>
                    <td>{{ $c->area?->name ?? '-' }}</td>
                    <td>
                        @if($c->is_on_leave)
                            <span class="status-badge status-muted">Cuti</span>
                        @elseif($c->is_isolated)
                            <span class="status-badge status-danger">Isolir</span>
                        @elseif($c->status === 'active')
                            <span class="status-badge status-success">Aktif</span>
                        @else
                            <span class="status-badge status-muted">{{ ucfirst($c->status) }}</span>
                        @endif
                    </td>
                    <td style="text-align:right;">
                        <div style="display:flex; gap:4px; justify-content:flex-end;">
                            <button onclick="openCustomerDetail({{ $c->id }})" class="action-btn" title="Detail">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                            </button>
                            <a href="{{ route('customers.edit', $c->id) }}" class="action-btn" title="Edit">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                            </a>
                            <form action="{{ route('customers.destroy', $c->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pelanggan {{ $c->name }}? Data tidak akan benar-benar hilang (soft delete).')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="action-btn" title="Hapus">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align:center; padding:48px; color:var(--text-muted);">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" style="margin:0 auto 12px; display:block; opacity:0.3;"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        Belum ada data pelanggan yang ditemukan
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($customers->hasPages())
        <div style="padding:16px 20px; border-top:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:13px; color:var(--text-muted);">
                Menampilkan {{ $customers->firstItem() }}-{{ $customers->lastItem() }} dari {{ $customers->total() }}
            </span>
            {{ $customers->links('pagination.simple') }}
        </div>
    @endif
</div>

{{-- Diagnostic Modal --}}
<div id="diagnosticModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:9999; align-items:center; justify-content:center;">
    <div style="background:var(--bg-card); width:80%; max-width:800px; max-height:80vh; border-radius:12px; display:flex; flex-direction:column; box-shadow:0 10px 25px rgba(0,0,0,0.2);">
        <div style="padding:16px 20px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
            <h3 id="diagnosticTitle" style="margin:0; font-size:16px;">Hasil Diagnostik</h3>
            <button onclick="document.getElementById('diagnosticModal').style.display='none'" style="background:none; border:none; cursor:pointer; color:var(--text-muted);">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <div id="diagnosticBody" style="padding:20px; overflow-y:auto; flex:1; font-size:13px;">
            <div id="diagnosticLoading" style="text-align:center; padding:40px; color:var(--text-muted); display:none;">
                <svg class="animate-spin" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin:0 auto 10px; display:block; animation:spin 1s linear infinite;"><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/></svg>
                Memindai data... Mohon tunggu.
            </div>
            <div id="diagnosticContent"></div>
        </div>
        <div style="padding:16px 20px; border-top:1px solid var(--border); text-align:right;">
            <button onclick="document.getElementById('diagnosticModal').style.display='none'" class="btn-secondary">Tutup</button>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    .btn-primary { display:inline-flex; align-items:center; gap:6px; padding:10px 20px; background:var(--gradient); border:none; border-radius:10px; color:white; font-size:14px; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s; }
    .btn-primary:hover { transform:translateY(-1px); box-shadow:0 4px 15px rgba(99,102,241,0.4); }
    .btn-secondary { display:inline-flex; align-items:center; gap:6px; padding:8px 16px; background:var(--bg-card); border:1px solid var(--border); border-radius:8px; color:var(--text-secondary); font-size:13px; font-weight:500; cursor:pointer; font-family:inherit; transition:all 0.2s; text-decoration:none; }
    .btn-secondary:hover { border-color:var(--accent); color:var(--accent); }
    .btn-ghost { padding:8px 12px; background:none; border:none; color:var(--text-muted); font-size:13px; cursor:pointer; text-decoration:none; }
    .btn-ghost:hover { color:var(--accent); }
    .btn-diagnostic { display:inline-flex; align-items:center; gap:6px; padding:6px 12px; background:var(--bg-card); border:1px solid; border-radius:6px; font-size:12px; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s; }
    .btn-diagnostic:hover { filter:brightness(1.2); background:rgba(255,255,255,0.05); }

    .input-field { padding:8px 12px; background:var(--bg-card); border:1px solid var(--border); border-radius:8px; color:var(--text-primary); font-size:14px; font-family:inherit; outline:none; transition:border-color 0.2s; }
    .input-field:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(99,102,241,0.15); }

    .card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:24px; box-shadow:var(--shadow-sm); }
    .data-table { width:100%; border-collapse:collapse; font-size:14px; }
    .data-table th { text-align:left; padding:12px 16px; color:var(--text-muted); font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:0.5px; border-bottom:2px solid var(--border); background:var(--bg-body); }
    .data-table td { padding:14px 16px; border-bottom:1px solid var(--border); }
    .data-table tbody tr { transition:background 0.15s; }
    .data-table tbody tr:hover { background:var(--accent-bg); }

    .badge { display:inline-block; padding:3px 10px; border-radius:6px; font-size:12px; font-weight:500; background:rgba(99,102,241,0.1); color:var(--accent); }
    .status-badge { display:inline-block; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:600; }
    .status-success { background:rgba(34,197,94,0.1); color:#22c55e; }
    .status-danger { background:rgba(239,68,68,0.1); color:#ef4444; }
    .status-muted { background:rgba(148,163,184,0.1); color:var(--text-muted); }

    .action-btn { width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; border-radius:8px; color:var(--text-muted); transition:all 0.15s; text-decoration:none; background:none; border:none; cursor:pointer;}
    .action-btn:hover { background:var(--accent-bg); color:var(--accent); }

    @keyframes spin { 100% { transform:rotate(360deg); } }
    .diagnostic-table { width:100%; border-collapse:collapse; margin-top:10px; }
    .diagnostic-table th, .diagnostic-table td { padding:10px; border:1px solid var(--border); text-align:left; }
    .diagnostic-table th { background:var(--bg-body); font-weight:600; }
</style>

<script>
function showDiagnosticModal(title) {
    document.getElementById('diagnosticTitle').innerText = title;
    document.getElementById('diagnosticContent').innerHTML = '';
    document.getElementById('diagnosticLoading').style.display = 'block';
    document.getElementById('diagnosticModal').style.display = 'flex';
}

function renderTable(headers, rows) {
    let html = '<table class="diagnostic-table"><thead><tr>';
    headers.forEach(h => html += `<th>${h}</th>`);
    html += '</tr></thead><tbody>';
    
    if (rows.length === 0) {
        html += `<tr><td colspan="${headers.length}" style="text-align:center; padding:20px; color:#10b981;">Aman. Tidak ada anomali terdeteksi! 🎉</td></tr>`;
    } else {
        rows.forEach(r => {
            html += '<tr>';
            r.forEach(d => html += `<td>${d}</td>`);
            html += '</tr>';
    html += '</tbody></table>';
    document.getElementById('diagnosticLoading').style.display = 'none';
    document.getElementById('diagnosticContent').innerHTML = html;
}

document.getElementById('btnCheckPppoeList').addEventListener('click', async function() {
    showDiagnosticModal('Cek Duplikat PPPoE');
    try {
        let res = await fetch('{{ route("customers.diagnostics.duplicates") }}');
        let data = await res.json();
        let rows = [];
        data.duplicates.forEach(d => {
            rows.push([
                d.username,
                d.router_name,
                d.customers.map(c => c.name).join('<br>')
            ]);
        });
        renderTable(['PPPoE Username', 'Router', 'Daftar Pelanggan (Duplikat)'], rows);
    } catch(e) {
        document.getElementById('diagnosticLoading').innerHTML = 'Gagal memuat data.';
    }
});

document.getElementById('btnCheckPaketMismatch').addEventListener('click', async function() {
    showDiagnosticModal('Cek Mismatch Paket');
    try {
        let res = await fetch('{{ route("customers.diagnostics.mismatch") }}');
        let data = await res.json();
        let rows = [];
        data.mismatches.forEach(d => {
            rows.push([
                d.nama,
                d.username,
                d.router_nama,
                d.paket_billing,
                d.profile_router,
                d.is_isolir ? '<span style="color:#ef4444">ISOLIR</span>' : '<span style="color:#f59e0b">MISMATCH</span>'
            ]);
        });
        renderTable(['Nama Pelanggan', 'PPPoE Username', 'Router', 'Paket (Aplikasi)', 'Profile (Mikrotik)', 'Status'], rows);
    } catch(e) {
        document.getElementById('diagnosticLoading').innerHTML = 'Gagal memuat data.';
    }
});

document.getElementById('btnCheckSync').addEventListener('click', async function() {
    showDiagnosticModal('Cek Pelanggan Belum Tersinkron (Kosong)');
    try {
        let res = await fetch('{{ route("customers.diagnostics.unsynced") }}');
        let data = await res.json();
        let rows = [];
        data.unsynced.forEach(d => {
            rows.push([
                d.name,
                d.package,
                '<a href="/customers/'+d.id+'/edit" style="color:#3b82f6;text-decoration:underline;">Update Kredensial</a>'
            ]);
        });
        renderTable(['Nama Pelanggan', 'Paket', 'Aksi'], rows);
    } catch(e) {
        document.getElementById('diagnosticLoading').innerHTML = 'Gagal memuat data.';
    }
});
</script>

<style>
/* Detail Modal Styles */
#customerDetailModal { display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.5); z-index:9999; align-items:center; justify-content:center; }
#customerDetailModal .modal-content { background:var(--bg-card); width:90%; max-width:700px; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,0.2); overflow:hidden; display:flex; flex-direction:column; max-height:90vh; }
#customerDetailModal .modal-header { display:flex; justify-content:space-between; align-items:center; background:var(--bg-body); padding:16px 20px; border-bottom:1px solid var(--border); }
#customerDetailModal .modal-title { font-size:18px; font-weight:700; color:var(--text-primary); }
#customerDetailModal .modal-close { background:none; border:none; cursor:pointer; color:var(--text-muted); }
#customerDetailModal .modal-close:hover { color:#ef4444; }
#customerDetailModal .modal-body { padding:20px; overflow-y:auto; flex:1; }
#customerDetailModal .detail-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px; }
#customerDetailModal .detail-box { background:var(--bg-body); padding:12px; border-radius:8px; border:1px solid var(--border); }
#customerDetailModal .detail-label { font-size:12px; color:var(--text-muted); margin-bottom:4px; text-transform:uppercase; letter-spacing:0.5px; font-weight:600; }
#customerDetailModal .detail-value { font-size:14px; font-weight:500; color:var(--text-primary); word-break:break-word; }
#customerDetailModal .detail-row { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid var(--border); }
#customerDetailModal .detail-row:last-child { border-bottom:none; }
#customerDetailModal .detail-section-title { font-size:15px; font-weight:600; color:var(--text-primary); margin:16px 0 8px; border-bottom:2px solid var(--border); padding-bottom:4px; }
#customerDetailModal .loading-spinner { text-align:center; padding:40px; color:var(--text-muted); }
</style>

<!-- Customer Detail Modal -->
<div id="customerDetailModal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-title">Detail Pelanggan</div>
            <button class="modal-close" onclick="closeCustomerDetail()">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <div class="modal-body" id="customerDetailBody">
            <div class="loading-spinner">Memuat data...</div>
        </div>
    </div>
</div>

<script>
function openCustomerDetail(id) {
    document.getElementById('customerDetailModal').style.display = 'flex';
    document.getElementById('customerDetailBody').innerHTML = '<div class="loading-spinner">Memuat data...</div>';

    fetch(`/customers/${id}`)
        .then(res => res.json())
        .then(res => {
            if (res.status === 'success') {
                const data = res.data;
                let statBadge = '';
                if(data.is_on_leave) statBadge = '<span class="status-badge status-muted">Cuti</span>';
                else if(data.is_isolated) statBadge = '<span class="status-badge status-danger">Isolir</span>';
                else if(data.status === 'active') statBadge = '<span class="status-badge status-success">Aktif</span>';
                else statBadge = `<span class="status-badge status-muted">${data.status}</span>`;

                const html = `
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px;">
                        <div>
                            <h2 style="margin:0 0 4px; font-size:20px; font-weight:700;">${data.name}</h2>
                            <div style="color:var(--text-muted); font-size:14px;">Username: ${data.username || '-'}</div>
                        </div>
                        <div>${statBadge}</div>
                    </div>

                    <div class="detail-grid">
                        <div class="detail-box">
                            <div class="detail-label">Nomor Telepon</div>
                            <div class="detail-value">${data.phone || '-'}</div>
                        </div>
                        <div class="detail-box">
                            <div class="detail-label">Paket Internet</div>
                            <div class="detail-value">${data.package}</div>
                        </div>
                        <div class="detail-box">
                            <div class="detail-label">Area / Wilayah</div>
                            <div class="detail-value">${data.area}</div>
                        </div>
                        <div class="detail-box">
                            <div class="detail-label">Titik ODP</div>
                            <div class="detail-value">${data.odp}</div>
                        </div>
                        <div class="detail-box">
                            <div class="detail-label">Router MikroTik</div>
                            <div class="detail-value">${data.router}</div>
                        </div>
                        <div class="detail-box">
                            <div class="detail-label">Server RADIUS</div>
                            <div class="detail-value">${data.server}</div>
                        </div>
                    </div>

                    <div class="detail-section-title">Alamat & Tanggung Jawab</div>
                    <div style="background:var(--bg-body); padding:12px; border-radius:8px; border:1px solid var(--border); margin-bottom:20px;">
                        <div style="margin-bottom:8px;">
                            <span class="detail-label">Alamat Lengkap:</span>
                            <div class="detail-value">${data.address || '-'}</div>
                        </div>
                        <div>
                            <span class="detail-label">Penanggung Jawab (Sales/Agen):</span>
                            <div class="detail-value">${data.sales}</div>
                        </div>
                    </div>

                    <div class="detail-section-title">Pengaturan Tagihan & Sinkronisasi</div>
                    <div style="background:var(--bg-body); padding:12px; border-radius:8px; border:1px solid var(--border);">
                        <div class="detail-row">
                            <span class="detail-label">Auto Isolir</span>
                            <span class="detail-value">${data.auto_isolir ? `Aktif (Max telat: ${data.max_tunggakan} bulan)` : 'Nonaktif'}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Pakai PPN</span>
                            <span class="detail-value">${data.pakai_ppn ? 'Ya' : 'Tidak'}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Auto WA Tagihan</span>
                            <span class="detail-value">${data.auto_wa_tagihan ? 'Aktif' : 'Nonaktif'}</span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Sync DB Pusat (API)</span>
                            <span class="detail-value">${data.sync_db_pusat ? '<span style="color:#3b82f6; font-weight:600;">Ya (Sinkron)</span>' : 'Tidak'}</span>
                        </div>
                    </div>
                `;
                document.getElementById('customerDetailBody').innerHTML = html;
            } else {
                document.getElementById('customerDetailBody').innerHTML = `<div class="loading-spinner" style="color:#ef4444;">Gagal memuat detail pelanggan.</div>`;
            }
        })
        .catch(err => {
            document.getElementById('customerDetailBody').innerHTML = `<div class="loading-spinner" style="color:#ef4444;">Terjadi kesalahan jaringan.</div>`;
        });
}

function closeCustomerDetail() {
    document.getElementById('customerDetailModal').style.display = 'none';
}
</script>
@endpush
