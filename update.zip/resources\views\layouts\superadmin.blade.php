@php
    $user = $user ?? auth()->user()?->load('role', 'tenant');
    $tenant = $tenant ?? ($user->tenant ?? null);
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="color-scheme" content="dark">
    <title>Super Admin · LadaPala-Bill</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0b0d14;
            --bg-card: rgba(20,16,28,.75);
            --bg-sidebar: rgba(20,16,28,.95);
            --border: rgba(255,255,255,.08);
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --accent: #f97316;
            --accent-glow: rgba(249,115,22,.15);
            --accent-2: #ef4444;
            --success: #22c55e;
            --danger: #ef4444;
            --warning: #f59e0b;
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Inter',system-ui,sans-serif;background:var(--bg-primary);color:var(--text-primary);min-height:100vh;display:flex;overflow:hidden}

        /* Sidebar */
        .sa-sidebar{width:260px;background:var(--bg-sidebar);border-right:1px solid var(--border);display:flex;flex-direction:column;height:100vh;position:fixed;z-index:50;transition:transform .3s}
        .sa-sidebar-header{padding:20px;border-bottom:1px solid var(--border)}
        .sa-sidebar-header h2{font-size:1rem;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px}
        .sa-sidebar-header h2 span{background:linear-gradient(135deg,#ef4444,#f97316);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-size:1.1rem}
        .sa-sidebar-header p{font-size:.75rem;color:var(--text-muted);margin-top:4px}
        .sa-nav{flex:1;overflow-y:auto;padding:12px}
        .sa-nav-section{font-size:.65rem;text-transform:uppercase;letter-spacing:.08em;color:var(--text-muted);padding:12px 12px 6px;font-weight:600}
        .sa-nav-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:8px;color:var(--text-secondary);text-decoration:none;font-size:.85rem;font-weight:500;transition:all .2s;margin-bottom:2px}
        .sa-nav-item:hover{background:rgba(255,255,255,.06);color:var(--text-primary)}
        .sa-nav-item.active{background:var(--accent-glow);color:var(--accent);border:1px solid rgba(249,115,22,.2)}
        .sa-nav-item svg{width:18px;height:18px;flex-shrink:0}
        .sa-nav-sep{height:1px;background:var(--border);margin:8px 12px}
        .sa-sidebar-footer{padding:16px;border-top:1px solid var(--border)}
        .sa-sidebar-footer .user-info{display:flex;align-items:center;gap:10px;font-size:.8rem;color:var(--text-secondary)}
        .sa-sidebar-footer .user-avatar{width:32px;height:32px;border-radius:8px;background:linear-gradient(135deg,#ef4444,#f97316);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff}

        /* Main */
        .sa-main{flex:1;margin-left:260px;height:100vh;overflow-y:auto;padding:0}
        .sa-header{position:sticky;top:0;z-index:10;background:rgba(11,13,20,.85);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);padding:16px 28px;display:flex;align-items:center;justify-content:space-between}
        .sa-header h1{font-size:1.1rem;font-weight:700;display:flex;align-items:center;gap:8px}
        .sa-header .sa-badge{font-size:.65rem;padding:3px 8px;background:linear-gradient(135deg,#ef4444,#f97316);color:#fff;border-radius:6px;font-weight:700;text-transform:uppercase;letter-spacing:.05em}
        .sa-content{padding:24px 28px}

        /* Cards */
        .sa-card{background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px;backdrop-filter:blur(8px)}
        .sa-card-title{font-size:.9rem;font-weight:700;color:#fff;margin-bottom:12px;display:flex;align-items:center;gap:8px}
        .sa-label{font-size:.78rem;color:var(--text-secondary);margin-bottom:4px;font-weight:500}
        .sa-input{width:100%;padding:8px 12px;background:rgba(0,0,0,.3);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);font-size:.85rem;font-family:inherit;outline:none;transition:border-color .2s}
        .sa-input:focus{border-color:var(--accent)}
        select.sa-input{cursor:pointer}
        textarea.sa-input{resize:vertical}

        /* Buttons */
        .sa-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:8px;border:none;font-size:.82rem;font-weight:600;cursor:pointer;transition:all .2s;font-family:inherit}
        .sa-btn-primary{background:linear-gradient(135deg,#ef4444,#f97316);color:#fff}
        .sa-btn-primary:hover{opacity:.9;transform:translateY(-1px)}
        .sa-btn-danger{background:rgba(239,68,68,.15);color:#f87171;border:1px solid rgba(239,68,68,.3)}
        .sa-btn-danger:hover{background:rgba(239,68,68,.25)}
        .sa-btn-secondary{background:rgba(255,255,255,.06);color:var(--text-secondary);border:1px solid var(--border)}
        .sa-btn-secondary:hover{background:rgba(255,255,255,.1)}
        .sa-btn-success{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.3)}

        /* Table */
        .sa-table{width:100%;border-collapse:collapse;font-size:.82rem}
        .sa-table th{text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid var(--border)}
        .sa-table td{padding:10px 12px;border-bottom:1px solid rgba(255,255,255,.04);color:var(--text-secondary)}
        .sa-table tr:hover td{background:rgba(255,255,255,.02)}
        .sa-table code{font-size:.78rem;color:var(--accent);background:rgba(249,115,22,.1);padding:2px 6px;border-radius:4px}

        /* Alerts */
        .sa-alert{padding:10px 14px;border-radius:8px;font-size:.82rem;margin-bottom:12px;display:none}
        .sa-alert.ok{display:block;background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
        .sa-alert.err{display:block;background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2)}

        /* Grid */
        .sa-grid-2{display:grid;grid-template-columns:1fr 1.5fr;gap:16px}
        @media(max-width:900px){.sa-grid-2{grid-template-columns:1fr}}

        /* Status badge */
        .sa-status{font-size:.72rem;padding:3px 8px;border-radius:6px;font-weight:600;display:inline-flex;align-items:center;gap:4px}
        .sa-status-active{background:rgba(34,197,94,.12);color:#4ade80}
        .sa-status-inactive{background:rgba(239,68,68,.12);color:#f87171}
        .sa-status-expired{background:rgba(100,116,139,.12);color:#94a3b8}
        .sa-status-grace{background:rgba(245,158,11,.12);color:#fbbf24}

        /* Stat cards */
        .sa-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px}
        .sa-stat{background:var(--bg-card);border:1px solid var(--border);border-radius:10px;padding:16px;text-align:center}
        .sa-stat-value{font-size:1.5rem;font-weight:800;color:#fff}
        .sa-stat-label{font-size:.72rem;color:var(--text-muted);margin-top:4px;text-transform:uppercase;letter-spacing:.04em}

        /* Mobile */
        .sa-hamburger{display:none;position:fixed;top:12px;left:12px;z-index:60;background:rgba(20,16,28,.9);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);padding:8px;cursor:pointer;font-size:1.2rem}
        .sa-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:40}
        @media(max-width:768px){
            .sa-sidebar{transform:translateX(-100%)}
            .sa-sidebar.open{transform:translateX(0)}
            .sa-main{margin-left:0}
            .sa-hamburger{display:block}
            .sa-overlay.show{display:block}
            .sa-content{padding:16px}
        }

        /* Modal */
        .sa-modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:999;align-items:center;justify-content:center}
        .sa-modal-overlay.show{display:flex}
        .sa-modal{background:#0d0f17;border:1px solid var(--border);border-radius:16px;padding:24px;width:100%;max-width:520px;max-height:90vh;overflow-y:auto}
        .sa-modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
        .sa-modal-header h3{font-size:1rem;font-weight:700;color:#fff}
        .sa-modal-close{background:none;border:none;color:var(--text-muted);font-size:1.2rem;cursor:pointer}
    </style>
    @stack('styles')
</head>
<body>
    <button class="sa-hamburger" onclick="document.querySelector('.sa-sidebar').classList.toggle('open');document.querySelector('.sa-overlay').classList.toggle('show')">☰</button>
    <div class="sa-overlay" onclick="document.querySelector('.sa-sidebar').classList.remove('open');this.classList.remove('show')"></div>

    <aside class="sa-sidebar">
        <div class="sa-sidebar-header">
            <h2><span>🏢</span> Super Admin</h2>
            <p>Kelola Tenant & Sistem</p>
        </div>
        <nav class="sa-nav">
            <div class="sa-nav-section">Manajemen</div>
            <a href="{{ route('superadmin.tenants') }}" class="sa-nav-item {{ request()->routeIs('superadmin.tenants') && !request()->routeIs('superadmin.tenants.detail') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                Kelola Tenant
            </a>
            <a href="{{ route('superadmin.subscriptions') }}" class="sa-nav-item {{ request()->routeIs('superadmin.subscriptions') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                Subscription
            </a>

            <div class="sa-nav-sep"></div>
            <div class="sa-nav-section">Akun</div>
            <a href="{{ route('superadmin.profile') }}" class="sa-nav-item {{ request()->routeIs('superadmin.profile') ? 'active' : '' }}">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                Profil Pengelola
            </a>

            <div class="sa-nav-sep"></div>
            <form method="POST" action="{{ route('logout') }}" style="padding:0 4px">
                @csrf
                <button type="submit" class="sa-nav-item" style="width:100%;border:none;background:none;cursor:pointer;color:#f87171;font-family:inherit">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                    Logout
                </button>
            </form>
        </nav>
        <div class="sa-sidebar-footer">
            <div class="user-info">
                <div class="user-avatar">{{ strtoupper(substr($user->name ?? 'U', 0, 1)) }}</div>
                <div>
                    <div style="font-weight:600;color:var(--text-primary)">{{ $user->name }}</div>
                    <div style="font-size:.7rem;color:var(--accent)">System Admin</div>
                </div>
            </div>
        </div>
    </aside>

    <div class="sa-main">
        <header class="sa-header">
            <h1>@yield('page-title', 'Super Admin') <span class="sa-badge">System</span></h1>
            <div style="font-size:.8rem;color:var(--text-muted)">{{ now()->format('d M Y, H:i') }}</div>
        </header>
        <div class="sa-content">
            @yield('content')
        </div>
    </div>

    @stack('scripts')
</body>
</html>
