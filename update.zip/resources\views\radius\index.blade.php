@php
    $user = auth()->user()?->load('role', 'tenant');
    $tenant = $user?->tenant;
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>RADIUS · {{ $tenant->name ?? 'RADIUS' }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{--bg:#0b1120;--bg-card:rgba(15,23,42,.7);--border:rgba(255,255,255,.08);--text:#e2e8f0;--muted:#64748b;--accent:#8b5cf6;--accent-glow:rgba(139,92,246,.15);--success:#22c55e;--danger:#ef4444;--warning:#f59e0b}
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text);min-height:100vh}

        .radius-header{padding:20px 28px;border-bottom:1px solid var(--border);background:rgba(11,17,32,.85);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
        .radius-header h1{font-size:1.2rem;font-weight:800;display:flex;align-items:center;gap:10px}
        .radius-header h1 svg{width:28px;height:28px;color:var(--accent)}
        .radius-header h1 span{font-weight:400;color:var(--muted);font-size:.85rem}
        .radius-btn{padding:8px 16px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.06);color:var(--text);font-size:.82rem;font-weight:500;cursor:pointer;transition:all .2s;font-family:inherit;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
        .radius-btn:hover{background:rgba(255,255,255,.12)}
        .radius-btn-primary{background:linear-gradient(135deg,#8b5cf6,#6366f1);border:none;color:#fff}
        .radius-btn-primary:hover{opacity:.9}

        .radius-content{padding:24px 28px;max-width:1200px;margin:0 auto}

        .router-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px;margin-top:20px}
        .router-card{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;padding:24px;backdrop-filter:blur(8px);transition:all .3s}
        .router-card:hover{border-color:rgba(139,92,246,.3);box-shadow:0 0 20px rgba(139,92,246,.08)}
        .router-card-header{display:flex;justify-content:space-between;align-items:start;margin-bottom:16px}
        .router-name{font-size:1.05rem;font-weight:700;color:#fff}
        .router-host{font-size:.78rem;color:var(--muted);margin-top:2px}
        .router-badge{padding:4px 10px;border-radius:99px;font-size:.7rem;font-weight:600;display:inline-flex;align-items:center;gap:4px}
        .router-badge.active{background:rgba(34,197,94,.15);color:#4ade80}
        .router-badge .dot{width:6px;height:6px;border-radius:50%;background:currentColor}

        .router-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px}
        .router-stat{text-align:center;padding:12px 8px;background:rgba(0,0,0,.25);border-radius:10px}
        .router-stat-value{font-size:1.3rem;font-weight:700}
        .router-stat-label{font-size:.65rem;color:var(--muted);margin-top:2px;text-transform:uppercase;letter-spacing:.04em}

        .router-actions{display:flex;gap:8px}
        .router-actions a,.router-actions button{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border-radius:10px;font-size:.82rem;font-weight:600;text-decoration:none;cursor:pointer;transition:all .2s;font-family:inherit;border:none}
        .action-manage{background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff}
        .action-manage:hover{opacity:.85;transform:translateY(-1px)}
        .action-sync{background:rgba(255,255,255,.06);color:var(--text);border:1px solid var(--border)!important}
        .action-sync:hover{background:rgba(255,255,255,.12)}

        /* Empty state */
        .empty-state{text-align:center;padding:80px 20px;color:var(--muted)}
        .empty-state svg{width:64px;height:64px;margin:0 auto 16px;opacity:.4}

        @media(max-width:768px){
            .radius-content{padding:16px}
            .router-grid{grid-template-columns:1fr}
        }
    </style>
</head>
<body>
    <header class="radius-header">
        <h1>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/></svg>
            RADIUS
            <span>· {{ $tenant->name ?? '' }}</span>
        </h1>
        <a href="{{ route('app-gateway') }}" class="radius-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
            Kembali
        </a>
    </header>

    <div class="radius-content">
        <div style="display:flex;justify-content:space-between;align-items:center">
            <div>
                <h2 style="font-size:1rem;font-weight:700">Pilih Router</h2>
                <p style="font-size:.82rem;color:var(--muted);margin-top:4px">Pilih router untuk mengelola PPPoE secret & profile</p>
            </div>
        </div>

        @if($routers->isEmpty())
        <div class="empty-state">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="14" width="20" height="6" rx="2"/><path d="M6 14V8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v6"/></svg>
            <p style="font-size:1rem;font-weight:600;margin-bottom:4px">Belum ada router aktif</p>
            <p style="font-size:.85rem">Tambahkan router di menu Config terlebih dahulu</p>
            <a href="{{ route('config.router') }}" class="radius-btn-primary" style="display:inline-flex;margin-top:12px;padding:10px 20px;border-radius:10px;text-decoration:none">
                Tambah Router →
            </a>
        </div>
        @else
        <div class="router-grid">
            @foreach($routers as $router)
            <div class="router-card">
                <div class="router-card-header">
                    <div>
                        <div class="router-name">{{ $router->name }}</div>
                        <div class="router-host">{{ $router->host }}:{{ $router->port }}</div>
                    </div>
                    <span class="router-badge active"><span class="dot"></span> Aktif</span>
                </div>

                <div class="router-stats">
                    <div class="router-stat">
                        <div class="router-stat-value" style="color:var(--accent)">{{ $router->pppoe_secrets_count }}</div>
                        <div class="router-stat-label">Secrets</div>
                    </div>
                    <div class="router-stat">
                        <div class="router-stat-value" style="color:var(--success)">{{ $router->pppoe_profiles_count }}</div>
                        <div class="router-stat-label">Profiles</div>
                    </div>
                    <div class="router-stat">
                        <div class="router-stat-value" style="color:var(--warning)">{{ $router->customers_count }}</div>
                        <div class="router-stat-label">Pelanggan</div>
                    </div>
                </div>

                @if($router->use_radius)
                <div style="display:flex;align-items:center;gap:6px;padding:8px 12px;background:rgba(139,92,246,.1);border:1px solid rgba(139,92,246,.2);border-radius:8px;font-size:.75rem;color:#a78bfa;margin-bottom:12px">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    RADIUS enabled
                </div>
                @endif

                <div class="router-actions">
                    <a href="{{ route('radius.secrets', $router) }}" class="action-manage">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        Kelola PPPoE
                    </a>
                    <button class="action-sync" onclick="syncRouter({{ $router->id }})">
                        🔄 Sync
                    </button>
                </div>
            </div>
            @endforeach
        </div>
        @endif
    </div>

    <script>
    var csrfToken = '{{ csrf_token() }}';

    function syncRouter(id) {
        if (!confirm('Sync PPPoE data dari router ini?')) return;
        var btn = event.target;
        btn.disabled = true;
        btn.textContent = '⏳ Syncing...';
        fetch('/radius/router/' + id + '/sync', {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken},
        })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            alert(res.message || 'Sync selesai');
            if (res.status === 'success') location.reload();
        })
        .catch(function() { alert('Gagal sync'); })
        .finally(function() { btn.disabled = false; btn.textContent = '🔄 Sync'; });
    }
    </script>
</body>
</html>
