<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Services\PermissionService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class IsolirController extends Controller
{
    public function __construct(private PermissionService $permissionService) {}

    public function index(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;

        $isolated = Customer::with(['package', 'area'])
            ->where('is_isolated', true)
            ->orderBy('isolated_since')
            ->paginate(25);

        $candidates = Customer::with('package')
            ->where('status', 'active')
            ->where('is_isolated', false)
            ->orderBy('name')
            ->get();

        $stats = [
            'total_isolated' => Customer::where('is_isolated', true)->count(),
            'total_active' => Customer::where('status', 'active')->where('is_isolated', false)->count(),
        ];

        return Inertia::render('Isolir/Index', compact('capabilities', 'isolated', 'candidates', 'stats'));
    }

    public function isolate(Request $request, Customer $customer)
    {
        $customer->update(['is_isolated' => true, 'isolated_since' => now()]);
        return back()->with('success', "{$customer->name} berhasil diisolir.");
    }

    public function release(Request $request, Customer $customer)
    {
        $customer->update(['is_isolated' => false, 'isolated_since' => null]);
        return back()->with('success', "{$customer->name} berhasil dilepas dari isolir.");
    }
}
