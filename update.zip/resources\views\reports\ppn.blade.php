@extends('layouts.app')
@section('title', 'Laporan PPN')
@section('content')
<div style="margin-bottom:20px;"><h1 style="font-size:22px; font-weight:700;">📊 Laporan PPN</h1><p style="color:var(--text-muted); font-size:14px;">Periode {{ \Carbon\Carbon::parse($month.'-01')->locale('id')->isoFormat('MMMM YYYY') }}</p></div>
<div class="kpi-grid"><div class="kpi-card" style="background:linear-gradient(135deg,#f59e0b,#fbbf24);"><div class="kpi-label">Total PPN</div><div class="kpi-value" style="color:#fef3c7">Rp {{ number_format($totalPpn) }}</div><div class="kpi-sub">{{ $payments->count() }} transaksi ber-PPN</div></div></div>
<div class="card" style="padding:16px; margin-bottom:16px;"><form method="GET" style="display:flex; gap:10px; align-items:flex-end;"><div><label class="form-label">Periode</label><input type="month" name="month" value="{{ $month }}" class="form-input"></div><button type="submit" class="btn-primary">🔍 Filter</button></form></div>
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>#</th><th>Tgl</th><th>Nama</th><th style="text-align:right">Jumlah</th><th style="text-align:right">PPN</th></tr></thead>
        <tbody>
        @forelse($payments as $i => $p)
        <tr><td>{{ $i+1 }}</td><td style="font-size:12px;color:var(--text-muted)">{{ $p->payment_date->format('d/m/Y') }}</td><td><strong>{{ $p->customer?->name ?? '-' }}</strong></td><td style="text-align:right;color:#86efac">{{ number_format($p->paid_amount) }}</td><td style="text-align:right;color:#fcd34d;font-weight:600">{{ number_format($p->ppn_amount) }}</td></tr>
        @empty
        <tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Tidak ada data PPN.</td></tr>
        @endforelse
        @if($payments->count())<tr style="border-top:2px solid var(--border);font-weight:700;background:rgba(245,158,11,.06);"><td colspan="3" style="text-align:right">Total:</td><td style="text-align:right;color:#86efac">{{ number_format($payments->sum('paid_amount')) }}</td><td style="text-align:right;color:#fcd34d">{{ number_format($totalPpn) }}</td></tr>@endif
        </tbody>
    </table>
</div>
@endsection
@push('styles')<style>.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px}.kpi-card{padding:20px;border-radius:var(--radius);border:1px solid var(--border)}.kpi-label{font-size:13px;color:rgba(255,255,255,.85);margin-bottom:4px}.kpi-value{font-size:24px;font-weight:800}.kpi-sub{font-size:12px;color:rgba(255,255,255,.7);margin-top:4px}.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}.form-label{display:block;font-size:12px;color:var(--text-muted);margin-bottom:4px;font-weight:600}.form-input{padding:8px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg-body);color:var(--text);font-size:14px;font-family:inherit}.btn-primary{padding:8px 16px;background:var(--accent);color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit}.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:10px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}</style>@endpush
