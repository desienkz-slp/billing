@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><rect x="2" y="14" width="20" height="6" rx="2"/><path d="M6 14V8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v6"/></svg>
Config Router
@endsection
@section('content')
<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.7fr);gap:16px;align-items:flex-start">
    {{-- FORM TAMBAH / EDIT --}}
    <div class="cfg-card">
        <div class="cfg-card-title" id="routerFormTitle">➕ Tambah Router</div>
        <div id="routerFormMsg" class="cfg-alert" style="margin-bottom:8px"></div>
        <input type="hidden" id="rId">
        <div style="display:flex;flex-direction:column;gap:10px">
            <div>
                <div class="cfg-label">Nama Router</div>
                <input type="text" id="rNama" class="cfg-input" placeholder="Contoh: Router Utama">
            </div>
            <div>
                <div class="cfg-label">Host / IP</div>
                <input type="text" id="rHost" class="cfg-input" placeholder="192.168.1.1">
            </div>
            <div>
                <div class="cfg-label">Username</div>
                <input type="text" id="rUser" class="cfg-input" placeholder="admin" autocomplete="off">
            </div>
            <div>
                <div class="cfg-label">Password <span id="rPassHint" style="color:var(--text-muted);display:none">(kosong = tidak diubah)</span></div>
                <input type="password" id="rPass" class="cfg-input" placeholder="••••••" autocomplete="new-password">
            </div>
            <div class="cfg-grid-2">
                <div>
                    <div class="cfg-label">Port API</div>
                    <input type="number" id="rPort" class="cfg-input" placeholder="8728" value="8728">
                </div>
                <div>
                    <div class="cfg-label">Port FTP</div>
                    <input type="number" id="rFtpPort" class="cfg-input" placeholder="21" value="21">
                </div>
            </div>
            {{-- Toggle FreeRADIUS --}}
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin-top:4px">
                <input type="checkbox" id="rUseRadius" style="accent-color:#a78bfa">
                <span class="cfg-label" style="margin:0">FreeRADIUS <span style="color:var(--text-muted);font-weight:400">(billing tidak buat PPPoE di MikroTik)</span></span>
            </label>
            <div id="rRadiusWrap" style="display:none">
                <div class="cfg-label">RADIUS Secret</div>
                <input type="text" id="rRadiusSecret" class="cfg-input" placeholder="MikroTik123!" autocomplete="off">
            </div>
            {{-- Toggle Auto Backup --}}
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                <input type="checkbox" id="rAutoBackup" style="accent-color:var(--success)">
                <span class="cfg-label" style="margin:0">Auto Backup</span>
            </label>
            <div style="display:flex;gap:8px;margin-top:4px">
                <button id="rSaveBtn" class="cfg-btn cfg-btn-primary" style="flex:1" onclick="saveRouter()">✓ Simpan</button>
                <button id="rCancelBtn" class="cfg-btn cfg-btn-secondary" style="display:none" onclick="resetRouterForm()">✕ Batal</button>
            </div>
        </div>
    </div>

    {{-- DAFTAR ROUTER --}}
    <div class="cfg-card">
        <div class="cfg-card-title">📋 Daftar Router</div>
        <div id="routerListMsg" class="cfg-alert" style="margin-bottom:8px"></div>
        <div style="max-height:60vh;overflow:auto">
            <table class="cfg-table">
                <thead>
                    <tr>
                        <th>#</th><th>Nama</th><th>Host</th><th>Port</th>
                        <th style="text-align:center">Status</th>
                        <th style="text-align:center">RADIUS</th>
                        <th style="text-align:center">Aksi</th>
                    </tr>
                </thead>
                <tbody id="routerTb">
                    <tr><td colspan="7" style="text-align:center;color:var(--text-muted)">Memuat…</td></tr>
                </tbody>
            </table>
        </div>
        <p style="font-size:.75rem;color:var(--text-muted);margin-top:12px">
            ℹ️ Router <span style="color:var(--success);font-weight:600">Aktif</span> akan muncul sebagai pilihan di menu Master Paket.
        </p>
    </div>
</div>

{{-- MODAL: Show Config --}}
<div id="configModal" class="cfg-modal-overlay">
    <div class="cfg-modal" style="max-width:700px">
        <div class="cfg-modal-header">
            <h3>📄 Konfigurasi Router</h3>
            <button class="cfg-modal-close" onclick="document.getElementById('configModal').classList.remove('show')">&times;</button>
        </div>
        <pre id="configTextArea" style="margin:0;font-size:.78rem;color:var(--text-primary);white-space:pre-wrap;word-break:break-all;background:rgba(0,0,0,.4);padding:16px;border-radius:8px;max-height:50vh;overflow-y:auto">Memuat…</pre>
        <div style="margin-top:12px;display:flex;gap:8px">
            <button class="cfg-btn cfg-btn-primary" onclick="copyConfig()">📋 Salin ke Clipboard</button>
        </div>
    </div>
</div>

{{-- MODAL: Restore --}}
<div id="restoreModal" class="cfg-modal-overlay">
    <div class="cfg-modal" style="max-width:640px">
        <div class="cfg-modal-header">
            <h3>⬆️ Restore dari Backup</h3>
            <button class="cfg-modal-close" onclick="document.getElementById('restoreModal').classList.remove('show')">&times;</button>
        </div>
        <input type="hidden" id="restoreRouterId">
        <div style="margin-bottom:12px">
            <div class="cfg-label">Pilih backup:</div>
            <select id="restoreBackupSelect" class="cfg-input"><option value="">Memuat…</option></select>
        </div>
        <pre id="restoreConfigPreview" style="display:none;margin:0;font-size:.78rem;color:var(--text-primary);white-space:pre-wrap;word-break:break-all;background:rgba(0,0,0,.4);padding:16px;border-radius:8px;max-height:40vh;overflow-y:auto"></pre>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
            <button class="cfg-btn cfg-btn-primary" onclick="loadRestoreConfig()">📥 Muat & Tampilkan</button>
            <button id="restoreCopyBtn" class="cfg-btn cfg-btn-secondary" style="display:none" onclick="copyRestoreConfig()">📋 Salin</button>
            <button id="restoreDownloadBtn" class="cfg-btn cfg-btn-secondary" style="display:none" onclick="downloadBackup()">💾 Download .rsc</button>
        </div>
        <p style="font-size:.75rem;color:var(--text-muted);margin-top:8px">Salin config lalu paste di terminal MikroTik atau Winbox untuk restore manual.</p>
    </div>
</div>

@push('styles')
<style>
    .r-btn{display:inline-flex;align-items:center;gap:3px;padding:3px 8px;border-radius:6px;border:1px solid var(--border);background:rgba(0,0,0,.3);color:var(--text-secondary);font-size:.72rem;cursor:pointer;transition:all .15s;font-family:inherit}
    .r-btn:hover{background:rgba(255,255,255,.08);color:var(--text-primary)}
    .r-btn.edit{border-color:rgba(14,165,233,.5)}
    .r-btn.del{border-color:rgba(239,68,68,.5)}
    .r-btn.test{border-color:rgba(168,85,247,.5)}
    .r-btn.config{border-color:rgba(59,130,246,.5)}
    .r-btn.backup{border-color:rgba(34,197,94,.5)}
    .r-btn.restore{border-color:rgba(249,115,22,.5)}
    .r-btn.toggle-on{border-color:rgba(234,179,8,.5);color:#fde047}
    .r-btn.toggle-off{border-color:rgba(34,197,94,.5)}
    .badge-on{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.4);color:#4ade80;font-size:.7rem;font-weight:600}
    .badge-off{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(100,116,139,.08);border:1px solid rgba(100,116,139,.3);color:var(--text-muted);font-size:.7rem}
    .badge-radius{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(167,139,250,.1);border:1px solid rgba(167,139,250,.35);color:#a78bfa;font-size:.7rem;font-weight:600}
    .badge-local{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(100,116,139,.08);border:1px solid rgba(100,116,139,.3);color:var(--text-muted);font-size:.7rem}
    @media(max-width:900px){
        div[style*="grid-template-columns:minmax(0,1fr) minmax(0,1.7fr)"]{grid-template-columns:1fr !important}
    }
</style>
@endpush

@push('scripts')
<script>
const CSRF = '{{ csrf_token() }}';
const ROUTES = {
    list: '{{ route("config.router") }}',
    store: '{{ route("config.router.store") }}',
    update: id => `/config/router/${id}`,
    destroy: id => `/config/router/${id}`,
    toggle: id => `/config/router/${id}/toggle`,
    test: id => `/config/router/${id}/test`,
};
let editing = false;

// Toggle RADIUS secret visibility
document.getElementById('rUseRadius').addEventListener('change', function(){
    document.getElementById('rRadiusWrap').style.display = this.checked ? 'block' : 'none';
});

function resetRouterForm(){
    editing = false;
    document.getElementById('rId').value = '';
    ['rNama','rHost','rUser','rPass','rRadiusSecret'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('rPort').value = '8728';
    document.getElementById('rFtpPort').value = '21';
    document.getElementById('rUseRadius').checked = false;
    document.getElementById('rAutoBackup').checked = false;
    document.getElementById('rRadiusWrap').style.display = 'none';
    document.getElementById('routerFormTitle').textContent = '➕ Tambah Router';
    document.getElementById('rCancelBtn').style.display = 'none';
    document.getElementById('rPassHint').style.display = 'none';
    hideMsg('routerFormMsg');
}

function loadRouters(){
    fetch(ROUTES.list, {headers:{'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res => {
        const tb = document.getElementById('routerTb');
        if(!res.data || !res.data.length){
            tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">Belum ada router. Tambahkan di form kiri.</td></tr>';
            return;
        }
        tb.innerHTML = res.data.map((r,i) => {
            const active = r.is_active;
            const radius = r.use_radius;
            return `<tr>
                <td>${i+1}</td>
                <td style="font-weight:${active?'600':'400'};color:${active?'var(--text-primary)':'var(--text-muted)'}">${esc(r.name)}</td>
                <td><code>${esc(r.host)}</code></td>
                <td>${r.port}</td>
                <td style="text-align:center">${active?'<span class="badge-on">● Aktif</span>':'<span class="badge-off">Nonaktif</span>'}</td>
                <td style="text-align:center">${radius?'<span class="badge-radius">🛡 RADIUS</span>':'<span class="badge-local">Local</span>'}</td>
                <td style="text-align:center">
                    <div style="display:flex;gap:4px;justify-content:center;flex-wrap:wrap">
                        <button class="r-btn config" onclick="showConfig(${r.id})">📄</button>
                        <button class="r-btn backup" onclick="backupRouter(${r.id},'${esc(r.name)}')">☁️</button>
                        <button class="r-btn restore" onclick="openRestore(${r.id})">⬆️</button>
                        <button class="r-btn test" onclick="testRouter(${r.id},'${esc(r.name)}')">🔌</button>
                        ${active
                            ?`<button class="r-btn toggle-on" onclick="toggleRouter(${r.id},'${esc(r.name)}')">⏸</button>`
                            :`<button class="r-btn toggle-off" onclick="toggleRouter(${r.id},'${esc(r.name)}')">▶</button>`}
                        <button class="r-btn edit" onclick='editRouter(${JSON.stringify(r)})'>✏️</button>
                        <button class="r-btn del" onclick="deleteRouter(${r.id},'${esc(r.name)}')">🗑</button>
                    </div>
                </td>
            </tr>`;
        }).join('');
    })
    .catch(() => {
        document.getElementById('routerTb').innerHTML = '<tr><td colspan="7" style="text-align:center;color:#f87171">Gagal memuat data.</td></tr>';
    });
}

function saveRouter(){
    const id = document.getElementById('rId').value;
    const payload = {
        name: document.getElementById('rNama').value.trim(),
        host: document.getElementById('rHost').value.trim(),
        username: document.getElementById('rUser').value.trim(),
        password: document.getElementById('rPass').value,
        port: parseInt(document.getElementById('rPort').value || '8728'),
        ftp_port: parseInt(document.getElementById('rFtpPort').value || '21'),
        use_radius: document.getElementById('rUseRadius').checked,
        radius_secret: document.getElementById('rRadiusSecret').value.trim() || null,
        auto_backup: document.getElementById('rAutoBackup').checked,
    };

    if(!payload.name || !payload.host || !payload.username || (!editing && !payload.password) || !payload.port){
        showMsg('routerFormMsg','err','Nama, host, username, password, dan port wajib diisi.');
        return;
    }

    const url = editing ? ROUTES.update(id) : ROUTES.store;
    const method = editing ? 'PUT' : 'POST';

    const btn = document.getElementById('rSaveBtn');
    btn.disabled = true; btn.textContent = 'Menyimpan…';

    fetch(url, {
        method, headers:{'Content-Type':'application/json','X-CSRF-TOKEN':CSRF,'Accept':'application/json'},
        body: JSON.stringify(payload)
    })
    .then(r=>r.json())
    .then(res => {
        if(res.status==='success'){ showMsg('routerFormMsg','ok',res.message); resetRouterForm(); loadRouters(); }
        else showMsg('routerFormMsg','err',res.message||'Gagal menyimpan.');
    })
    .catch(()=>showMsg('routerFormMsg','err','Gagal menghubungi server.'))
    .finally(()=>{ btn.disabled=false; btn.textContent='✓ Simpan'; });
}

function editRouter(r){
    editing = true;
    document.getElementById('rId').value = r.id;
    document.getElementById('rNama').value = r.name;
    document.getElementById('rHost').value = r.host;
    document.getElementById('rUser').value = r.username || '';
    document.getElementById('rPass').value = '';
    document.getElementById('rPort').value = r.port;
    document.getElementById('rFtpPort').value = r.ftp_port || 21;
    document.getElementById('rUseRadius').checked = !!r.use_radius;
    document.getElementById('rAutoBackup').checked = !!r.auto_backup;
    document.getElementById('rRadiusWrap').style.display = r.use_radius ? 'block' : 'none';
    document.getElementById('rRadiusSecret').value = '';
    document.getElementById('routerFormTitle').textContent = '✏️ Edit Router';
    document.getElementById('rCancelBtn').style.display = 'inline-flex';
    document.getElementById('rPassHint').style.display = 'inline';
    hideMsg('routerFormMsg');
    window.scrollTo({top:0,behavior:'smooth'});
}

function deleteRouter(id, name){
    if(!confirm(`Hapus router "${name}"?`)) return;
    fetch(ROUTES.destroy(id), {method:'DELETE',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{ showMsg('routerListMsg',res.status==='success'?'ok':'err',res.message); if(res.status==='success') loadRouters(); })
    .catch(()=>showMsg('routerListMsg','err','Gagal menghubungi server.'));
}

function toggleRouter(id, name){
    if(!confirm(`Toggle status router "${name}"?`)) return;
    fetch(ROUTES.toggle(id), {method:'POST',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{ showMsg('routerListMsg',res.status==='success'?'ok':'err',res.message); if(res.status==='success') loadRouters(); })
    .catch(()=>showMsg('routerListMsg','err','Gagal.'));
}

function testRouter(id, name){
    showMsg('routerListMsg','info',`Mengecek koneksi ke "${name}"…`);
    fetch(ROUTES.test(id), {method:'POST',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>showMsg('routerListMsg',res.status==='success'?'ok':'err',res.message))
    .catch(()=>showMsg('routerListMsg','err','Gagal menghubungi server.'));
}

function showMsg(elId, cls, msg){
    const el = document.getElementById(elId);
    el.className = 'cfg-alert ' + cls;
    el.textContent = msg;
    el.style.display = 'block';
    if(cls !== 'info') setTimeout(()=>{ el.style.display='none'; }, 5000);
}
function hideMsg(elId){ document.getElementById(elId).style.display='none'; }
function esc(s){ return (s||'').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

// ==================== CONFIG ====================
function showConfig(id){
    document.getElementById('configTextArea').textContent = 'Memuat konfigurasi…';
    document.getElementById('configModal').classList.add('show');
    fetch(`/config/router/${id}/config`, {headers:{'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{
        document.getElementById('configTextArea').textContent = res.status==='success' ? (res.config||'(kosong)') : ('Error: '+(res.message||'-'));
    })
    .catch(()=>{ document.getElementById('configTextArea').textContent = 'Gagal memuat config.'; });
}
function copyConfig(){
    const t = document.getElementById('configTextArea').textContent;
    copyToClipboard(t);
    document.getElementById('configModal').classList.remove('show');
    showMsg('routerListMsg','ok','Config disalin ke clipboard.');
}

// ==================== BACKUP ====================
function backupRouter(id, name){
    if(!confirm(`Backup config router "${name}"?`)) return;
    showMsg('routerListMsg','info',`Menyimpan backup "${name}"…`);
    fetch(`/config/router/${id}/backup`, {method:'POST',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>showMsg('routerListMsg',res.status==='success'?'ok':'err',res.message))
    .catch(()=>showMsg('routerListMsg','err','Gagal menyimpan backup.'));
}

// ==================== RESTORE ====================
function openRestore(id){
    document.getElementById('restoreRouterId').value = id;
    document.getElementById('restoreBackupSelect').innerHTML = '<option value="">Memuat…</option>';
    document.getElementById('restoreConfigPreview').style.display = 'none';
    document.getElementById('restoreCopyBtn').style.display = 'none';
    document.getElementById('restoreDownloadBtn').style.display = 'none';
    document.getElementById('restoreModal').classList.add('show');
    fetch(`/config/router/${id}/backups`, {headers:{'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{
        let opts = '<option value="">-- Pilih backup --</option>';
        if(res.data && res.data.length) res.data.forEach(b=>{
            opts+=`<option value="${b.id}">${b.config_name}</option>`;
        });
        else opts = '<option value="">Tidak ada backup</option>';
        document.getElementById('restoreBackupSelect').innerHTML = opts;
    })
    .catch(()=>{ document.getElementById('restoreBackupSelect').innerHTML = '<option value="">Gagal memuat</option>'; });
}
function loadRestoreConfig(){
    const rid = document.getElementById('restoreRouterId').value;
    const bid = document.getElementById('restoreBackupSelect').value;
    if(!bid){ showMsg('routerListMsg','err','Pilih backup dulu.'); return; }
    fetch(`/config/router/${rid}/restore/${bid}`, {headers:{'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{
        const pre = document.getElementById('restoreConfigPreview');
        if(res.status==='success'){
            pre.textContent = res.config||'';
            pre.style.display='block';
            document.getElementById('restoreCopyBtn').style.display='inline-flex';
            document.getElementById('restoreDownloadBtn').style.display='inline-flex';
        } else {
            pre.textContent = 'Error: '+(res.message||'-');
            pre.style.display='block';
        }
    })
    .catch(()=>{ document.getElementById('restoreConfigPreview').textContent='Gagal memuat.'; document.getElementById('restoreConfigPreview').style.display='block'; });
}
function downloadBackup(){
    const rid = document.getElementById('restoreRouterId').value;
    const bid = document.getElementById('restoreBackupSelect').value;
    if(!bid){ showMsg('routerListMsg','err','Pilih backup dulu.'); return; }
    window.open(`/config/router/${rid}/download/${bid}`, '_blank');
}
function copyRestoreConfig(){
    const t = document.getElementById('restoreConfigPreview').textContent;
    if(!t){ showMsg('routerListMsg','err','Muat config dulu.'); return; }
    copyToClipboard(t);
    document.getElementById('restoreModal').classList.remove('show');
    showMsg('routerListMsg','ok','Config disalin. Paste di Terminal/Winbox untuk restore.');
}

// Clipboard fallback for HTTP (non-HTTPS)
function copyToClipboard(text){
    if(navigator.clipboard && window.isSecureContext){
        navigator.clipboard.writeText(text);
        return;
    }
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;left:-9999px;top:-9999px';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
}

// Close modals on overlay click
['configModal','restoreModal'].forEach(id=>{
    document.getElementById(id).addEventListener('click', function(e){ if(e.target===this) this.classList.remove('show'); });
});

// Init
loadRouters();
</script>
@endpush
@endsection
