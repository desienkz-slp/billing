@extends('layouts.app')
@section('title', 'Arus Kas')
@section('content')
@php $monthLabel = \Carbon\Carbon::parse($month.'-01')->locale('id')->isoFormat('MMMM YYYY'); @endphp
<div style="margin-bottom:20px;"><h1 style="font-size:22px; font-weight:700;">↔️ Arus Kas</h1><p style="color:var(--text-muted); font-size:14px;">{{ $monthLabel }}</p></div>
<div class="card" style="padding:16px; margin-bottom:16px;"><form method="GET" style="display:flex; gap:10px; align-items:flex-end;"><div><label class="form-label">Periode</label><input type="month" name="month" value="{{ $month }}" class="form-input"></div><button type="submit" class="btn-primary">🔍 Filter</button></form></div>
<div class="kpi-grid">
    <div class="kpi-card" style="background:linear-gradient(135deg,#047857,#10b981);"><div class="kpi-label">Total Pemasukan</div><div class="kpi-value">Rp {{ number_format($totalMasuk) }}</div></div>
    <div class="kpi-card" style="background:linear-gradient(135deg,#7f1d1d,#b91c1c);"><div class="kpi-label">Total Pengeluaran</div><div class="kpi-value" style="color:#fca5a5">Rp {{ number_format($totalKeluar) }}</div></div>
    @php $selisih = $totalMasuk - $totalKeluar; @endphp
    <div class="kpi-card" style="background:linear-gradient(135deg,#0e7490,#06b6d4);"><div class="kpi-label">Selisih</div><div class="kpi-value" style="color:{{ $selisih >= 0 ? '#4ade80' : '#fca5a5' }}">Rp {{ number_format($selisih) }}</div></div>
</div>
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>Tanggal</th><th style="text-align:right;color:#4ade80">Masuk</th><th style="text-align:right;color:#fca5a5">Keluar</th></tr></thead>
        <tbody>
        @php $allDates = collect(); $pemasukanMap = $pemasukan->keyBy('tanggal'); $kelMap = $pengeluaranHarian->keyBy('tanggal'); $allDates = $pemasukanMap->keys()->merge($kelMap->keys())->unique()->sort(); @endphp
        @forelse($allDates as $tgl)
        @php $masuk = $pemasukanMap[$tgl]->total ?? 0; $keluar = $kelMap[$tgl]->total ?? 0; @endphp
        <tr><td>{{ \Carbon\Carbon::parse($tgl)->format('d/m/Y') }}</td><td style="text-align:right;color:#86efac;font-weight:{{ $masuk > 0 ? '600' : '400' }}">{{ $masuk > 0 ? number_format($masuk) : '-' }}</td><td style="text-align:right;color:#fca5a5;font-weight:{{ $keluar > 0 ? '600' : '400' }}">{{ $keluar > 0 ? number_format($keluar) : '-' }}</td></tr>
        @empty
        <tr><td colspan="3" style="text-align:center;padding:40px;color:var(--text-muted);">Tidak ada data.</td></tr>
        @endforelse
        @if($allDates->count())<tr style="border-top:2px solid var(--border);font-weight:700;"><td>Total</td><td style="text-align:right;color:#4ade80">{{ number_format($totalMasuk) }}</td><td style="text-align:right;color:#fca5a5">{{ number_format($totalKeluar) }}</td></tr>@endif
        </tbody>
    </table>
</div>
@endsection
@push('styles')<style>.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px}.kpi-card{padding:20px;border-radius:var(--radius);border:1px solid var(--border)}.kpi-label{font-size:13px;color:rgba(255,255,255,.85);margin-bottom:4px}.kpi-value{font-size:24px;font-weight:800;color:#fff}.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}.form-label{display:block;font-size:12px;color:var(--text-muted);margin-bottom:4px;font-weight:600}.form-input{padding:8px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg-body);color:var(--text);font-size:14px;font-family:inherit}.btn-primary{padding:8px 16px;background:var(--accent);color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit}.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:10px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}</style>@endpush
