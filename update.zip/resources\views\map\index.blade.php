@php
    $user = auth()->user()?->load('role', 'tenant');
    $tenant = $user?->tenant;
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Peta Pelanggan · {{ $tenant->name ?? 'Map' }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/vendor/leaflet/leaflet.css" />
    <link rel="stylesheet" href="/vendor/leaflet-markercluster/MarkerCluster.css" />
    <link rel="stylesheet" href="/vendor/leaflet-markercluster/MarkerCluster.Default.css" />
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{--bg:#0b1120;--bg-card:rgba(15,23,42,.85);--border:rgba(255,255,255,.08);--text:#e2e8f0;--muted:#64748b;--accent:#0ea5e9;--success:#22c55e;--danger:#ef4444;--warning:#f59e0b}
        body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text);height:100vh;overflow:hidden;display:flex;flex-direction:column}

        /* Header */
        .map-header{display:flex;align-items:center;justify-content:space-between;padding:12px 20px;background:var(--bg-card);border-bottom:1px solid var(--border);backdrop-filter:blur(12px);z-index:1000}
        .map-header h1{font-size:1rem;font-weight:700;display:flex;align-items:center;gap:8px}
        .map-header h1 svg{width:20px;height:20px;color:var(--accent)}
        .map-header-actions{display:flex;gap:8px;align-items:center}
        .map-btn{padding:6px 14px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.06);color:var(--text);font-size:.8rem;font-weight:500;cursor:pointer;transition:all .2s;font-family:inherit;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
        .map-btn:hover{background:rgba(255,255,255,.12)}
        .map-btn-primary{background:linear-gradient(135deg,#0ea5e9,#6366f1);border:none;color:#fff}

        /* Map container */
        .map-wrapper{flex:1;position:relative;display:flex}
        #map{flex:1;z-index:1}

        /* Filter panel */
        .filter-panel{width:280px;background:var(--bg-card);border-right:1px solid var(--border);backdrop-filter:blur(12px);overflow-y:auto;padding:16px;z-index:500;transition:transform .3s}
        .filter-panel.collapsed{transform:translateX(-100%);position:absolute;left:0;top:0;bottom:0}
        .filter-title{font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:600;margin:12px 0 6px}
        .filter-select{width:100%;padding:8px 10px;background:rgba(0,0,0,.3);border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:.82rem;font-family:inherit;outline:none;margin-bottom:8px}
        .filter-select:focus{border-color:var(--accent)}
        .filter-select option{background:#0f172a}

        /* Stats */
        .filter-stats{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}
        .stat-card{background:rgba(0,0,0,.3);border-radius:8px;padding:10px;text-align:center}
        .stat-value{font-size:1.3rem;font-weight:700;color:#fff}
        .stat-label{font-size:.68rem;color:var(--muted);margin-top:2px}

        /* Legend */
        .legend{margin-top:16px}
        .legend-item{display:flex;align-items:center;gap:8px;font-size:.78rem;color:var(--text);margin-bottom:6px}
        .legend-dot{width:12px;height:12px;border-radius:50%;flex-shrink:0}

        /* Override Leaflet dark */
        .leaflet-container{background:var(--bg)!important}
        .leaflet-popup-content-wrapper{background:var(--bg-card)!important;color:var(--text)!important;border-radius:12px!important;backdrop-filter:blur(12px);border:1px solid var(--border)}
        .leaflet-popup-tip{background:var(--bg-card)!important}
        .leaflet-popup-content{margin:12px 16px!important;font-family:'Inter',sans-serif!important;font-size:.82rem!important}
        .leaflet-popup-close-button{color:var(--muted)!important}
        .leaflet-control-zoom a{background:var(--bg-card)!important;color:var(--text)!important;border-color:var(--border)!important}
        .leaflet-control-attribution{background:rgba(0,0,0,.6)!important;color:var(--muted)!important;font-size:.6rem!important}
        .leaflet-control-attribution a{color:var(--accent)!important}

        /* Marker cluster override */
        .marker-cluster-small,.marker-cluster-medium,.marker-cluster-large{background:rgba(14,165,233,.3)!important}
        .marker-cluster-small div,.marker-cluster-medium div,.marker-cluster-large div{background:rgba(14,165,233,.7)!important;color:#fff!important;font-weight:600!important;font-family:'Inter',sans-serif!important}

        /* Mobile */
        .filter-toggle{display:none}
        @media(max-width:768px){
            .filter-panel{position:absolute;left:0;top:0;bottom:0;transform:translateX(-100%)}
            .filter-panel.show{transform:translateX(0)}
            .filter-toggle{display:block}
        }

        /* Popup */
        .popup-name{font-weight:700;font-size:.9rem;color:#fff;margin-bottom:4px}
        .popup-badge{display:inline-block;padding:2px 8px;border-radius:99px;font-size:.68rem;font-weight:600}
        .popup-badge.active{background:rgba(34,197,94,.15);color:#4ade80}
        .popup-badge.isolated{background:rgba(239,68,68,.15);color:#f87171}
        .popup-badge.inactive{background:rgba(100,116,139,.15);color:#94a3b8}
        .popup-row{display:flex;justify-content:space-between;margin-top:4px;font-size:.78rem}
        .popup-row .label{color:var(--muted)}
    </style>
</head>
<body>
    <header class="map-header">
        <h1>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            Peta Pelanggan
            <span style="font-weight:400;color:var(--muted);font-size:.8rem">· {{ $tenant->name ?? '' }}</span>
        </h1>
        <div class="map-header-actions">
            <button class="map-btn filter-toggle" onclick="toggleFilter()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
                Filter
            </button>
            <span style="font-size:.78rem;color:var(--muted)" id="markerCount">—</span>
            <a href="{{ route('app-gateway') }}" class="map-btn">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
                Kembali
            </a>
        </div>
    </header>

    <div class="map-wrapper">
        <aside class="filter-panel" id="filterPanel">
            <div class="filter-title">Filter</div>
            <select class="filter-select" id="filterArea" onchange="loadMarkers()">
                <option value="">Semua Area</option>
                @foreach($areas as $a)
                <option value="{{ $a->id }}">{{ $a->name }}</option>
                @endforeach
            </select>
            <select class="filter-select" id="filterStatus" onchange="loadMarkers()">
                <option value="">Semua Status</option>
                <option value="active">Aktif</option>
                <option value="isolated">Terisolir</option>
                <option value="inactive">Tidak Aktif</option>
            </select>
            <select class="filter-select" id="filterPackage" onchange="loadMarkers()">
                <option value="">Semua Paket</option>
                @foreach($packages as $p)
                <option value="{{ $p->id }}">{{ $p->name }}</option>
                @endforeach
            </select>

            <div class="filter-title">Layer</div>
            <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;margin-bottom:4px">
                <input type="checkbox" id="showCustomers" checked onchange="toggleLayer('customers')" style="accent-color:var(--accent)"> Pelanggan
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;margin-bottom:4px">
                <input type="checkbox" id="showOdcs" checked onchange="toggleLayer('odcs')" style="accent-color:#f97316"> ODC
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;margin-bottom:4px">
                <input type="checkbox" id="showOdps" checked onchange="toggleLayer('odps')" style="accent-color:var(--accent)"> ODP
            </label>

            <div class="filter-stats">
                <div class="stat-card">
                    <div class="stat-value" id="statCustomers">{{ $totalCustomers }}</div>
                    <div class="stat-label">Pelanggan</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="statOdcs">{{ $totalOdcs }}</div>
                    <div class="stat-label">ODC</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="statOdps">{{ $totalOdps }}</div>
                    <div class="stat-label">ODP</div>
                </div>
            </div>

            <div class="legend">
                <div class="filter-title">Legenda</div>
                <div class="legend-item"><div class="legend-dot" style="background:var(--success)"></div> Pelanggan Aktif</div>
                <div class="legend-item"><div class="legend-dot" style="background:var(--danger)"></div> Pelanggan Terisolir</div>
                <div class="legend-item"><div class="legend-dot" style="background:var(--muted)"></div> Pelanggan Tidak Aktif</div>
                <div class="legend-item"><div class="legend-dot" style="background:#f97316;transform:rotate(45deg);border-radius:2px"></div> ODC</div>
                <div class="legend-item"><div class="legend-dot" style="background:var(--accent)"></div> ODP</div>
            </div>
        </aside>
        <div id="map"></div>
    </div>

    <script src="/vendor/leaflet/leaflet.js"></script>
    <script src="/vendor/leaflet-markercluster/leaflet.markercluster.js"></script>
    <script>
    var map = L.map('map', {
        center: [-8.0954, 112.1609], // Blitar default
        zoom: 13,
        zoomControl: true,
    });

    // Google Maps hybrid tile layer
    var googleStreets = L.tileLayer('https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
        maxZoom: 20,
        subdomains: ['mt0','mt1','mt2','mt3'],
        attribution: '&copy; Google Maps',
    });
    var googleSatellite = L.tileLayer('https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
        maxZoom: 20,
        subdomains: ['mt0','mt1','mt2','mt3'],
        attribution: '&copy; Google Maps',
    });
    var googleHybrid = L.tileLayer('https://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}', {
        maxZoom: 20,
        subdomains: ['mt0','mt1','mt2','mt3'],
        attribution: '&copy; Google Maps',
    });
    googleHybrid.addTo(map);

    L.control.layers({
        'Google Streets': googleStreets,
        'Google Satellite': googleSatellite,
        'Google Hybrid': googleHybrid,
    }, {}, {position: 'topright'}).addTo(map);

    var customerCluster = L.markerClusterGroup({
        maxClusterRadius: 50,
        spiderfyOnMaxZoom: true,
        showCoverageOnHover: false,
    });
    var odpLayer = L.layerGroup();
    var odcLayer = L.layerGroup();
    map.addLayer(customerCluster);
    map.addLayer(odpLayer);
    map.addLayer(odcLayer);

    function createCircleIcon(color, size) {
        size = size || 10;
        return L.divIcon({
            className: '',
            html: '<div style="width:'+size+'px;height:'+size+'px;border-radius:50%;background:'+color+';border:2px solid rgba(255,255,255,.5);box-shadow:0 0 6px '+color+'"></div>',
            iconSize: [size, size],
            iconAnchor: [size/2, size/2],
        });
    }

    function odpIcon() {
        return L.divIcon({
            className: '',
            html: '<div style="width:14px;height:14px;border-radius:3px;background:var(--accent,#0ea5e9);border:2px solid rgba(255,255,255,.6);box-shadow:0 0 8px rgba(14,165,233,.5)"></div>',
            iconSize: [14, 14],
            iconAnchor: [7, 7],
        });
    }

    function odcIcon() {
        return L.divIcon({
            className: '',
            html: '<div style="width:18px;height:18px;transform:rotate(45deg);border-radius:3px;background:#f97316;border:2px solid rgba(255,255,255,.7);box-shadow:0 0 10px rgba(249,115,22,.6)"></div>',
            iconSize: [18, 18],
            iconAnchor: [9, 9],
        });
    }

    var statusColors = {active: '#22c55e', isolated: '#ef4444', inactive: '#64748b'};
    var statusLabels = {active: 'Aktif', isolated: 'Terisolir', inactive: 'Tidak Aktif'};

    function loadMarkers() {
        var area = document.getElementById('filterArea').value;
        var status = document.getElementById('filterStatus').value;
        var pkg = document.getElementById('filterPackage').value;

        var params = new URLSearchParams();
        if (area) params.set('area_id', area);
        if (status) params.set('status', status);
        if (pkg) params.set('package_id', pkg);

        // Load customers
        if (document.getElementById('showCustomers').checked) {
            fetch('{{ route("map.api.customers") }}?' + params.toString())
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    customerCluster.clearLayers();
                    var data = res.data || [];
                    data.forEach(function(c) {
                        var color = statusColors[c.status] || '#64748b';
                        var marker = L.marker([c.lat, c.lng], {icon: createCircleIcon(color)});
                        marker.bindPopup(
                            '<div class="popup-name">' + c.name + '</div>' +
                            '<span class="popup-badge ' + c.status + '">' + (statusLabels[c.status] || c.status) + '</span>' +
                            '<div class="popup-row"><span class="label">Username</span><span>' + (c.username || '-') + '</span></div>' +
                            '<div class="popup-row"><span class="label">Paket</span><span>' + (c.package || '-') + '</span></div>' +
                            '<div class="popup-row"><span class="label">Speed</span><span>' + (c.speed || '-') + '</span></div>' +
                            '<div class="popup-row"><span class="label">Area</span><span>' + (c.area || '-') + '</span></div>' +
                            '<div class="popup-row"><span class="label">ODP</span><span>' + (c.odp || '-') + '</span></div>' +
                            '<div class="popup-row"><span class="label">Telepon</span><span>' + (c.phone || '-') + '</span></div>' +
                            (c.address ? '<div style="margin-top:6px;font-size:.72rem;color:var(--muted)">' + c.address + '</div>' : '')
                        );
                        customerCluster.addLayer(marker);
                    });
                    document.getElementById('statCustomers').textContent = data.length;
                    updateMarkerCount();
                });
        } else {
            customerCluster.clearLayers();
        }

        // Load ODPs
        if (document.getElementById('showOdps').checked) {
            var odpParams = new URLSearchParams();
            if (area) odpParams.set('area_id', area);
            fetch('{{ route("map.api.odps") }}?' + odpParams.toString())
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    odpLayer.clearLayers();
                    var data = res.data || [];
                    data.forEach(function(o) {
                        var marker = L.marker([o.lat, o.lng], {icon: odpIcon()});
                        var fillPct = o.capacity > 0 ? Math.round((o.used / o.capacity) * 100) : 0;
                        var fillColor = fillPct >= 90 ? 'var(--danger)' : (fillPct >= 70 ? 'var(--warning)' : 'var(--success)');
                        marker.bindPopup(
                            '<div class="popup-name">📦 ' + o.name + '</div>' +
                            '<div class="popup-row"><span class="label">Area</span><span>' + (o.area || '-') + '</span></div>' +
                            '<div class="popup-row"><span class="label">Kapasitas</span><span>' + o.used + '/' + o.capacity + '</span></div>' +
                            '<div class="popup-row"><span class="label">Tersedia</span><span style="color:' + fillColor + '">' + o.available + ' port</span></div>' +
                            '<div style="margin-top:6px;height:4px;background:rgba(255,255,255,.1);border-radius:2px;overflow:hidden"><div style="width:' + fillPct + '%;height:100%;background:' + fillColor + '"></div></div>'
                        );
                        odpLayer.addLayer(marker);
                    });
                    document.getElementById('statOdps').textContent = data.length;
                    updateMarkerCount();
                });
        } else {
            odpLayer.clearLayers();
        }

        // Load ODCs
        if (document.getElementById('showOdcs').checked) {
            var odcParams = new URLSearchParams();
            if (area) odcParams.set('area_id', area);
            fetch('{{ route("map.api.odcs") }}?' + odcParams.toString())
                .then(function(r) { return r.json(); })
                .then(function(res) {
                    odcLayer.clearLayers();
                    var data = res.data || [];
                    data.forEach(function(o) {
                        var marker = L.marker([o.lat, o.lng], {icon: odcIcon()});
                        var fillPct = o.capacity > 0 ? Math.round((o.used / o.capacity) * 100) : 0;
                        var fillColor = fillPct >= 90 ? 'var(--danger)' : (fillPct >= 70 ? 'var(--warning)' : 'var(--success)');
                        marker.bindPopup(
                            '<div class="popup-name">🗄️ ' + o.name + '</div>' +
                            '<div class="popup-row"><span class="label">Area</span><span>' + (o.area || '-') + '</span></div>' +
                            '<div class="popup-row"><span class="label">Kapasitas</span><span>' + o.used + '/' + o.capacity + '</span></div>' +
                            '<div class="popup-row"><span class="label">Tersedia</span><span style="color:' + fillColor + '">' + o.available + ' port</span></div>' +
                            '<div class="popup-row"><span class="label">ODP</span><span>' + o.odp_count + ' unit</span></div>' +
                            '<div style="margin-top:6px;height:4px;background:rgba(255,255,255,.1);border-radius:2px;overflow:hidden"><div style="width:' + fillPct + '%;height:100%;background:' + fillColor + '"></div></div>'
                        );
                        odcLayer.addLayer(marker);
                    });
                    document.getElementById('statOdcs').textContent = data.length;
                    updateMarkerCount();
                });
        } else {
            odcLayer.clearLayers();
        }
    }

    function toggleLayer(type) {
        loadMarkers();
    }

    function toggleFilter() {
        document.getElementById('filterPanel').classList.toggle('show');
    }

    function updateMarkerCount() {
        var total = customerCluster.getLayers().length + odpLayer.getLayers().length + odcLayer.getLayers().length;
        document.getElementById('markerCount').textContent = total + ' markers';
    }

    // Initial load
    loadMarkers();
    </script>
</body>
</html>
