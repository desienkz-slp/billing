@extends('layouts.app')
@section('title', 'Statistik')
@section('content')
<h1 style="font-size:22px; font-weight:700; margin-bottom:24px;">📊 Statistik</h1>

{{-- Revenue Chart --}}
<div class="card" style="margin-bottom:20px;">
    <h3 class="card-heading">💰 Pendapatan per Bulan (12 bulan terakhir)</h3>
    <div style="display:flex; align-items:flex-end; gap:6px; height:180px; padding-top:16px; overflow-x:auto;">
        @php $maxRev = $revenueMonthly->max('total') ?: 1; @endphp
        @foreach($revenueMonthly as $r)
        <div style="flex:1; min-width:50px; display:flex; flex-direction:column; align-items:center; gap:4px;">
            <div style="font-size:9px; color:var(--text-muted); white-space:nowrap;">{{ number_format($r->total/1000,0) }}K</div>
            <div style="width:100%; max-width:36px; height:{{ max(8, ($r->total/$maxRev)*140) }}px; background:var(--gradient); border-radius:6px 6px 0 0;"></div>
            <div style="font-size:10px; color:var(--text-secondary); font-weight:500;">{{ \Carbon\Carbon::parse($r->period.'-01')->format('M') }}</div>
            <div style="font-size:9px; color:var(--text-muted);">{{ $r->count }}x</div>
        </div>
        @endforeach
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px;">
    {{-- Customer Growth --}}
    <div class="card">
        <h3 class="card-heading">👥 Pertumbuhan Pelanggan</h3>
        <div style="padding-top:12px;">
        @foreach($customerGrowth as $cg)
            <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid var(--border);">
                <span style="font-size:13px;">{{ \Carbon\Carbon::parse($cg->period.'-01')->locale('id')->isoFormat('MMM Y') }}</span>
                <span style="font-weight:600; color:var(--success);">+{{ $cg->count }}</span>
            </div>
        @endforeach
        @if($customerGrowth->isEmpty())
            <p style="color:var(--text-muted); text-align:center; padding:20px;">Belum ada data</p>
        @endif
        </div>
    </div>

    {{-- Package Distribution --}}
    <div class="card">
        <h3 class="card-heading">📦 Distribusi Paket</h3>
        <div style="padding-top:12px;">
        @php $totalPkg = $packageDist->sum('count') ?: 1; @endphp
        @foreach($packageDist as $pd)
            @php $pct = round(($pd->count / $totalPkg) * 100); $colors = ['#6366f1','#8b5cf6','#06b6d4','#22c55e','#f59e0b','#ef4444']; $color = $colors[$loop->index % count($colors)]; @endphp
            <div style="margin-bottom:12px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:13px;">
                    <span>{{ $pd->package?->name ?? 'Unknown' }}</span>
                    <span style="color:var(--text-muted);">{{ $pd->count }} ({{ $pct }}%)</span>
                </div>
                <div style="height:6px; background:var(--border); border-radius:3px; overflow:hidden;">
                    <div style="height:100%; width:{{ $pct }}%; background:{{ $color }}; border-radius:3px;"></div>
                </div>
            </div>
        @endforeach
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
    {{-- Payment Methods --}}
    <div class="card">
        <h3 class="card-heading">💳 Metode Pembayaran (Tahun Ini)</h3>
        <div style="padding-top:12px;">
        @foreach($methodStats as $ms)
        <div style="display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--border);">
            <span style="text-transform:capitalize; font-weight:500;">{{ $ms->payment_method }}</span>
            <span><strong>{{ $ms->count }}x</strong> — Rp {{ number_format($ms->total,0,',','.') }}</span>
        </div>
        @endforeach
        </div>
    </div>

    {{-- Top Collectors --}}
    <div class="card">
        <h3 class="card-heading">🏆 Top Petugas (Bulan Ini)</h3>
        <div style="padding-top:12px;">
        @foreach($topCollectors as $tc)
        <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid var(--border);">
            <div><span style="font-weight:600;">{{ $tc->collector?->name ?? 'Unknown' }}</span></div>
            <div style="text-align:right;"><strong>{{ $tc->count }}x</strong><br><span style="font-size:12px; color:var(--text-muted);">Rp {{ number_format($tc->total,0,',','.') }}</span></div>
        </div>
        @endforeach
        @if($topCollectors->isEmpty())<p style="color:var(--text-muted); text-align:center; padding:20px;">Belum ada data</p>@endif
        </div>
    </div>
</div>
@endsection
@push('styles')
<style>
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow-sm)}
.card-heading{font-size:15px;font-weight:600;margin-bottom:4px}
@media(max-width:768px){div[style*="grid-template-columns:1fr 1fr"]{grid-template-columns:1fr!important}}
</style>
@endpush
