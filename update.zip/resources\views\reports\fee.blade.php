@extends('layouts.app')
@section('title', 'Laporan Fee')
@section('content')
@php $monthLabel = \Carbon\Carbon::parse($month.'-01')->locale('id')->isoFormat('MMMM YYYY'); @endphp
<div style="margin-bottom:20px;"><h1 style="font-size:22px; font-weight:700;">💵 Laporan Fee</h1><p style="color:var(--text-muted); font-size:14px;">{{ $monthLabel }}</p></div>
<div class="card" style="padding:16px; margin-bottom:16px;"><form method="GET" style="display:flex; gap:10px; align-items:flex-end;"><div><label class="form-label">Periode</label><input type="month" name="month" value="{{ $month }}" class="form-input"></div><button type="submit" class="btn-primary">🔍 Filter</button></form></div>
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>#</th><th>Kolektor</th><th style="text-align:right">Jml Transaksi</th><th style="text-align:right">Total Koleksi</th></tr></thead>
        <tbody>
        @forelse($collectors as $i => $c)
        <tr><td>{{ $i+1 }}</td><td><strong>{{ $c->collector?->name ?? 'Unknown' }}</strong><br><span style="font-size:11px;color:var(--text-muted)">{{ $c->collector?->role?->name ?? '' }}</span></td><td style="text-align:right">{{ number_format($c->count) }}</td><td style="text-align:right;color:#86efac;font-weight:600">{{ number_format($c->total) }}</td></tr>
        @empty
        <tr><td colspan="4" style="text-align:center;padding:40px;color:var(--text-muted);">Tidak ada data fee.</td></tr>
        @endforelse
        @if($collectors->count())<tr style="border-top:2px solid var(--border);font-weight:700;"><td colspan="2" style="text-align:right">Total:</td><td style="text-align:right">{{ number_format($collectors->sum('count')) }}</td><td style="text-align:right;color:#4ade80">{{ number_format($collectors->sum('total')) }}</td></tr>@endif
        </tbody>
    </table>
</div>
@endsection
@push('styles')<style>.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}.form-label{display:block;font-size:12px;color:var(--text-muted);margin-bottom:4px;font-weight:600}.form-input{padding:8px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg-body);color:var(--text);font-size:14px;font-family:inherit}.btn-primary{padding:8px 16px;background:var(--accent);color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit}.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:10px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}</style>@endpush
