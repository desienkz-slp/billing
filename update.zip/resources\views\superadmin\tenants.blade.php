@extends('layouts.superadmin')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
Kelola Tenant
@endsection
@section('content')
@if(session('success'))<div class="sa-alert ok">✅ {{ session('success') }}</div>@endif
@if(session('error'))<div class="sa-alert err">❌ {{ session('error') }}</div>@endif

{{-- Stats --}}
<div class="sa-stats">
    <div class="sa-stat">
        <div class="sa-stat-value">{{ $tenants->count() }}</div>
        <div class="sa-stat-label">Total Tenant</div>
    </div>
    <div class="sa-stat">
        <div class="sa-stat-value">{{ $tenants->where('is_active', true)->count() }}</div>
        <div class="sa-stat-label">Aktif</div>
    </div>
    <div class="sa-stat">
        <div class="sa-stat-value">{{ $tenants->sum('users_count') }}</div>
        <div class="sa-stat-label">Total User</div>
    </div>
    <div class="sa-stat">
        <div class="sa-stat-value">{{ $tenants->sum('customers_count') }}</div>
        <div class="sa-stat-label">Total Pelanggan</div>
    </div>
</div>

<div class="sa-grid-2">
    {{-- FORM TAMBAH --}}
    <div class="sa-card">
        <div class="sa-card-title">➕ Tambah Tenant Baru</div>
        <form method="POST" action="{{ route('superadmin.tenants.store') }}">
            @csrf
            <div style="display:flex;flex-direction:column;gap:10px">
                <div style="border-bottom:1px solid var(--border);padding-bottom:10px;margin-bottom:2px">
                    <div style="font-size:.72rem;color:var(--text-muted);text-transform:uppercase;font-weight:600;margin-bottom:8px">Info Tenant</div>
                    <div><div class="sa-label">Nama ISP *</div><input type="text" name="name" class="sa-input" required placeholder="contoh: LadaPala Net Kediri"></div>
                    <div style="margin-top:8px"><div class="sa-label">Slug (URL)</div><input type="text" name="slug" class="sa-input" placeholder="auto dari nama (contoh: ladapala-net-kediri)"></div>
                    <div style="margin-top:8px"><div class="sa-label">Custom Domain</div><input type="text" name="domain" class="sa-input" placeholder="contoh: billing.ladapala.com"></div>
                    <div style="margin-top:8px">
                        <div class="sa-label">Timezone</div>
                        <select name="timezone" class="sa-input">
                            <option value="Asia/Jakarta">WIB (Asia/Jakarta)</option>
                            <option value="Asia/Makassar">WITA (Asia/Makassar)</option>
                            <option value="Asia/Jayapura">WIT (Asia/Jayapura)</option>
                        </select>
                    </div>
                </div>
                <div style="border-bottom:1px solid var(--border);padding-bottom:10px;margin-bottom:2px">
                    <div style="font-size:.72rem;color:var(--text-muted);text-transform:uppercase;font-weight:600;margin-bottom:8px">Profil Perusahaan</div>
                    <div><div class="sa-label">Nama Perusahaan</div><input type="text" name="company_name" class="sa-input" placeholder="Sama dengan nama ISP jika kosong"></div>
                    <div style="margin-top:8px"><div class="sa-label">Alamat</div><input type="text" name="company_address" class="sa-input" placeholder="Alamat perusahaan"></div>
                    <div style="margin-top:8px"><div class="sa-label">Telepon</div><input type="text" name="company_phone" class="sa-input" placeholder="08xx"></div>
                </div>
                <div>
                    <div style="font-size:.72rem;color:var(--text-muted);text-transform:uppercase;font-weight:600;margin-bottom:8px">User Admin Pertama</div>
                    <div><div class="sa-label">Nama Lengkap *</div><input type="text" name="admin_name" class="sa-input" required placeholder="Nama admin"></div>
                    <div style="margin-top:8px"><div class="sa-label">Username *</div><input type="text" name="admin_username" class="sa-input" required placeholder="username_login"></div>
                    <div style="margin-top:8px"><div class="sa-label">Password *</div><input type="password" name="admin_password" class="sa-input" required minlength="6" placeholder="Min 6 karakter"></div>
                </div>
                <button type="submit" class="sa-btn sa-btn-primary" style="margin-top:8px">🏢 Buat Tenant + User Admin</button>
            </div>
        </form>
    </div>

    {{-- DAFTAR TENANT --}}
    <div class="sa-card">
        <div class="sa-card-title">📋 Daftar Tenant ({{ $tenants->count() }})</div>
        <div style="max-height:70vh;overflow:auto">
            <table class="sa-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tenant</th>
                        <th>Slug</th>
                        <th>Status</th>
                        <th>Users</th>
                        <th>Pelanggan</th>
                        <th>Subscription</th>
                        <th style="text-align:center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($tenants as $i => $t)
                    @php
                        $sub = $t->subscriptions->first();
                        $subStatus = $sub ? ($sub->isActive() ? 'active' : ($sub->status === 'grace' ? 'grace' : 'expired')) : 'none';
                    @endphp
                    <tr>
                        <td>{{ $i+1 }}</td>
                        <td>
                            <div style="font-weight:600;color:#fff">{{ $t->name }}</div>
                            @if($t->domain)<div style="font-size:.7rem;color:var(--text-muted)">{{ $t->domain }}</div>@endif
                        </td>
                        <td><code>{{ $t->slug }}</code></td>
                        <td>
                            @if($t->is_active)
                            <span class="sa-status sa-status-active">● Aktif</span>
                            @else
                            <span class="sa-status sa-status-inactive">● Nonaktif</span>
                            @endif
                        </td>
                        <td>{{ $t->users_count }}</td>
                        <td>{{ $t->customers_count }}</td>
                        <td>
                            @if($sub)
                                <span class="sa-status sa-status-{{ $subStatus }}">
                                    {{ ucfirst($sub->plan) }}
                                </span>
                                <div style="font-size:.65rem;color:var(--text-muted);margin-top:2px">
                                    exp: {{ $sub->expires_at->format('d/m/Y') }}
                                </div>
                            @else
                                <span class="sa-status sa-status-expired">Tanpa Sub</span>
                            @endif
                        </td>
                        <td style="text-align:center">
                            <div style="display:flex;gap:4px;justify-content:center;flex-wrap:wrap">
                                <a href="{{ route('superadmin.tenants.detail', $t) }}" class="sa-btn sa-btn-secondary" style="padding:4px 10px;font-size:.72rem">👁 Detail</a>
                                <button class="sa-btn sa-btn-secondary" style="padding:4px 10px;font-size:.72rem" onclick="editTenant({{ $t->id }})">✏️</button>
                                <button class="sa-btn {{ $t->is_active ? 'sa-btn-danger' : 'sa-btn-success' }}" style="padding:4px 10px;font-size:.72rem" onclick="toggleTenant({{ $t->id }}, '{{ $t->name }}', {{ $t->is_active ? 'true' : 'false' }})">{{ $t->is_active ? '⏸' : '▶' }}</button>
                                <button class="sa-btn sa-btn-danger" style="padding:4px 10px;font-size:.72rem" onclick="deleteTenant({{ $t->id }}, '{{ $t->name }}')">🗑</button>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:30px">Belum ada tenant.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- MODAL EDIT --}}
<div class="sa-modal-overlay" id="editModal">
    <div class="sa-modal">
        <div class="sa-modal-header">
            <h3>✏️ Edit Tenant</h3>
            <button class="sa-modal-close" onclick="document.getElementById('editModal').classList.remove('show')">&times;</button>
        </div>
        <div id="editMsg" class="sa-alert"></div>
        <form id="editForm">
            <input type="hidden" id="editId">
            <div style="display:flex;flex-direction:column;gap:10px">
                <div><div class="sa-label">Nama ISP</div><input type="text" id="editName" class="sa-input" required></div>
                <div><div class="sa-label">Slug</div><input type="text" id="editSlug" class="sa-input"></div>
                <div><div class="sa-label">Domain</div><input type="text" id="editDomain" class="sa-input"></div>
                <div>
                    <div class="sa-label">Timezone</div>
                    <select id="editTimezone" class="sa-input">
                        <option value="Asia/Jakarta">WIB (Asia/Jakarta)</option>
                        <option value="Asia/Makassar">WITA (Asia/Makassar)</option>
                        <option value="Asia/Jayapura">WIT (Asia/Jayapura)</option>
                    </select>
                </div>
                <div><div class="sa-label">Nama Perusahaan</div><input type="text" id="editCompanyName" class="sa-input"></div>
                <div><div class="sa-label">Alamat</div><input type="text" id="editCompanyAddress" class="sa-input"></div>
                <div><div class="sa-label">Telepon</div><input type="text" id="editCompanyPhone" class="sa-input"></div>
                <div style="display:flex;gap:8px;margin-top:12px">
                    <button type="submit" class="sa-btn sa-btn-primary">✓ Simpan</button>
                    <button type="button" class="sa-btn sa-btn-secondary" onclick="document.getElementById('editModal').classList.remove('show')">Batal</button>
                </div>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
var tenantsData = @json($tenants->keyBy('id'));

function editTenant(id) {
    var t = tenantsData[id];
    if (!t) return;
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = t.name || '';
    document.getElementById('editSlug').value = t.slug || '';
    document.getElementById('editDomain').value = t.domain || '';
    document.getElementById('editTimezone').value = t.timezone || 'Asia/Jakarta';
    var cp = t.company_profile || {};
    document.getElementById('editCompanyName').value = cp.name || '';
    document.getElementById('editCompanyAddress').value = cp.address || '';
    document.getElementById('editCompanyPhone').value = cp.phone || '';
    document.getElementById('editModal').classList.add('show');
}

document.getElementById('editForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var id = document.getElementById('editId').value;
    var data = {
        name: document.getElementById('editName').value,
        slug: document.getElementById('editSlug').value,
        domain: document.getElementById('editDomain').value,
        timezone: document.getElementById('editTimezone').value,
        company_name: document.getElementById('editCompanyName').value,
        company_address: document.getElementById('editCompanyAddress').value,
        company_phone: document.getElementById('editCompanyPhone').value,
    };
    fetch('/superadmin/tenants/' + id, {
        method: 'PUT',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}'},
        body: JSON.stringify(data)
    })
    .then(function(r) { return r.json(); })
    .then(function(res) {
        if (res.status === 'success') location.reload();
        else { var m = document.getElementById('editMsg'); m.className='sa-alert err'; m.textContent=res.message; }
    });
});

function toggleTenant(id, name, isActive) {
    var action = isActive ? 'Nonaktifkan' : 'Aktifkan';
    if (!confirm(action + ' tenant "' + name + '"?')) return;
    fetch('/superadmin/tenants/' + id + '/toggle', {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}'}
    })
    .then(function(r) { return r.json(); })
    .then(function(res) {
        if (res.status === 'success') location.reload();
        else alert(res.message);
    });
}

function deleteTenant(id, name) {
    if (!confirm('⚠️ HAPUS tenant "' + name + '"?\n\nSemua data (user, role, customer, subscription) akan DIHAPUS PERMANEN!')) return;
    if (!confirm('🔴 KONFIRMASI TERAKHIR:\nAnda YAKIN ingin menghapus "' + name + '" beserta SEMUA datanya?')) return;
    fetch('/superadmin/tenants/' + id, {
        method: 'DELETE',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}'}
    })
    .then(function(r) { return r.json(); })
    .then(function(res) {
        if (res.status === 'success') location.reload();
        else alert(res.message);
    });
}
</script>
@endpush
@endsection
