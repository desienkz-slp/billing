@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
Role & Permission
@endsection
@section('content')
@if(session('success'))
<div class="cfg-alert ok">{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="cfg-alert err">{{ session('error') }}</div>
@endif

@php
$permGroups = [
    'Dashboard' => [
        'can_view_dashboard' => 'Lihat Dashboard',
        'can_view_dashboard_config' => 'Lihat Dashboard Config',
        'can_view_dashboard_map' => 'Lihat Dashboard Map',
    ],
    'Pelanggan' => [
        'can_input_customer' => 'Input Pelanggan',
        'can_edit_customer' => 'Edit Pelanggan',
        'can_delete_customer' => 'Hapus Pelanggan',
        'can_import_customer' => 'Import Pelanggan',
        'can_export_customer' => 'Export Pelanggan',
        'can_view_all_customers' => 'Lihat Semua Pelanggan',
    ],
    'Visibilitas Data' => [
        'view_by_area' => 'Lihat per Area',
        'view_by_sales' => 'Lihat per Sales',
        'view_own_only' => 'Hanya Data Sendiri',
    ],
    'Pembayaran' => [
        'can_process_payment' => 'Proses Pembayaran',
        'can_cancel_payment' => 'Batal Pembayaran',
        'can_view_payment_history' => 'Lihat Riwayat',
    ],
    'Isolir & Cuti' => [
        'can_manage_isolir' => 'Kelola Isolir',
        'can_auto_isolir_config' => 'Config Auto Isolir',
        'can_cuti' => 'Ajukan Cuti',
        'can_manage_cuti' => 'Kelola Cuti',
    ],
    'Laporan & Keuangan' => [
        'can_view_reports' => 'Lihat Laporan',
        'can_view_finance' => 'Lihat Keuangan',
        'can_manage_expenses' => 'Kelola Pengeluaran',
        'can_manage_deposits' => 'Kelola Deposit',
        'can_deduct_balance' => 'Kurangi Saldo',
        'can_delete_finance' => 'Hapus Data Keuangan',
        'can_use_deposit' => 'Gunakan Deposit',
    ],
    'Master Data' => [
        'can_manage_packages' => 'Kelola Paket',
        'can_manage_areas' => 'Kelola Area',
        'can_manage_odp' => 'Kelola ODP',
        'can_manage_routers' => 'Kelola Router',
        'can_manage_servers' => 'Kelola Server',
    ],
    'Administrasi' => [
        'can_manage_users' => 'Kelola User',
        'can_manage_roles' => 'Kelola Role',
        'can_view_audit_logs' => 'Lihat Audit Log',
        'can_manage_config' => 'Kelola Config',
        'can_backup_restore' => 'Backup & Restore',
        'can_edit_template' => 'Edit Template',
    ],
    'Teknis' => [
        'can_access_mikrotik' => 'Akses MikroTik',
        'can_access_radius' => 'Akses RADIUS',
        'can_manage_pppoe' => 'Kelola PPPoE',
        'can_send_wa_blast' => 'Kirim WA Blast',
    ],
    'Monitor & Map' => [
        'can_view_map' => 'Lihat Peta',
        'can_view_monitor' => 'Lihat Monitor',
    ],
    'Akses Modul' => [
        'can_access_billing' => 'Akses Billing',
        'can_access_config' => 'Akses Config',
        'can_access_db' => 'Akses Database',
        'can_access_map' => 'Akses Map',
    ],
];
$allPerms = [];
foreach ($permGroups as $perms) { foreach ($perms as $k => $v) $allPerms[$k] = $v; }
@endphp

<div class="cfg-grid-2">
    {{-- FORM TAMBAH --}}
    <div class="cfg-card">
        <div class="cfg-card-title">➕ Tambah Role Baru</div>
        <form method="POST" action="{{ route('config.roles.store') }}">
            @csrf
            <div style="margin-bottom:12px">
                <div class="cfg-label">Nama Role</div>
                <input type="text" name="name" class="cfg-input" required placeholder="contoh: Admin Area">
            </div>
            <div style="margin-bottom:12px">
                <div class="cfg-label">Deskripsi</div>
                <input type="text" name="description" class="cfg-input" placeholder="Deskripsi singkat">
            </div>
            <div style="margin-bottom:12px">
                <div class="cfg-label">Permission</div>
                <div style="padding:10px;background:rgba(0,0,0,.2);border-radius:8px;max-height:350px;overflow:auto">
                    @foreach($permGroups as $groupName => $perms)
                    <div style="font-size:.7rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin:8px 0 4px;font-weight:600">{{ $groupName }}</div>
                    @foreach($perms as $key => $label)
                    <label class="cfg-check"><input type="checkbox" name="{{ $key }}" value="1"> {{ $label }}</label>
                    @endforeach
                    @endforeach
                </div>
            </div>
            <button type="submit" class="cfg-btn cfg-btn-primary">✓ Simpan Role</button>
        </form>
    </div>

    {{-- DAFTAR ROLE --}}
    <div class="cfg-card">
        <div class="cfg-card-title">📋 Daftar Role ({{ $roles->count() }})</div>
        <div style="max-height:70vh;overflow:auto">
            @forelse($roles as $r)
            <div style="padding:12px;background:rgba(0,0,0,.2);border-radius:8px;margin-bottom:8px">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                    <div>
                        <strong style="color:#fff">{{ $r->name }}</strong>
                        <span style="font-size:.75rem;color:var(--text-muted);margin-left:6px">{{ $r->users_count }} user</span>
                        @if($r->description)<div style="font-size:.75rem;color:var(--text-muted)">{{ $r->description }}</div>@endif
                    </div>
                    <div style="display:flex;gap:4px">
                        <button class="cfg-btn cfg-btn-secondary" style="padding:4px 10px;font-size:.75rem" onclick="editRole({{ $r->id }})">✏️</button>
                        @if($r->users_count == 0)
                        <button class="cfg-btn cfg-btn-danger" style="padding:4px 10px;font-size:.75rem" onclick="deleteRole({{ $r->id }}, '{{ $r->name }}')">🗑</button>
                        @endif
                    </div>
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:4px">
                    @foreach($allPerms as $key => $label)
                        @if($r->$key)
                        <span style="font-size:.65rem;padding:2px 6px;background:rgba(14,165,233,.15);color:var(--accent);border-radius:4px">{{ $label }}</span>
                        @endif
                    @endforeach
                </div>
            </div>
            @empty
            <p style="text-align:center;color:var(--text-muted);padding:20px">Belum ada role.</p>
            @endforelse
        </div>
    </div>
</div>

{{-- MODAL EDIT --}}
<div class="cfg-modal-overlay" id="editModal">
    <div class="cfg-modal" style="max-width:520px">
        <div class="cfg-modal-header">
            <h3>✏️ Edit Role</h3>
            <button class="cfg-modal-close" onclick="document.getElementById('editModal').classList.remove('show')">&times;</button>
        </div>
        <div id="editMsg" class="cfg-alert"></div>
        <form id="editForm">
            <input type="hidden" id="editId">
            <div style="margin-bottom:12px">
                <div class="cfg-label">Nama</div>
                <input type="text" id="editName" class="cfg-input" required>
            </div>
            <div style="margin-bottom:12px">
                <div class="cfg-label">Deskripsi</div>
                <input type="text" id="editDesc" class="cfg-input">
            </div>
            <div style="margin-bottom:12px">
                <div class="cfg-label">Permission</div>
                <div style="padding:10px;background:rgba(0,0,0,.2);border-radius:8px;max-height:300px;overflow:auto">
                    @foreach($permGroups as $groupName => $perms)
                    <div style="font-size:.7rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;margin:8px 0 4px;font-weight:600">{{ $groupName }}</div>
                    @foreach($perms as $key => $label)
                    <label class="cfg-check"><input type="checkbox" id="edit_{{ $key }}" name="{{ $key }}" value="1"> {{ $label }}</label>
                    @endforeach
                    @endforeach
                </div>
            </div>
            <div style="display:flex;gap:8px;margin-top:16px">
                <button type="submit" class="cfg-btn cfg-btn-primary">✓ Simpan</button>
                <button type="button" class="cfg-btn cfg-btn-secondary" onclick="document.getElementById('editModal').classList.remove('show')">Batal</button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
var rolesData = @json($roles->keyBy('id'));
var allPermKeys = @json(array_keys($allPerms));

function editRole(id) {
    var r = rolesData[id];
    if (!r) return;
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = r.name;
    document.getElementById('editDesc').value = r.description || '';
    allPermKeys.forEach(function(k) {
        var el = document.getElementById('edit_' + k);
        if (el) el.checked = !!r[k];
    });
    document.getElementById('editModal').classList.add('show');
}

document.getElementById('editForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var id = document.getElementById('editId').value;
    var data = {
        name: document.getElementById('editName').value,
        description: document.getElementById('editDesc').value
    };
    allPermKeys.forEach(function(k) {
        var el = document.getElementById('edit_' + k);
        data[k] = el && el.checked ? 1 : 0;
    });
    fetch('/config/roles/' + id, {
        method: 'PUT',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}'},
        body: JSON.stringify(data)
    })
    .then(function(r) { return r.json(); })
    .then(function(res) {
        if (res.status === 'success') location.reload();
        else { var m = document.getElementById('editMsg'); m.className='cfg-alert err'; m.textContent=res.message; }
    });
});

function deleteRole(id, name) {
    if (!confirm('Hapus role "' + name + '"?')) return;
    fetch('/config/roles/' + id, {
        method: 'DELETE',
        headers: {'X-CSRF-TOKEN': '{{ csrf_token() }}'}
    })
    .then(function(r) { return r.json(); })
    .then(function(res) {
        if (res.status === 'success') location.reload();
        else alert(res.message);
    });
}
</script>
@endpush
@endsection
