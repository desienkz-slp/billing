@extends('layouts.app')

@section('title', 'Pencairan Fee Tim')

@section('content')
<div class="header-section" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
    <div>
        <h2 style="font-size:24px; font-weight:700; color:var(--text-main); margin:0 0 4px;">Pencairan Fee Tim</h2>
        <p style="color:var(--text-muted); font-size:14px; margin:0;">Rekap fee sales & kolektor dan proses pencairannya.</p>
    </div>
    <div style="display:flex; gap:12px; align-items:center;">
        <form id="filterForm" action="{{ route('fee_withdrawals.index') }}" method="GET" style="display:flex; gap:8px;">
            <input type="month" name="bulan" value="{{ $bulan }}" class="input-field" style="width:auto;">
            <button type="submit" class="btn btn-primary" style="padding:8px 16px;">Filter</button>
        </form>
    </div>
</div>

@if(session('success'))
<div style="padding:12px; background:#10b98120; border:1px solid #10b981; color:#10b981; border-radius:6px; margin-bottom:20px;">
    {{ session('success') }}
</div>
@endif

<!-- Rekap Fee Per User -->
<div class="content-card" style="margin-bottom:24px;">
    <div style="padding:16px; border-bottom:1px solid var(--border);">
        <h3 style="margin:0; font-size:16px;">Sisa Komisi/Fee Bulan {{ \Carbon\Carbon::parse($bulan.'-01')->format('F Y') }}</h3>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Fee Sales</th>
                    <th>Fee Kolektor</th>
                    <th>Total Fee</th>
                    <th>Sudah Dicairkan</th>
                    <th>Sisa Belum Dicairkan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($userFees as $userId => $fee)
                <tr>
                    <td>
                        <div style="font-weight:600;">{{ $fee['user']->name ?? 'Unknown' }}</div>
                        <div style="font-size:12px; color:var(--text-muted);">{{ $fee['user']->role->name ?? '' }}</div>
                    </td>
                    <td>Rp {{ number_format($fee['sales'], 0, ',', '.') }}</td>
                    <td>Rp {{ number_format($fee['collector'], 0, ',', '.') }}</td>
                    <td style="font-weight:600;">Rp {{ number_format($fee['total'], 0, ',', '.') }}</td>
                    <td style="color:#10b981;">Rp {{ number_format($fee['withdrawn'], 0, ',', '.') }}</td>
                    <td style="font-weight:700; color:#ef4444;">Rp {{ number_format($fee['sisa'], 0, ',', '.') }}</td>
                    <td>
                        @if($fee['sisa'] > 0)
                        <button type="button" class="btn btn-primary" style="padding:4px 12px; font-size:12px;" onclick="openWithdrawModal({{ $userId }}, '{{ $fee['user']->name }}', {{ $fee['sisa'] }})">
                            Cairkan
                        </button>
                        @else
                        <span style="font-size:12px; color:var(--text-muted);">Lunas</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align:center; padding:20px; color:var(--text-muted);">Tidak ada data fee di bulan ini.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<!-- Histori Pencairan -->
<div class="content-card">
    <div style="padding:16px; border-bottom:1px solid var(--border);">
        <h3 style="margin:0; font-size:16px;">Histori Pencairan (Withdrawal) Bulan Ini</h3>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Waktu</th>
                    <th>User Penerima</th>
                    <th>Nominal</th>
                    <th>Catatan</th>
                    <th>Diproses Oleh</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($withdrawals as $w)
                <tr>
                    <td>{{ $w->created_at->format('d M Y H:i') }}</td>
                    <td style="font-weight:600;">{{ $w->user->name ?? '-' }}</td>
                    <td style="font-weight:600; color:#10b981;">Rp {{ number_format($w->amount, 0, ',', '.') }}</td>
                    <td>{{ $w->notes ?? '-' }}</td>
                    <td>{{ $w->processor->name ?? '-' }}</td>
                    <td>
                        <form action="{{ route('fee_withdrawals.destroy', $w->id) }}" method="POST" onsubmit="return confirm('Batalkan pencairan ini?');">
                            @csrf @method('DELETE')
                            <button type="submit" class="btn" style="padding:4px 8px; background:#ef444420; color:#ef4444; border:1px solid #ef4444; font-size:12px;">Batalkan</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align:center; padding:20px; color:var(--text-muted);">Belum ada pencairan di bulan ini.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Pencairan -->
<div id="withdrawModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); align-items:center; justify-content:center; z-index:100;">
    <div class="content-card" style="width:400px; padding:24px; background:var(--bg-main);">
        <h3 style="margin-top:0;">Pencairan Fee</h3>
        <form action="{{ route('fee_withdrawals.store') }}" method="POST">
            @csrf
            <input type="hidden" name="periode" value="{{ $bulan }}">
            <input type="hidden" name="user_id" id="modalUserId">
            
            <div class="form-group" style="margin-bottom:16px;">
                <label>Nama User</label>
                <input type="text" id="modalUserName" class="input-field" disabled>
            </div>
            <div class="form-group" style="margin-bottom:16px;">
                <label>Nominal Pencairan (Rp)</label>
                <input type="number" name="amount" id="modalAmount" class="input-field" min="1" required>
            </div>
            <div class="form-group" style="margin-bottom:24px;">
                <label>Catatan (Opsional)</label>
                <input type="text" name="notes" class="input-field" placeholder="Cair tunai, transfer BCA, dll">
            </div>
            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button type="button" class="btn" onclick="document.getElementById('withdrawModal').style.display='none'">Batal</button>
                <button type="submit" class="btn btn-primary">Konfirmasi Pencairan</button>
            </div>
        </form>
    </div>
</div>

@endsection

@push('scripts')
<script>
function openWithdrawModal(userId, userName, maxAmount) {
    document.getElementById('modalUserId').value = userId;
    document.getElementById('modalUserName').value = userName;
    document.getElementById('modalAmount').value = maxAmount;
    document.getElementById('modalAmount').max = maxAmount;
    document.getElementById('withdrawModal').style.display = 'flex';
}
</script>
@endpush
