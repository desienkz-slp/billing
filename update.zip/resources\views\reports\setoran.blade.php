@extends('layouts.app')
@section('title', 'Laporan Setoran')
@section('content')
@php $monthLabel = \Carbon\Carbon::parse($month.'-01')->locale('id')->isoFormat('MMMM YYYY'); @endphp
<div style="margin-bottom:20px;"><h1 style="font-size:22px; font-weight:700;">🏦 Laporan Setoran</h1><p style="color:var(--text-muted); font-size:14px;">{{ $monthLabel }}</p></div>
@if(session('success'))<div class="alert-success">✅ {{ session('success') }}</div>@endif
<div class="kpi-grid"><div class="kpi-card" style="background:linear-gradient(135deg,#047857,#10b981);"><div class="kpi-label">Total Setoran</div><div class="kpi-value" style="color:#4ade80">Rp {{ number_format($total) }}</div><div class="kpi-sub">{{ $deposits->count() }} setoran</div></div></div>
<div class="card" style="padding:16px; margin-bottom:16px;"><form method="GET" style="display:flex; gap:10px; align-items:flex-end;"><div><label class="form-label">Periode</label><input type="month" name="month" value="{{ $month }}" class="form-input"></div><button type="submit" class="btn-primary">🔍 Filter</button></form></div>
@if($user->is_system_admin || $user->role?->can_manage_deposits)
<div class="card" style="padding:16px; margin-bottom:16px;">
    <h3 style="font-size:15px; font-weight:600; margin-bottom:12px;">➕ Tambah Setoran</h3>
    <form method="POST" action="{{ route('reports.setoran.store') }}" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">@csrf
        <div><label class="form-label">Sales</label><select name="sales_id" required class="form-input">@foreach($salesUsers as $s)<option value="{{ $s->id }}">{{ $s->name }}</option>@endforeach</select></div>
        <div><label class="form-label">Nominal (Rp)</label><input type="number" name="amount" required min="1" class="form-input"></div>
        <div><label class="form-label">Metode</label><select name="method" class="form-input"><option value="cash">Cash</option><option value="transfer">Transfer</option></select></div>
        <div><label class="form-label">Keterangan</label><input type="text" name="notes" class="form-input" placeholder="Opsional"></div>
        <button type="submit" class="btn-primary">💾 Simpan</button>
    </form>
</div>
@endif
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>#</th><th>Tgl</th><th>Sales</th><th>Metode</th><th>Keterangan</th><th>Diterima Oleh</th><th style="text-align:right">Nominal</th></tr></thead>
        <tbody>
        @forelse($deposits as $i => $d)
        <tr><td>{{ $i+1 }}</td><td style="font-size:12px;color:var(--text-muted)">{{ $d->deposit_date->format('d/m/Y') }}</td><td><strong>{{ $d->sales?->name ?? '-' }}</strong></td><td>{{ ucfirst($d->method) }}</td><td style="font-size:13px;color:var(--text-muted)">{{ $d->notes ?? '-' }}</td><td style="font-size:12px;color:var(--text-muted)">{{ $d->receiver?->name ?? '-' }}</td><td style="text-align:right;color:#4ade80;font-weight:600">{{ number_format($d->amount) }}</td></tr>
        @empty
        <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted);">Belum ada setoran.</td></tr>
        @endforelse
        @if($deposits->count())<tr style="border-top:2px solid var(--border);font-weight:700;"><td colspan="6" style="text-align:right">Total:</td><td style="text-align:right;color:#22c55e">{{ number_format($total) }}</td></tr>@endif
        </tbody>
    </table>
</div>
@endsection
@push('styles')<style>.alert-success{padding:12px 16px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:10px;color:#22c55e;margin-bottom:16px;font-size:14px}.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px}.kpi-card{padding:20px;border-radius:var(--radius);border:1px solid var(--border)}.kpi-label{font-size:13px;color:rgba(255,255,255,.85);margin-bottom:4px}.kpi-value{font-size:24px;font-weight:800}.kpi-sub{font-size:12px;color:rgba(255,255,255,.7);margin-top:4px}.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}.form-label{display:block;font-size:12px;color:var(--text-muted);margin-bottom:4px;font-weight:600}.form-input{padding:8px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg-body);color:var(--text);font-size:14px;font-family:inherit}.btn-primary{padding:8px 16px;background:var(--accent);color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit}.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:10px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}</style>@endpush
