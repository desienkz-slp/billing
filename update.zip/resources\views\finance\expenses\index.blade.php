@extends('layouts.app')

@section('title', 'Pengeluaran Operasional')

@section('content')
<div class="header-section" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
    <div>
        <h2 style="font-size:24px; font-weight:700; color:var(--text-main); margin:0 0 4px;">Pengeluaran Operasional</h2>
        <p style="color:var(--text-muted); font-size:14px; margin:0;">Kelola catatan pengeluaran bulanan.</p>
    </div>
    <div style="display:flex; gap:12px; align-items:center;">
        <form id="filterForm" action="{{ route('expenses.index') }}" method="GET" style="display:flex; gap:8px;">
            <input type="month" name="bulan" value="{{ $bulan }}" class="input-field" style="width:auto;">
            <button type="submit" class="btn btn-primary" style="padding:8px 16px;">Filter</button>
        </form>
        <button type="button" class="btn btn-primary" style="padding:8px 16px;" onclick="document.getElementById('addExpenseModal').style.display='flex'">
            + Tambah
        </button>
    </div>
</div>

@if(session('success'))
<div style="padding:12px; background:#10b98120; border:1px solid #10b981; color:#10b981; border-radius:6px; margin-bottom:20px;">
    {{ session('success') }}
</div>
@endif

<div class="content-card" style="padding:20px; margin-bottom:24px;">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <div style="font-size:14px; color:var(--text-muted);">Total Pengeluaran Bulan Ini</div>
        <div style="font-size:24px; font-weight:700; color:#ef4444;">Rp {{ number_format($total, 0, ',', '.') }}</div>
    </div>
</div>

<div class="content-card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Kategori</th>
                    <th>Deskripsi</th>
                    <th>Nominal</th>
                    <th>Ditambahkan Oleh</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($expenses as $exp)
                <tr>
                    <td>{{ \Carbon\Carbon::parse($exp->expense_date)->format('d M Y') }}</td>
                    <td><span style="background:var(--bg-hover); padding:4px 8px; border-radius:4px; font-size:12px;">{{ $exp->category }}</span></td>
                    <td>{{ $exp->description }}</td>
                    <td style="font-weight:600; color:#ef4444;">Rp {{ number_format($exp->amount, 0, ',', '.') }}</td>
                    <td>{{ $exp->creator->name ?? '-' }}</td>
                    <td>
                        <form action="{{ route('expenses.destroy', $exp->id) }}" method="POST" onsubmit="return confirm('Hapus pengeluaran ini?');" style="display:inline-block;">
                            @csrf @method('DELETE')
                            <button type="submit" class="btn" style="padding:4px 8px; background:#ef444420; color:#ef4444; border:1px solid #ef4444;">Hapus</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align:center; padding:20px; color:var(--text-muted);">Tidak ada catatan pengeluaran di bulan ini.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="padding:16px;">
        {{ $expenses->links() }}
    </div>
</div>

<!-- Add Modal -->
<div id="addExpenseModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); align-items:center; justify-content:center; z-index:100;">
    <div class="content-card" style="width:400px; padding:24px; background:var(--bg-main);">
        <h3 style="margin-top:0;">Tambah Pengeluaran</h3>
        <form action="{{ route('expenses.store') }}" method="POST">
            @csrf
            <div class="form-group" style="margin-bottom:16px;">
                <label>Tanggal</label>
                <input type="date" name="expense_date" class="input-field" value="{{ date('Y-m-d') }}" required>
            </div>
            <div class="form-group" style="margin-bottom:16px;">
                <label>Kategori</label>
                <select name="category" class="input-field" required>
                    @foreach($categories as $cat)
                        <option value="{{ $cat }}">{{ $cat }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group" style="margin-bottom:16px;">
                <label>Deskripsi/Keterangan</label>
                <input type="text" name="description" class="input-field" placeholder="Beli kabel, operasional teknisi, dll" required>
            </div>
            <div class="form-group" style="margin-bottom:24px;">
                <label>Nominal (Rp)</label>
                <input type="number" name="amount" class="input-field" min="0" required>
            </div>
            <div style="display:flex; justify-content:flex-end; gap:12px;">
                <button type="button" class="btn" onclick="document.getElementById('addExpenseModal').style.display='none'">Batal</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

@endsection
