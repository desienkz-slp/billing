@extends('layouts.app')
@section('title', 'Detail Router — ' . $router->name)
@section('content')
<div style="margin-bottom:20px;display:flex;justify-content:space-between;align-items:start;flex-wrap:wrap;gap:12px">
    <div>
        <h2 style="font-size:1.2rem;font-weight:700;display:flex;align-items:center;gap:8px">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="14" width="20" height="6" rx="2"/><path d="M6 14V8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v6"/></svg>
            {{ $identity ?? $router->name }}
        </h2>
        <span style="font-size:.82rem;color:var(--text-muted)">{{ $router->host }}:{{ $router->port }}</span>
    </div>
    <div style="display:flex;gap:8px">
        <button onclick="syncPppoe()" style="padding:8px 14px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.06);color:var(--text-secondary);font-size:.8rem;cursor:pointer;font-family:inherit">🔄 Sync PPPoE</button>
        <a href="{{ route('monitoring.index') }}" style="padding:8px 14px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.06);color:var(--text-secondary);font-size:.8rem;text-decoration:none;display:inline-flex;align-items:center;gap:4px">← Kembali</a>
    </div>
</div>

{{-- System Resources --}}
@if($resources)
<div class="card" style="margin-bottom:16px;padding:16px">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px">
        @php
            $cpuLoad = $resources['cpu-load'] ?? 0;
            $freeRam = isset($resources['free-memory']) ? round($resources['free-memory'] / 1024 / 1024) : 0;
            $totalRam = isset($resources['total-memory']) ? round($resources['total-memory'] / 1024 / 1024) : 0;
            $usedRam = $totalRam - $freeRam;
            $ramPct = $totalRam > 0 ? round(($usedRam / $totalRam) * 100) : 0;
        @endphp
        <div style="text-align:center">
            <div style="font-size:.68rem;color:var(--text-muted);text-transform:uppercase;margin-bottom:4px">CPU</div>
            <div style="font-size:1.4rem;font-weight:700;color:{{ $cpuLoad > 80 ? 'var(--danger)' : ($cpuLoad > 50 ? 'var(--warning)' : 'var(--success)') }}">{{ $cpuLoad }}%</div>
        </div>
        <div style="text-align:center">
            <div style="font-size:.68rem;color:var(--text-muted);text-transform:uppercase;margin-bottom:4px">RAM</div>
            <div style="font-size:1.4rem;font-weight:700;color:{{ $ramPct > 80 ? 'var(--danger)' : 'var(--accent)' }}">{{ $usedRam }}/{{ $totalRam }} MB</div>
        </div>
        <div style="text-align:center">
            <div style="font-size:.68rem;color:var(--text-muted);text-transform:uppercase;margin-bottom:4px">Uptime</div>
            <div style="font-size:1rem;font-weight:600">{{ $resources['uptime'] ?? '—' }}</div>
        </div>
        <div style="text-align:center">
            <div style="font-size:.68rem;color:var(--text-muted);text-transform:uppercase;margin-bottom:4px">Version</div>
            <div style="font-size:1rem;font-weight:600">{{ $resources['version'] ?? '—' }}</div>
        </div>
        <div style="text-align:center">
            <div style="font-size:.68rem;color:var(--text-muted);text-transform:uppercase;margin-bottom:4px">Board</div>
            <div style="font-size:1rem;font-weight:600">{{ $resources['board-name'] ?? '—' }}</div>
        </div>
    </div>
</div>
@endif

{{-- Tabs --}}
<div style="display:flex;gap:4px;margin-bottom:16px;border-bottom:1px solid var(--border);padding-bottom:0">
    <button class="tab-btn active" onclick="switchTab('secrets')" id="tab-secrets" style="padding:10px 18px;border:none;background:none;color:var(--text-primary);font-size:.85rem;font-weight:600;cursor:pointer;border-bottom:2px solid var(--accent);font-family:inherit">PPPoE Secrets ({{ $enrichedSecrets->count() }})</button>
    <button class="tab-btn" onclick="switchTab('active')" id="tab-active" style="padding:10px 18px;border:none;background:none;color:var(--text-muted);font-size:.85rem;font-weight:500;cursor:pointer;border-bottom:2px solid transparent;font-family:inherit">Active ({{ $activeDetails->count() }})</button>
    <button class="tab-btn" onclick="switchTab('profiles')" id="tab-profiles" style="padding:10px 18px;border:none;background:none;color:var(--text-muted);font-size:.85rem;font-weight:500;cursor:pointer;border-bottom:2px solid transparent;font-family:inherit">Profiles ({{ count($profiles) }})</button>
</div>

{{-- Tab: PPPoE Secrets --}}
<div class="tab-content" id="content-secrets">
    <div style="margin-bottom:12px">
        <input type="text" id="searchSecrets" placeholder="Cari username / pelanggan..." oninput="filterSecrets()" style="width:100%;max-width:360px;padding:8px 12px;background:var(--bg-card);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);font-size:.85rem;font-family:inherit;outline:none">
    </div>
    <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:.82rem">
            <thead>
                <tr style="border-bottom:1px solid var(--border)">
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">#</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Username</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Profile</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Status</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Pelanggan</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Aksi</th>
                </tr>
            </thead>
            <tbody id="secretsBody">
                @foreach($enrichedSecrets as $i => $s)
                <tr class="secret-row" data-search="{{ strtolower($s['name'] . ' ' . ($s['customer_name'] ?? '')) }}" style="border-bottom:1px solid rgba(255,255,255,.04)">
                    <td style="padding:8px 12px;color:var(--text-muted)">{{ $i + 1 }}</td>
                    <td style="padding:8px 12px">
                        <code style="font-size:.78rem;color:var(--accent);background:rgba(14,165,233,.1);padding:2px 6px;border-radius:4px">{{ $s['name'] }}</code>
                    </td>
                    <td style="padding:8px 12px;color:var(--text-secondary)">{{ $s['profile'] }}</td>
                    <td style="padding:8px 12px">
                        @if($s['disabled'])
                            <span style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:99px;font-size:.7rem;font-weight:600;background:rgba(239,68,68,.15);color:#f87171">
                                <span style="width:5px;height:5px;border-radius:50%;background:currentColor"></span> Disabled
                            </span>
                        @elseif($s['is_online'])
                            <span style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:99px;font-size:.7rem;font-weight:600;background:rgba(34,197,94,.15);color:#4ade80">
                                <span style="width:5px;height:5px;border-radius:50%;background:currentColor"></span> Online
                            </span>
                        @else
                            <span style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:99px;font-size:.7rem;font-weight:600;background:rgba(100,116,139,.15);color:#94a3b8">
                                <span style="width:5px;height:5px;border-radius:50%;background:currentColor"></span> Offline
                            </span>
                        @endif
                    </td>
                    <td style="padding:8px 12px;color:var(--text-secondary)">{{ $s['customer_name'] ?? '—' }}</td>
                    <td style="padding:8px 12px">
                        @if($s['customer_id'])
                            @if($s['disabled'])
                            <button onclick="unisolir({{ $s['customer_id'] }}, '{{ $s['name'] }}')" style="padding:4px 10px;border-radius:6px;border:none;background:rgba(34,197,94,.15);color:#4ade80;font-size:.72rem;font-weight:600;cursor:pointer;font-family:inherit">Unisolir</button>
                            @else
                            <button onclick="isolir({{ $s['customer_id'] }}, '{{ $s['name'] }}')" style="padding:4px 10px;border-radius:6px;border:none;background:rgba(239,68,68,.15);color:#f87171;font-size:.72rem;font-weight:600;cursor:pointer;font-family:inherit">Isolir</button>
                            @endif
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

{{-- Tab: Active Connections --}}
<div class="tab-content" id="content-active" style="display:none">
    <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:.82rem">
            <thead>
                <tr style="border-bottom:1px solid var(--border)">
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">#</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Name</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Pelanggan</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Address</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Caller ID</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Uptime</th>
                </tr>
            </thead>
            <tbody>
                @forelse($activeDetails as $i => $a)
                <tr style="border-bottom:1px solid rgba(255,255,255,.04)">
                    <td style="padding:8px 12px;color:var(--text-muted)">{{ $i + 1 }}</td>
                    <td style="padding:8px 12px"><code style="font-size:.78rem;color:var(--success);background:rgba(34,197,94,.1);padding:2px 6px;border-radius:4px">{{ $a['name'] }}</code></td>
                    <td style="padding:8px 12px;color:var(--text-secondary)">{{ $a['customer_name'] ?? '—' }}</td>
                    <td style="padding:8px 12px;color:var(--text-muted);font-size:.78rem">{{ $a['address'] }}</td>
                    <td style="padding:8px 12px;color:var(--text-muted);font-size:.78rem">{{ $a['caller_id'] }}</td>
                    <td style="padding:8px 12px;font-weight:600">{{ $a['uptime'] }}</td>
                </tr>
                @empty
                <tr><td colspan="6" style="padding:20px;text-align:center;color:var(--text-muted)">Tidak ada koneksi aktif</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

{{-- Tab: Profiles --}}
<div class="tab-content" id="content-profiles" style="display:none">
    <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:.82rem">
            <thead>
                <tr style="border-bottom:1px solid var(--border)">
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">#</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Name</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Rate Limit</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Local Address</th>
                    <th style="text-align:left;padding:10px 12px;color:var(--text-muted);font-weight:600;font-size:.72rem;text-transform:uppercase">Remote Address</th>
                </tr>
            </thead>
            <tbody>
                @foreach($profiles as $i => $p)
                <tr style="border-bottom:1px solid rgba(255,255,255,.04)">
                    <td style="padding:8px 12px;color:var(--text-muted)">{{ $i + 1 }}</td>
                    <td style="padding:8px 12px;font-weight:600">{{ $p['name'] ?? '—' }}</td>
                    <td style="padding:8px 12px;color:var(--accent)">{{ $p['rate-limit'] ?? '-' }}</td>
                    <td style="padding:8px 12px;color:var(--text-muted)">{{ $p['local-address'] ?? '-' }}</td>
                    <td style="padding:8px 12px;color:var(--text-muted)">{{ $p['remote-address'] ?? '-' }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@push('scripts')
<script>
var routerId = {{ $router->id }};
var csrfToken = '{{ csrf_token() }}';

function switchTab(tab) {
    document.querySelectorAll('.tab-content').forEach(function(el) { el.style.display = 'none'; });
    document.querySelectorAll('.tab-btn').forEach(function(el) {
        el.style.color = 'var(--text-muted)';
        el.style.fontWeight = '500';
        el.style.borderBottomColor = 'transparent';
    });
    document.getElementById('content-' + tab).style.display = 'block';
    var btn = document.getElementById('tab-' + tab);
    btn.style.color = 'var(--text-primary)';
    btn.style.fontWeight = '600';
    btn.style.borderBottomColor = 'var(--accent)';
}

function filterSecrets() {
    var q = document.getElementById('searchSecrets').value.toLowerCase();
    document.querySelectorAll('.secret-row').forEach(function(row) {
        row.style.display = row.dataset.search.indexOf(q) !== -1 ? '' : 'none';
    });
}

function syncPppoe() {
    if (!confirm('Sync PPPoE data dari router ini?')) return;
    fetch('/monitoring/router/' + routerId + '/sync', {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken},
    })
    .then(function(r) { return r.json(); })
    .then(function(res) { alert(res.message); if (res.status === 'success') location.reload(); })
    .catch(function() { alert('Gagal sync'); });
}

function isolir(customerId, name) {
    if (!confirm('Isolir "' + name + '"?')) return;
    fetch('/monitoring/router/' + routerId + '/isolir/' + customerId, {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken},
    })
    .then(function(r) { return r.json(); })
    .then(function(res) { alert(res.message); if (res.status === 'success') location.reload(); })
    .catch(function() { alert('Gagal isolir'); });
}

function unisolir(customerId, name) {
    if (!confirm('Unisolir "' + name + '"?')) return;
    fetch('/monitoring/router/' + routerId + '/unisolir/' + customerId, {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken},
    })
    .then(function(r) { return r.json(); })
    .then(function(res) { alert(res.message); if (res.status === 'success') location.reload(); })
    .catch(function() { alert('Gagal unisolir'); });
}
</script>
@endpush
@endsection
