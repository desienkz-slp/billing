<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Web\StatisticController;
use App\Http\Controllers\Web\ExpenseController;
use App\Http\Controllers\Web\FeeWithdrawalController;
use App\Http\Controllers\Web\CustomerController;
use App\Http\Controllers\Web\CustomerDiagnosticController;
use App\Http\Controllers\Web\CutiController;
use App\Http\Controllers\Web\InvoiceController;
use App\Http\Controllers\Web\IsolirController;
use App\Http\Controllers\Web\PaymentApiController;
use App\Http\Controllers\Web\ReportController;
use App\Http\Controllers\Web\SettingsController;
use App\Http\Controllers\Web\ConfigController;
use App\Http\Controllers\Web\MapController;
use App\Http\Controllers\Web\MonitoringController;
use App\Http\Controllers\Web\RadiusController;
use App\Http\Controllers\Web\SuperAdminController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => auth()->check() ? redirect()->route('app-gateway') : redirect()->route('login'));

Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->name('login.post');
});

Route::middleware(['auth', 'tenant'])->group(function () {
    Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
    Route::get('/app-gateway', fn () => view('app-gateway'))->name('app-gateway');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Statistik
    Route::get('/statistics', [StatisticController::class, 'index'])->middleware('permission:can_view_reports')->name('statistics.index');
    Route::get('/statistics/api', [StatisticController::class, 'apiData'])->middleware('permission:can_view_reports')->name('statistics.api');
    Route::post('/statistics/toggle-hide', [StatisticController::class, 'toggleHideMonth'])->middleware('permission:can_view_reports')->name('statistics.toggle_hide');

    // Keuangan (Finance)
    Route::resource('expenses', ExpenseController::class)->only(['index', 'store', 'destroy'])->middleware('permission:can_view_finance');
    Route::resource('fee_withdrawals', FeeWithdrawalController::class)->only(['index', 'store', 'destroy'])->middleware('permission:can_view_finance');



    // 📦📦 Customers 📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦📦
    Route::get('/customers/search-pppoe', [CustomerController::class, 'searchPppoeUsers'])
        ->name('customers.search-pppoe');
    Route::get('/customers', [CustomerController::class, 'index'])->name('customers.index');
    Route::get('/customers/create', [CustomerController::class, 'create'])
        ->middleware('permission:can_input_customer')->name('customers.create');
    Route::post('/customers', [CustomerController::class, 'store'])
        ->middleware('permission:can_input_customer')->name('customers.store');
    Route::get('/customers/{customer}/edit', [CustomerController::class, 'edit'])
        ->name('customers.edit');
    Route::put('/customers/{customer}', [CustomerController::class, 'update'])
        ->name('customers.update');
    Route::delete('/customers/{customer}', [CustomerController::class, 'destroy'])
        ->name('customers.destroy');
    Route::get('/customers/{customer}', [CustomerController::class, 'show'])
        ->name('customers.show');

    // ── Customer Diagnostics ──────────────────────
    Route::get('/customers-diagnostics/duplicates', [CustomerDiagnosticController::class, 'scanDuplicates'])
        ->name('customers.diagnostics.duplicates');
    Route::get('/customers-diagnostics/mismatch', [CustomerDiagnosticController::class, 'scanMismatch'])
        ->name('customers.diagnostics.mismatch');
    Route::get('/customers-diagnostics/unsynced', [CustomerDiagnosticController::class, 'scanUnsynced'])
        ->name('customers.diagnostics.unsynced');

    // ── Pelanggan Cuti ────────────────────────────
    Route::get('/cuti', [CutiController::class, 'index'])
        ->middleware('permission:can_manage_cuti')->name('cuti.index');
    Route::post('/cuti/{customer}/store', [CutiController::class, 'store'])
        ->middleware('permission:can_manage_cuti')->name('cuti.store');
    Route::post('/cuti/{customer}/restore', [CutiController::class, 'restore'])
        ->middleware('permission:can_manage_cuti')->name('cuti.restore');
    Route::delete('/cuti/{customer}', [CutiController::class, 'destroy'])
        ->middleware('permission:can_manage_cuti')->name('cuti.destroy');

    // ── Payment API (AJAX) ────────────────────────
    Route::get('/api-web/payments/months/{customer}', [PaymentApiController::class, 'getMonths'])
        ->middleware('permission:can_process_payment')->name('api.payments.months');
    Route::post('/api-web/payments/single', [PaymentApiController::class, 'storeSingle'])
        ->middleware('permission:can_process_payment')->name('api.payments.single');
    Route::post('/api-web/payments/batch', [PaymentApiController::class, 'storeBatch'])
        ->middleware('permission:can_process_payment')->name('api.payments.batch');

    // ── Isolir ────────────────────────────────────

    Route::get('/isolir', [IsolirController::class, 'index'])
        ->middleware('permission:can_manage_isolir')->name('isolir.index');
    Route::post('/isolir/{customer}/isolate', [IsolirController::class, 'isolate'])
        ->middleware('permission:can_manage_isolir')->name('isolir.isolate');
    Route::post('/isolir/{customer}/release', [IsolirController::class, 'release'])
        ->middleware('permission:can_manage_isolir')->name('isolir.release');

    // ── Reports (Laporan) ─────────────────────────
    Route::get('/reports/statistics', [ReportController::class, 'statistics'])
        ->middleware('permission:can_view_reports')->name('reports.statistics');
    Route::get('/reports/finance', [ReportController::class, 'finance'])
        ->middleware('permission:can_view_finance')->name('reports.finance');
    Route::get('/reports/detail-pendapatan', [ReportController::class, 'detailPendapatan'])
        ->middleware('permission:can_view_reports')->name('reports.detail-pendapatan');
    Route::get('/reports/pengeluaran', [ReportController::class, 'pengeluaran'])
        ->middleware('permission:can_view_finance')->name('reports.pengeluaran');
    Route::post('/reports/pengeluaran', [ReportController::class, 'storePengeluaran'])
        ->middleware('permission:can_manage_expenses')->name('reports.pengeluaran.store');
    Route::get('/reports/ppn', [ReportController::class, 'ppn'])
        ->middleware('permission:can_view_finance')->name('reports.ppn');
    Route::get('/reports/total', [ReportController::class, 'total'])
        ->middleware('permission:can_view_finance')->name('reports.total');
    Route::get('/reports/cashflow', [ReportController::class, 'cashflow'])
        ->middleware('permission:can_view_finance')->name('reports.cashflow');
    Route::get('/reports/fee', [ReportController::class, 'fee'])
        ->middleware('permission:can_view_finance')->name('reports.fee');
    Route::get('/reports/setoran', [ReportController::class, 'setoran'])
        ->middleware('permission:can_manage_deposits')->name('reports.setoran');
    Route::post('/reports/setoran', [ReportController::class, 'storeSetoran'])
        ->middleware('permission:can_manage_deposits')->name('reports.setoran.store');
    Route::get('/reports/mitra', [ReportController::class, 'mitra'])
        ->middleware('permission:can_view_finance')->name('reports.mitra');
    Route::get('/reports/saldo', [ReportController::class, 'saldo'])
        ->middleware('permission:can_view_finance')->name('reports.saldo');

    // ── Settings (Master Data) ────────────────────
    Route::get('/settings/users', [SettingsController::class, 'users'])
        ->middleware('permission:can_manage_users')->name('settings.users');
    Route::post('/settings/users', [SettingsController::class, 'storeUser'])
        ->middleware('permission:can_manage_users')->name('settings.users.store');
    Route::post('/settings/users/{targetUser}/toggle', [SettingsController::class, 'toggleUser'])
        ->middleware('permission:can_manage_users')->name('settings.users.toggle');
    Route::put('/settings/users/{targetUser}', [SettingsController::class, 'updateUser'])
        ->middleware('permission:can_manage_users')->name('settings.users.update');
    Route::post('/settings/users/{targetUser}/default-sales', [SettingsController::class, 'setDefaultSales'])
        ->middleware('permission:can_manage_users')->name('settings.users.default_sales');

    Route::get('/settings/packages', [SettingsController::class, 'packages'])
        ->middleware('permission:can_manage_packages')->name('settings.packages');
    Route::post('/settings/packages', [SettingsController::class, 'storePackage'])
        ->middleware('permission:can_manage_packages')->name('settings.packages.store');
    Route::put('/settings/packages/{package}', [SettingsController::class, 'updatePackage'])
        ->middleware('permission:can_manage_packages')->name('settings.packages.update');
    Route::delete('/settings/packages/{package}', [SettingsController::class, 'destroyPackage'])
        ->middleware('permission:can_manage_packages')->name('settings.packages.destroy');
    Route::get('/settings/packages/router/{router}/profiles', [SettingsController::class, 'routerProfiles'])
        ->middleware('permission:can_manage_packages')->name('settings.packages.router-profiles');

    Route::get('/settings/areas', [SettingsController::class, 'areas'])
        ->middleware('permission:can_manage_areas')->name('settings.areas');
    Route::post('/settings/areas', [SettingsController::class, 'storeArea'])
        ->middleware('permission:can_manage_areas')->name('settings.areas.store');

    Route::get('/settings/odps', [SettingsController::class, 'odps'])
        ->middleware('permission:can_manage_odp')->name('settings.odps');
    Route::post('/settings/odps', [SettingsController::class, 'storeOdp'])
        ->middleware('permission:can_manage_odp')->name('settings.odps.store');
    Route::delete('/settings/odps/{odp}', [SettingsController::class, 'destroyOdp'])
        ->middleware('permission:can_manage_odp')->name('settings.odps.destroy');

    Route::get('/settings/odcs', [SettingsController::class, 'odcs'])
        ->middleware('permission:can_manage_odp')->name('settings.odcs');
    Route::post('/settings/odcs', [SettingsController::class, 'storeOdc'])
        ->middleware('permission:can_manage_odp')->name('settings.odcs.store');
    Route::put('/settings/odcs/{odc}', [SettingsController::class, 'updateOdc'])
        ->middleware('permission:can_manage_odp')->name('settings.odcs.update');
    Route::delete('/settings/odcs/{odc}', [SettingsController::class, 'destroyOdc'])
        ->middleware('permission:can_manage_odp')->name('settings.odcs.destroy');

    Route::get('/settings/template-tagihan', [SettingsController::class, 'templateTagihan'])
        ->middleware('permission:can_edit_template')->name('settings.template-tagihan');
    Route::get('/settings/template-nota', [SettingsController::class, 'templateNota'])
        ->middleware('permission:can_edit_template')->name('settings.template-nota');

    // ── Config Module ─────────────────────────────
    Route::prefix('config')->middleware('permission:can_access_config')->group(function () {
        Route::get('/', [ConfigController::class, 'index'])->name('config.index');
        Route::get('/users', [ConfigController::class, 'users'])->name('config.users');
        Route::post('/users', [ConfigController::class, 'storeUser'])->name('config.users.store');
        Route::put('/users/{targetUser}', [ConfigController::class, 'updateUser'])->name('config.users.update');
        Route::post('/users/{targetUser}/toggle', [ConfigController::class, 'toggleUser'])->name('config.users.toggle');
        Route::post('/users/{targetUser}/default-sales', [ConfigController::class, 'setDefaultSales'])->name('config.users.default_sales');
        Route::get('/roles', [ConfigController::class, 'roles'])->name('config.roles');
        Route::post('/roles', [ConfigController::class, 'storeRole'])->name('config.roles.store');
        Route::put('/roles/{role}', [ConfigController::class, 'updateRole'])->name('config.roles.update');
        Route::delete('/roles/{role}', [ConfigController::class, 'destroyRole'])->name('config.roles.destroy');
        Route::get('/setting-nota', [ConfigController::class, 'settingNota'])->name('config.setting-nota');
        Route::post('/setting-nota', [ConfigController::class, 'updateSettingNota'])->name('config.setting-nota.update');
        Route::get('/wa-gateway', [ConfigController::class, 'waGateway'])->name('config.wa-gateway');
        Route::get('/router', [ConfigController::class, 'router'])->name('config.router');
        Route::post('/router', [ConfigController::class, 'storeRouter'])->name('config.router.store');
        Route::put('/router/{router}', [ConfigController::class, 'updateRouter'])->name('config.router.update');
        Route::delete('/router/{router}', [ConfigController::class, 'destroyRouter'])->name('config.router.destroy');
        Route::post('/router/{router}/toggle', [ConfigController::class, 'toggleRouter'])->name('config.router.toggle');
        Route::post('/router/{router}/test', [ConfigController::class, 'testRouter'])->name('config.router.test');
        Route::get('/router/{router}/config', [ConfigController::class, 'getRouterConfig'])->name('config.router.config');
        Route::post('/router/{router}/backup', [ConfigController::class, 'backupRouter'])->name('config.router.backup');
        Route::get('/router/{router}/backups', [ConfigController::class, 'listRouterBackups'])->name('config.router.backups');
        Route::get('/router/{router}/restore/{backup}', [ConfigController::class, 'restoreRouterBackup'])->name('config.router.restore');
        Route::get('/router/{router}/download/{backup}', [ConfigController::class, 'downloadBackup'])->name('config.router.download');

        Route::get('/server', [ConfigController::class, 'server'])->name('config.server');
        Route::post('/server', [ConfigController::class, 'storeServer'])->name('config.server.store');
        Route::put('/server/{server}', [ConfigController::class, 'updateServer'])->name('config.server.update');
        Route::delete('/server/{server}', [ConfigController::class, 'destroyServer'])->name('config.server.destroy');
        Route::post('/server/{server}/toggle', [ConfigController::class, 'toggleServer'])->name('config.server.toggle');
        Route::post('/server/{server}/test', [ConfigController::class, 'testServer'])->name('config.server.test');

        // RADIUS Server Management
        Route::get('/radius-server', [ConfigController::class, 'radiusServer'])->name('config.radius-server');
        Route::post('/radius-server', [ConfigController::class, 'storeRadiusServer'])->name('config.radius-server.store');
        Route::put('/radius-server/{server}', [ConfigController::class, 'updateRadiusServer'])->name('config.radius-server.update');
        Route::delete('/radius-server/{server}', [ConfigController::class, 'destroyRadiusServer'])->name('config.radius-server.destroy');
        Route::post('/radius-server/{server}/toggle', [ConfigController::class, 'toggleRadiusServer'])->name('config.radius-server.toggle');
        Route::post('/radius-server/{server}/test', [ConfigController::class, 'testRadiusServer'])->name('config.radius-server.test');

        Route::get('/backup', [ConfigController::class, 'backup'])->name('config.backup');
        Route::get('/log-sistem', [ConfigController::class, 'logSistem'])->name('config.log-sistem');
        Route::get('/db-pusat', [ConfigController::class, 'dbPusat'])->name('config.db-pusat');
        Route::post('/db-pusat', [ConfigController::class, 'updateDbPusat'])->name('config.db-pusat.update');
    });

    // ── Map Module ─────────────────────────────────
    Route::prefix('map')->middleware('permission:can_view_map')->group(function () {
        Route::get('/', [MapController::class, 'index'])->name('map.index');
        Route::post('/customer/{customer}/coordinate', [MapController::class, 'updateCoordinate'])
            ->name('map.coordinate.update');
        Route::delete('/customer/{customer}/coordinate', [MapController::class, 'deleteCoordinate'])
            ->name('map.coordinate.delete');
        Route::get('/api/customers', [MapController::class, 'apiCustomers'])->name('map.api.customers');
        Route::get('/api/odps', [MapController::class, 'apiOdps'])->name('map.api.odps');
        Route::get('/api/odcs', [MapController::class, 'apiOdcs'])->name('map.api.odcs');
    });

    // ── Monitoring/RADIUS Module ──────────────────
    Route::prefix('monitoring')->middleware('permission:can_view_monitor,can_access_mikrotik')->group(function () {
        Route::get('/', [MonitoringController::class, 'index'])->name('monitoring.index');
        Route::get('/router/{router}', [MonitoringController::class, 'routerDetail'])->name('monitoring.router.detail');
        Route::get('/router/{router}/active-json', [MonitoringController::class, 'activeConnections'])
            ->name('monitoring.active');
        Route::get('/router/{router}/resources-json', [MonitoringController::class, 'systemResources'])
            ->name('monitoring.resources');
        Route::post('/router/{router}/sync', [MonitoringController::class, 'syncPppoe'])
            ->middleware('permission:can_manage_pppoe')->name('monitoring.sync');
        Route::post('/router/{router}/isolir/{customer}', [MonitoringController::class, 'isolirCustomer'])
            ->middleware('permission:can_manage_pppoe')->name('monitoring.isolir');
        Route::post('/router/{router}/unisolir/{customer}', [MonitoringController::class, 'unisolirCustomer'])
            ->middleware('permission:can_manage_pppoe')->name('monitoring.unisolir');
    });

    // ── RADIUS Module ────────────────────────────
    Route::prefix('radius')->middleware('permission:can_access_radius,can_manage_pppoe')->group(function () {
        Route::get('/', [RadiusController::class, 'index'])->name('radius.index');
        Route::get('/router/{router}/secrets', [RadiusController::class, 'secrets'])->name('radius.secrets');
        Route::get('/router/{router}/profiles', [RadiusController::class, 'profiles'])->name('radius.profiles');
        Route::post('/router/{router}/sync', [RadiusController::class, 'sync'])
            ->middleware('permission:can_manage_pppoe')->name('radius.sync');
        Route::post('/router/{router}/isolir/{customer}', [RadiusController::class, 'isolir'])
            ->middleware('permission:can_manage_pppoe')->name('radius.isolir');
        Route::post('/router/{router}/unisolir/{customer}', [RadiusController::class, 'unisolir'])
            ->middleware('permission:can_manage_pppoe')->name('radius.unisolir');
    });
});

// ==================== SUPER ADMIN (Cross-Tenant) ====================
Route::prefix('superadmin')
    ->middleware(['auth', 'system_admin'])
    ->group(function () {
        Route::get('/', [SuperAdminController::class, 'index'])->name('superadmin.index');

        // Tenant CRUD
        Route::get('/tenants', [SuperAdminController::class, 'tenants'])->name('superadmin.tenants');
        Route::post('/tenants', [SuperAdminController::class, 'storeTenant'])->name('superadmin.tenants.store');
        Route::put('/tenants/{tenant}', [SuperAdminController::class, 'updateTenant'])->name('superadmin.tenants.update');
        Route::post('/tenants/{tenant}/toggle', [SuperAdminController::class, 'toggleTenant'])->name('superadmin.tenants.toggle');
        Route::delete('/tenants/{tenant}', [SuperAdminController::class, 'destroyTenant'])->name('superadmin.tenants.destroy');

        // Subscription
        Route::get('/subscriptions', [SuperAdminController::class, 'subscriptions'])->name('superadmin.subscriptions');
        Route::post('/subscriptions', [SuperAdminController::class, 'storeSubscription'])->name('superadmin.subscriptions.store');
        Route::put('/subscriptions/{subscription}', [SuperAdminController::class, 'updateSubscription'])->name('superadmin.subscriptions.update');

        // Tenant detail
        Route::get('/tenants/{tenant}/detail', [SuperAdminController::class, 'tenantDetail'])->name('superadmin.tenants.detail');

        // Profile
        Route::get('/profile', [SuperAdminController::class, 'profile'])->name('superadmin.profile');
        Route::put('/profile', [SuperAdminController::class, 'updateProfile'])->name('superadmin.profile.update');
    });

