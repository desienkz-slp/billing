@extends('layouts.app')
@section('title', 'Master ODP')
@section('content')
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <div><h1 style="font-size:22px; font-weight:700;">📡 Master ODP</h1><p style="color:var(--text-muted); font-size:14px;">{{ $odps->count() }} ODP terdaftar</p></div>
</div>
@if(session('success'))<div class="alert-success">✅ {{ session('success') }}</div>@endif
<div class="card" style="padding:16px; margin-bottom:16px;">
    <h3 style="font-size:15px; font-weight:600; margin-bottom:12px;">➕ Tambah ODP</h3>
    <form method="POST" action="{{ route('settings.odps.store') }}" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">@csrf
        <div><label class="form-label">Nama</label><input type="text" name="name" required class="form-input" placeholder="ODP-001"></div>
        <div><label class="form-label">Kode</label><input type="text" name="code" class="form-input" placeholder="Kode ODP"></div>
        <div><label class="form-label">Area</label><select name="area_id" class="form-input">@foreach($areas as $a)<option value="{{ $a->id }}">{{ $a->name }}</option>@endforeach</select></div>
        <div><label class="form-label">Kapasitas</label><input type="number" name="capacity" value="8" min="1" class="form-input"></div>
        <button type="submit" class="btn-primary">💾 Simpan</button>
    </form>
</div>
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>#</th><th>Nama</th><th>Kode</th><th>Area</th><th>Kapasitas</th><th>Terpakai</th><th>Sisa</th><th style="text-align:center">Aksi</th></tr></thead>
        <tbody>
        @forelse($odps as $i => $o)
        @php $used = $o->customers_count ?? 0; $sisa = ($o->capacity ?? 0) - $used; $pct = $o->capacity > 0 ? round($used / $o->capacity * 100) : 0; @endphp
        <tr>
            <td>{{ $i+1 }}</td><td><strong>{{ $o->name }}</strong></td><td style="font-size:12px;color:var(--text-muted)">{{ $o->code ?? '-' }}</td><td>{{ $o->area?->name ?? '-' }}</td>
            <td>{{ $o->capacity ?? 0 }}</td><td><div style="display:flex;align-items:center;gap:8px;"><div style="flex:1;height:6px;background:var(--border);border-radius:3px;overflow:hidden;min-width:60px;"><div style="height:100%;background:{{ $pct > 80 ? '#ef4444' : ($pct > 50 ? '#f59e0b' : '#22c55e') }};width:{{ $pct }}%;border-radius:3px;"></div></div><span style="font-size:12px;color:var(--text-muted)">{{ $used }}</span></div></td>
            <td style="color:{{ $sisa > 0 ? '#4ade80' : '#ef4444' }};font-weight:600">{{ $sisa }}</td>
            <td style="text-align:center"><form method="POST" action="{{ route('settings.odps.destroy', $o) }}" onsubmit="return confirm('Hapus ODP {{ $o->name }}?')">@csrf @method('DELETE')<button type="submit" class="action-btn btn-hapus">🗑</button></form></td>
        </tr>
        @empty
        <tr><td colspan="8" style="text-align:center;padding:40px;color:var(--text-muted);">Belum ada ODP.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
@endsection
@push('styles')<style>.alert-success{padding:12px 16px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:10px;color:#22c55e;margin-bottom:16px;font-size:14px}.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}.form-label{display:block;font-size:12px;color:var(--text-muted);margin-bottom:4px;font-weight:600}.form-input{padding:8px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg-body);color:var(--text);font-size:14px;font-family:inherit}.btn-primary{padding:8px 16px;background:var(--accent);color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit}.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:10px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}.action-btn{padding:4px 10px;border-radius:6px;font-size:12px;cursor:pointer;border:1px solid rgba(239,68,68,.3);background:rgba(239,68,68,.1);color:#ef4444;font-family:inherit}</style>@endpush
