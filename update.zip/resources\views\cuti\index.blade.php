@extends('layouts.app')
@section('title', 'Pelanggan Cuti')
@section('content')
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <div><h1 style="font-size:22px; font-weight:700;">⏸️ Pelanggan Cuti</h1><p style="color:var(--text-muted); font-size:14px;">{{ $customers->count() }} pelanggan cuti</p></div>
</div>
@if(session('success'))<div class="alert-success">✅ {{ session('success') }}</div>@endif
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>#</th><th>Nama</th><th>WA</th><th>Paket</th><th>Area</th><th>Sales</th><th style="text-align:center;">Aksi</th></tr></thead>
        <tbody>
        @forelse($customers as $i => $c)
        <tr>
            <td>{{ $i+1 }}</td>
            <td><strong>{{ $c->name }}</strong></td>
            <td>{{ $c->phone ?? '-' }}</td>
            <td>{{ $c->package?->name ?? '-' }}</td>
            <td>{{ $c->area?->name ?? '-' }}</td>
            <td>{{ $c->salesUser?->name ?? '-' }}</td>
            <td style="text-align:center; display:flex; gap:6px; justify-content:center;">
                <form method="POST" action="{{ route('cuti.restore', $c) }}" onsubmit="return confirm('Kembalikan {{ $c->name }} ke Daftar Pelanggan?')">@csrf<button type="submit" class="action-btn btn-restore"><i>↩</i> Kembalikan</button></form>
                <form method="POST" action="{{ route('cuti.destroy', $c) }}" onsubmit="return confirm('Hapus permanen {{ $c->name }}? Data tidak bisa dikembalikan!')">@csrf @method('DELETE')<button type="submit" class="action-btn btn-hapus"><i>🗑</i> Hapus</button></form>
            </td>
        </tr>
        @empty
        <tr><td colspan="7" style="text-align:center; padding:40px; color:var(--text-muted);">Tidak ada pelanggan cuti.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
@endsection
@push('styles')
<style>
.alert-success{padding:12px 16px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:10px;color:#22c55e;margin-bottom:16px;font-size:14px}
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}
.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:12px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}
.action-btn{padding:5px 12px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid;font-family:inherit;display:inline-flex;align-items:center;gap:4px}
.btn-restore{background:rgba(34,197,94,.1);border-color:rgba(34,197,94,.3);color:#22c55e}.btn-hapus{background:rgba(239,68,68,.1);border-color:rgba(239,68,68,.3);color:#ef4444}
</style>
@endpush
