@extends('layouts.app')
@section('title', 'Edit Pelanggan')

@section('content')
<div class="header-action" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <div>
        <h2 style="font-size:18px; font-weight:700;">Edit Pelanggan: {{ $customer->name }}</h2>
        <p style="font-size:13px; color:var(--text-muted); margin-top:4px;">Perbarui informasi profil atau layanan pelanggan ini.</p>
    </div>
    <a href="{{ route('customers.index') }}" class="btn-secondary" style="text-decoration:none;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        Kembali
    </a>
</div>

<div class="card" style="max-width:800px;">
    @if($errors->any())
    <div style="background:rgba(239,68,68,0.1); border:1px solid #ef4444; color:#991b1b; padding:12px 16px; border-radius:8px; margin-bottom:20px; font-size:13px;">
        <ul style="margin-left:20px; margin-bottom:0;">
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <form action="{{ route('customers.update', $customer->id) }}" method="POST">
        @csrf
        @method('PUT')
        
        <div class="form-row">
            <div class="form-group">
                <label>Nama Lengkap <span style="color:#ef4444;">*</span></label>
                <input type="text" name="name" value="{{ old('name', $customer->name) }}" class="input-field" required placeholder="Masukkan nama pelanggan">
            </div>
            <div class="form-group">
                <label>Username / ID PPPoe</label>
                <div style="display:flex; gap:8px;">
                    <input type="text" name="username" id="username_field" value="{{ old('username', $customer->username) }}" class="input-field" placeholder="Username (opsional)">
                    <button type="button" class="action-btn" style="padding:0 12px; height:38px; border:1px solid var(--border); border-radius:6px; background:var(--bg-body); cursor:pointer;" onclick="openPppoeSearch()" title="Cari PPPoE di Router/RADIUS">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                    </button>
                </div>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Nomor HP</label>
                <input type="text" name="phone" value="{{ old('phone', $customer->phone) }}" class="input-field" placeholder="Contoh: 08123456789">
            </div>
            <div class="form-group">
                <label>Password PPPoE</label>
                <input type="text" name="password_pppoe" value="{{ old('password_pppoe', $customer->password_pppoe) }}" class="input-field" placeholder="Password (opsional)">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group" style="grid-column: span 2;">
                <label>Alamat Lengkap</label>
                <input type="text" name="address" value="{{ old('address', $customer->address) }}" class="input-field" placeholder="Alamat rumah">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Pilih Paket <span style="color:#ef4444;">*</span></label>
                <select name="package_id" class="input-field" required>
                    <option value="">-- Pilih Paket --</option>
                    @foreach($packages as $pkg)
                        <option value="{{ $pkg->id }}" {{ old('package_id', $customer->package_id) == $pkg->id ? 'selected' : '' }}>
                            {{ $pkg->name }} - Rp {{ number_format($pkg->price,0,',','.') }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label>Pilih Area <span style="color:#ef4444;">*</span></label>
                <select name="area_id" class="input-field" required>
                    <option value="">-- Pilih Area --</option>
                    @foreach($areas as $area)
                        <option value="{{ $area->id }}" {{ old('area_id', $customer->area_id) == $area->id ? 'selected' : '' }}>
                            {{ $area->name }}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Router MikroTik</label>
                <select name="router_id" class="input-field">
                    <option value="">-- Tidak Terhubung ke Router --</option>
                    @foreach($routers as $r)
                        <option value="{{ $r->id }}" {{ old('router_id', $customer->router_id) == $r->id ? 'selected' : '' }}>
                            {{ $r->name }} ({{ $r->host }})
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label>Server RADIUS</label>
                <select name="server_id" class="input-field">
                    <option value="">-- Tidak Terhubung RADIUS --</option>
                    @foreach($servers as $s)
                        <option value="{{ $s->id }}" {{ old('server_id', $customer->server_id) == $s->id ? 'selected' : '' }}>
                            {{ $s->name }}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>ODP (Titik Distribusi)</label>
                <select name="odp_id" class="input-field">
                    <option value="">-- Tanpa ODP --</option>
                    @foreach($odps as $odp)
                        <option value="{{ $odp->id }}" {{ old('odp_id', $customer->odp_id) == $odp->id ? 'selected' : '' }}>
                            {{ $odp->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label>Penanggung Jawab (Sales / Agen) <span style="color:#ef4444;">*</span></label>
                <select name="sales_id" class="input-field" required>
                    @foreach($users as $u)
                        <option value="{{ $u->id }}" {{ old('sales_id', $customer->sales_id) == $u->id ? 'selected' : '' }}>
                            {{ $u->name }} ({{ $u->role->name ?? 'User' }})
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group" style="display: flex; gap: 10px; grid-column: span 2;">
                <div style="flex:1;">
                    <label>Latitude</label>
                    <input type="text" name="latitude" value="{{ old('latitude', $customer->coordinate?->latitude) }}" class="input-field" placeholder="Contoh: -6.200000">
                </div>
                <div style="flex:1;">
                    <label>Longitude</label>
                    <input type="text" name="longitude" value="{{ old('longitude', $customer->coordinate?->longitude) }}" class="input-field" placeholder="Contoh: 106.816666">
                </div>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Jenis Pembayaran <span style="color:#ef4444;">*</span></label>
                <select name="jenis_bayar" class="input-field" required>
                    <option value="prabayar" {{ old('jenis_bayar', $customer->jenis_bayar) == 'prabayar' ? 'selected' : '' }}>Prabayar (Bayar di awal)</option>
                    <option value="pascabayar" {{ old('jenis_bayar', $customer->jenis_bayar) == 'pascabayar' ? 'selected' : '' }}>Pascabayar (Bayar di akhir)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Status Pelanggan <span style="color:#ef4444;">*</span></label>
                <select name="status" class="input-field" required>
                    <option value="active" {{ old('status', $customer->status) == 'active' ? 'selected' : '' }}>Aktif</option>
                    <option value="inactive" {{ old('status', $customer->status) == 'inactive' ? 'selected' : '' }}>Non-Aktif</option>
                </select>
            </div>
        </div>

        <div class="form-row" style="margin-bottom:15px; padding:15px; background:var(--bg-body); border-radius:8px; border:1px solid var(--border);">
            <div style="display:flex; flex-direction:column; gap:12px; grid-column: span 2;">
                <div style="display:flex; align-items:center; gap:20px; flex-wrap:wrap;">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-weight:500;">
                        <input type="checkbox" name="auto_isolir" value="1" style="width:16px; height:16px; cursor:pointer;" {{ old('auto_isolir', $customer->auto_isolir) ? 'checked' : '' }}>
                        ISOLIR
                    </label>

                    <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:13px; color:var(--text-muted);">Telat:</span>
                        <input type="number" name="max_tunggakan" min="0" max="12" value="{{ old('max_tunggakan', $customer->max_tunggakan) }}" style="width:60px; padding:4px 8px; border-radius:4px; border:1px solid var(--border); background:var(--bg-card); color:var(--text-primary); text-align:center;">
                        <span style="font-size:13px; color:var(--text-muted);">bulan</span>
                    </div>

                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-weight:500;">
                        <input type="checkbox" name="pakai_ppn" value="1" style="width:16px; height:16px; cursor:pointer;" {{ old('pakai_ppn', $customer->pakai_ppn) ? 'checked' : '' }}>
                        PPN
                    </label>

                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-weight:500;">
                        <input type="checkbox" name="auto_wa_tagihan" value="1" style="width:16px; height:16px; cursor:pointer;" {{ old('auto_wa_tagihan', $customer->auto_wa_tagihan) ? 'checked' : '' }}>
                        WA
                    </label>

                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-weight:500; color:#3b82f6;" title="Kirim data akun ke Server Pusat via HTTP Request API">
                        <input type="checkbox" name="sync_db_pusat" value="1" style="width:16px; height:16px; cursor:pointer;" {{ old('sync_db_pusat', $customer->sync_db_pusat) ? 'checked' : '' }}>
                        Sync DB
                    </label>
                </div>
            </div>
        </div>

        <div style="margin-bottom:20px; padding:15px; background:var(--accent-bg); border-radius:8px; border:1px solid var(--border);">
            <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-weight:500;">
                <input type="checkbox" name="create_pppoe" value="1" style="width:16px; height:16px; cursor:pointer;" {{ old('create_pppoe') ? 'checked' : '' }}>
                Sinkronisasikan Perubahan ke Router / RADIUS saat disimpan
            </label>
            <p style="margin:4px 0 0 24px; font-size:12px; color:var(--text-muted);">
                Jika dicentang, sistem akan mengirimkan perintah ke MikroTik atau Server RADIUS untuk memperbarui kredensial pelanggan ini.
            </p>
        </div>

        <div style="border-top:1px solid var(--border); padding-top:20px; margin-top:10px; display:flex; justify-content:flex-end; gap:12px;">
            <a href="{{ route('customers.index') }}" class="btn-secondary">Batal</a>
            <button type="submit" class="btn-primary">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Simpan Perubahan
            </button>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<style>
/* Modal Styles */
.modal-overlay {
    display: none; position: fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.5); z-index:9999;
    align-items:center; justify-content:center;
}
.modal-content {
    background:var(--bg-card); width:90%; max-width:600px; border-radius:8px; padding:20px; box-shadow:0 10px 25px rgba(0,0,0,0.2);
    display:flex; flex-direction:column; max-height:80vh;
}
.modal-header {
    display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border); padding-bottom:12px; margin-bottom:12px;
}
.modal-title { font-size:16px; font-weight:600; color:var(--text-primary); }
.modal-close { background:none; border:none; cursor:pointer; color:var(--text-muted); padding:4px; border-radius:4px; }
.modal-close:hover { background:var(--bg-body); color:var(--text-primary); }
.pppoe-search-input { width:100%; padding:8px 12px; border:1px solid var(--border); border-radius:6px; margin-bottom:12px; background:var(--bg-body); color:var(--text-primary); }
.pppoe-list { flex:1; overflow-y:auto; border:1px solid var(--border); border-radius:6px; }
.pppoe-item { padding:10px 12px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; cursor:pointer; }
.pppoe-item:hover { background:var(--bg-body); }
.pppoe-item:last-child { border-bottom:none; }
.pppoe-name { font-weight:600; font-size:14px; }
.pppoe-source { font-size:12px; color:var(--text-muted); background:#e2e8f0; padding:2px 6px; border-radius:4px; }
.pppoe-loading { text-align:center; padding:20px; color:var(--text-muted); }
</style>

<!-- Modal Search PPPoE -->
<div id="pppoeModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-title">Cari User PPPoE Eksternal</div>
            <button class="modal-close" onclick="closePppoeSearch()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <input type="text" id="pppoeSearchText" class="pppoe-search-input" placeholder="Ketik nama untuk memfilter..." onkeyup="filterPppoeList()">
        <div id="pppoeListContainer" class="pppoe-list">
            <div class="pppoe-loading">Memuat data...</div>
        </div>
    </div>
</div>

<script>
let pppoeData = [];

function openPppoeSearch() {
    document.getElementById('pppoeModal').style.display = 'flex';
    document.getElementById('pppoeSearchText').value = '';
    const container = document.getElementById('pppoeListContainer');
    container.innerHTML = '<div class="pppoe-loading">Memuat data dari Router & RADIUS...</div>';

    fetch('{{ route("customers.search-pppoe") }}')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                pppoeData = data.data;
                renderPppoeList(pppoeData);
            } else {
                container.innerHTML = '<div class="pppoe-loading" style="color:#ef4444;">Gagal memuat data.</div>';
            }
        })
        .catch(err => {
            container.innerHTML = '<div class="pppoe-loading" style="color:#ef4444;">Terjadi kesalahan jaringan.</div>';
        });
}

function closePppoeSearch() {
    document.getElementById('pppoeModal').style.display = 'none';
}

function renderPppoeList(items) {
    const container = document.getElementById('pppoeListContainer');
    if (items.length === 0) {
        container.innerHTML = '<div class="pppoe-loading">Tidak ada data ditemukan.</div>';
        return;
    }

    container.innerHTML = items.map(item => {
        // Escape quotes for onclick
        const uname = (item.username || '').replace(/'/g, "\\'");
        const pass = (item.password || '').replace(/'/g, "\\'");
        return `
            <div class="pppoe-item" onclick="selectPppoe('${uname}', '${pass}', '${item.source_type}', '${item.source_id}')">
                <div>
                    <div class="pppoe-name">${item.username}</div>
                </div>
                <div class="pppoe-source">${item.source}</div>
            </div>
        `;
    }).join('');
}

function filterPppoeList() {
    const txt = document.getElementById('pppoeSearchText').value.toLowerCase();
    const filtered = pppoeData.filter(item => item.username.toLowerCase().includes(txt));
    renderPppoeList(filtered);
}

function selectPppoe(username, password, sourceType, sourceId) {
    document.getElementById('username_field').value = username;
    const passField = document.querySelector('input[name="password_pppoe"]');
    if (passField && password) passField.value = password; // Only fill if we got a password
    
    // Select Router / Server
    const routerSelect = document.querySelector('select[name="router_id"]');
    const serverSelect = document.querySelector('select[name="server_id"]');
    
    if (sourceType === 'router' && routerSelect) {
        routerSelect.value = sourceId;
        if (serverSelect) serverSelect.value = '';
    } else if (sourceType === 'radius' && serverSelect) {
        serverSelect.value = sourceId;
        if (routerSelect) routerSelect.value = '';
    }
    
    // Uncheck and Disable "Sinkronisasikan Perubahan ke Router / RADIUS saat disimpan"
    const createPppoeCheckbox = document.querySelector('input[name="create_pppoe"]');
    if (createPppoeCheckbox) {
        createPppoeCheckbox.checked = false;
        createPppoeCheckbox.disabled = true;
        
        // Let the user know why it's disabled visually
        const createPppoeLabel = createPppoeCheckbox.closest('label');
        if (createPppoeLabel) {
            createPppoeLabel.style.opacity = '0.5';
            createPppoeLabel.title = 'Dinonaktifkan karena Anda memilih user PPPoE yang sudah ada (hanya ditautkan)';
        }
    }
    
    closePppoeSearch();
}
</script>
@endpush

@push('styles')
<style>
    .btn-primary { display:inline-flex; align-items:center; gap:6px; padding:10px 20px; background:var(--gradient); border:none; border-radius:10px; color:white; font-size:14px; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s; }
    .btn-primary:hover { transform:translateY(-1px); box-shadow:0 4px 15px rgba(99,102,241,0.4); }
    .btn-secondary { display:inline-flex; align-items:center; gap:6px; padding:10px 20px; background:var(--bg-card); border:1px solid var(--border); border-radius:10px; color:var(--text-secondary); font-size:14px; font-weight:500; cursor:pointer; font-family:inherit; transition:all 0.2s; text-decoration:none; }
    .btn-secondary:hover { border-color:var(--accent); color:var(--accent); }

    .card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:24px; box-shadow:var(--shadow-sm); }
    
    .form-row { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px; }
    .form-group label { display:block; font-size:13px; font-weight:600; color:var(--text-secondary); margin-bottom:8px; }
    .input-field { width:100%; padding:10px 14px; background:var(--bg-body); border:1px solid var(--border); border-radius:8px; color:var(--text-primary); font-size:14px; font-family:inherit; outline:none; transition:all 0.2s; }
    .input-field:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(99,102,241,0.15); background:var(--bg-card); }
    select.input-field { cursor:pointer; }
    
    @media (max-width:640px) {
        .form-row { grid-template-columns:1fr; gap:16px; margin-bottom:16px; }
    }
</style>
@endpush
