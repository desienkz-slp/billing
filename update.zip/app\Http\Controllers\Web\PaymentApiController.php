<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Services\PaymentService;
use Illuminate\Http\Request;

class PaymentApiController extends Controller
{
    public function __construct(private PaymentService $paymentService) {}

    public function getMonths(Customer $customer, Request $request)
    {
        // Pastikan customer milik tenant yang sedang login
        if ($customer->tenant_id !== $request->user()->tenant_id) {
            return response()->json(['status' => 'error', 'message' => 'Unauthorized'], 403);
        }

        $paidMonths = $this->paymentService->getPaymentMonths($customer);
        
        $customerData = [
            'id' => $customer->id,
            'name' => $customer->name,
            'nama_paket' => $customer->package?->name,
            'harga' => $customer->getEffectivePrice(),
            'tgl_daftar' => $customer->registration_date?->toDateString(),
            'jenis_bayar' => $customer->jenis_bayar ?? 'prabayar',
            // Default diskon bisa diambil dari model jika ada, untuk sekarang 0
            'diskon_default' => 0, 
            'tambahan_layanan' => 0,
        ];

        return response()->json([
            'status' => 'success',
            'customer' => $customerData,
            'paid_months' => $paidMonths,
        ]);
    }

    public function storeSingle(Request $request)
    {
        $data = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'bulan_bayar' => 'required|array|min:1',
            'bulan_bayar.*' => 'date_format:Y-m',
            'tgl_bayar' => 'required|date',
            'metode' => 'required|string',
            'diskon' => 'nullable|integer|min:0',
            'paid_amount' => 'nullable|numeric|min:0', // Untuk partial payment
            'keterangan' => 'nullable|string|max:500',
        ]);

        $customer = Customer::findOrFail($data['customer_id']);
        if ($customer->tenant_id !== $request->user()->tenant_id) {
            return response()->json(['status' => 'error', 'message' => 'Unauthorized'], 403);
        }

        try {
            $result = $this->paymentService->processSinglePayment($customer, $data, $request->user());
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 400);
        }
    }

    public function storeBatch(Request $request)
    {
        $data = $request->validate([
            'customer_ids' => 'required|array|min:1',
            'customer_ids.*' => 'exists:customers,id',
            'sampai_bulan' => 'nullable|date_format:Y-m',
            'tgl_bayar' => 'required|date',
            'metode' => 'required|string',
            'keterangan' => 'nullable|string|max:500',
        ]);

        try {
            $count = $this->paymentService->processBatchPayment($data['customer_ids'], $data, $request->user());
            return response()->json([
                'status' => 'success',
                'message' => "{$count} pelanggan berhasil dibayar lunas.",
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Gagal memproses batch payment: ' . $e->getMessage()
            ], 500);
        }
    }
}
