@extends('layouts.superadmin')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
Profil Pengelola
@endsection
@section('content')
@if(session('success'))<div class="sa-alert ok">✅ {{ session('success') }}</div>@endif
@if(session('error'))<div class="sa-alert err">❌ {{ session('error') }}</div>@endif

<div class="sa-grid-2">
    {{-- FORM UBAH PROFIL --}}
    <div class="sa-card">
        <div class="sa-card-title">👤 Ubah Username & Profil</div>
        <form method="POST" action="{{ route('superadmin.profile.update') }}">
            @csrf
            @method('PUT')
            <div style="display:flex;flex-direction:column;gap:12px">
                <div>
                    <div class="sa-label">Nama Lengkap *</div>
                    <input type="text" name="name" class="sa-input" required value="{{ old('name', $user->name) }}">
                    @error('name')<div style="color:#f87171;font-size:.75rem;margin-top:4px">{{ $message }}</div>@enderror
                </div>
                <div>
                    <div class="sa-label">Username (untuk login) *</div>
                    <input type="text" name="username" class="sa-input" required value="{{ old('username', $user->username) }}">
                    @error('username')<div style="color:#f87171;font-size:.75rem;margin-top:4px">{{ $message }}</div>@enderror
                </div>
                <div>
                    <div class="sa-label">Email</div>
                    <input type="email" name="email" class="sa-input" value="{{ old('email', $user->email) }}" placeholder="opsional">
                    @error('email')<div style="color:#f87171;font-size:.75rem;margin-top:4px">{{ $message }}</div>@enderror
                </div>

                <div style="border-top:1px solid var(--border);padding-top:14px;margin-top:6px">
                    <div style="font-size:.72rem;color:var(--text-muted);text-transform:uppercase;font-weight:600;margin-bottom:10px">🔒 Ubah Password (kosongkan jika tidak ingin ubah)</div>
                    <div>
                        <div class="sa-label">Password Lama</div>
                        <input type="password" name="current_password" class="sa-input" placeholder="Masukkan password lama">
                        @error('current_password')<div style="color:#f87171;font-size:.75rem;margin-top:4px">{{ $message }}</div>@enderror
                    </div>
                    <div style="margin-top:8px">
                        <div class="sa-label">Password Baru</div>
                        <input type="password" name="new_password" class="sa-input" placeholder="Min 6 karakter">
                        @error('new_password')<div style="color:#f87171;font-size:.75rem;margin-top:4px">{{ $message }}</div>@enderror
                    </div>
                    <div style="margin-top:8px">
                        <div class="sa-label">Konfirmasi Password Baru</div>
                        <input type="password" name="new_password_confirmation" class="sa-input" placeholder="Ketik ulang password baru">
                    </div>
                </div>

                <button type="submit" class="sa-btn sa-btn-primary" style="margin-top:8px">💾 Simpan Perubahan</button>
            </div>
        </form>
    </div>

    {{-- INFO --}}
    <div class="sa-card">
        <div class="sa-card-title">ℹ️ Info Akun Saat Ini</div>
        <table style="width:100%;font-size:.85rem">
            <tr>
                <td style="color:var(--text-muted);padding:8px 0;width:130px">ID</td>
                <td style="padding:8px 0;color:#fff;font-weight:600">{{ $user->id }}</td>
            </tr>
            <tr>
                <td style="color:var(--text-muted);padding:8px 0">Nama</td>
                <td style="padding:8px 0;color:#fff;font-weight:600">{{ $user->name }}</td>
            </tr>
            <tr>
                <td style="color:var(--text-muted);padding:8px 0">Username</td>
                <td style="padding:8px 0"><code style="font-size:.85rem;color:var(--accent);background:rgba(249,115,22,.1);padding:3px 8px;border-radius:4px">{{ $user->username }}</code></td>
            </tr>
            <tr>
                <td style="color:var(--text-muted);padding:8px 0">Email</td>
                <td style="padding:8px 0">{{ $user->email ?: '-' }}</td>
            </tr>
            <tr>
                <td style="color:var(--text-muted);padding:8px 0">Role</td>
                <td style="padding:8px 0">{{ $user->role->name ?? '-' }}</td>
            </tr>
            <tr>
                <td style="color:var(--text-muted);padding:8px 0">Tenant</td>
                <td style="padding:8px 0">{{ $user->tenant->name ?? '-' }}</td>
            </tr>
            <tr>
                <td style="color:var(--text-muted);padding:8px 0">System Admin</td>
                <td style="padding:8px 0"><span class="sa-status sa-status-active">● Ya</span></td>
            </tr>
            <tr>
                <td style="color:var(--text-muted);padding:8px 0">Login Terakhir</td>
                <td style="padding:8px 0">{{ $user->last_login_at?->format('d/m/Y H:i') ?? '-' }}</td>
            </tr>
        </table>

        <div style="margin-top:20px;padding:14px;background:rgba(249,115,22,.08);border:1px solid rgba(249,115,22,.2);border-radius:8px;font-size:.82rem;color:#fb923c">
            <strong>💡 Tips:</strong> Ubah username dari <code style="color:#fff">superadmin</code> menjadi sesuatu yang unik (misal: <code style="color:#fff">owner</code> atau <code style="color:#fff">sysadmin</code>) agar tidak sama dengan username admin tenant.
        </div>
    </div>
</div>
@endsection
