@extends('layouts.app')
@section('title', 'Detail Pendapatan')
@section('content')
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:10px;">
    <div><h1 style="font-size:22px; font-weight:700;">🧾 Detail Pendapatan</h1><p style="color:var(--text-muted); font-size:14px;">Periode {{ \Carbon\Carbon::parse($month.'-01')->locale('id')->isoFormat('MMMM YYYY') }}</p></div>
</div>
<div class="kpi-grid">
    <div class="kpi-card kpi-green"><div class="kpi-label">Total Harga</div><div class="kpi-value">{{ number_format($totals['harga']) }}</div><div class="kpi-sub">{{ $totals['count'] }} transaksi</div></div>
    <div class="kpi-card kpi-red"><div class="kpi-label">Total Diskon</div><div class="kpi-value">{{ number_format($totals['diskon']) }}</div></div>
    <div class="kpi-card kpi-blue"><div class="kpi-label">Total PPN</div><div class="kpi-value">{{ number_format($totals['ppn']) }}</div></div>
    <div class="kpi-card kpi-cyan"><div class="kpi-label">Total Dibayar</div><div class="kpi-value">{{ number_format($totals['paid']) }}</div></div>
</div>
<div class="card" style="padding:16px; margin-bottom:16px;">
    <form method="GET" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
        <div><label class="form-label">Periode</label><input type="month" name="month" value="{{ $month }}" class="form-input"></div>
        <div><label class="form-label">Area</label><select name="area_id" class="form-input"><option value="">Semua</option>@foreach($areas as $a)<option value="{{ $a->id }}">{{ $a->name }}</option>@endforeach</select></div>
        <button type="submit" class="btn-primary">🔍 Filter</button>
        <a href="{{ route('reports.detail-pendapatan') }}" class="btn-secondary">↩ Reset</a>
    </form>
</div>
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>#</th><th>Tgl</th><th>Periode</th><th>Nama</th><th>Paket</th><th style="text-align:right">Harga</th><th style="text-align:right">Diskon</th><th style="text-align:right">PPN</th><th style="text-align:right">Dibayar</th></tr></thead>
        <tbody>
        @forelse($payments as $i => $p)
        <tr>
            <td>{{ $i+1 }}</td>
            <td style="font-size:12px; color:var(--text-muted)">{{ $p->payment_date->format('d/m/Y') }}</td>
            <td style="font-size:12px; color:#fbbf24; font-weight:500">{{ $p->period }}</td>
            <td><strong>{{ $p->customer?->name ?? '-' }}</strong></td>
            <td style="font-size:13px">{{ $p->customer?->package?->name ?? '-' }}</td>
            <td style="text-align:right; color:#86efac">{{ number_format($p->amount) }}</td>
            <td style="text-align:right; color:#fca5a5">{{ number_format($p->discount) }}</td>
            <td style="text-align:right; color:#fcd34d">{{ number_format($p->ppn_amount) }}</td>
            <td style="text-align:right; font-weight:600; color:#67e8f9">{{ number_format($p->paid_amount) }}</td>
        </tr>
        @empty
        <tr><td colspan="9" style="text-align:center; padding:40px; color:var(--text-muted);">Belum ada data pada periode ini.</td></tr>
        @endforelse
        @if($payments->count())
        <tr style="border-top:2px solid var(--border); font-weight:700; background:rgba(6,182,212,.06);">
            <td colspan="5" style="text-align:right">Total:</td>
            <td style="text-align:right; color:#86efac">{{ number_format($totals['harga']) }}</td>
            <td style="text-align:right; color:#fca5a5">{{ number_format($totals['diskon']) }}</td>
            <td style="text-align:right; color:#fcd34d">{{ number_format($totals['ppn']) }}</td>
            <td style="text-align:right; color:#67e8f9">{{ number_format($totals['paid']) }}</td>
        </tr>
        @endif
        </tbody>
    </table>
</div>
@endsection
@push('styles')
<style>
.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px}
.kpi-card{padding:20px;border-radius:var(--radius);border:1px solid var(--border)}.kpi-green{background:linear-gradient(135deg,#047857,#10b981)}.kpi-red{background:linear-gradient(135deg,#b91c1c,#dc2626)}.kpi-blue{background:linear-gradient(135deg,#1d4ed8,#3b82f6)}.kpi-cyan{background:linear-gradient(135deg,#0e7490,#06b6d4)}
.kpi-label{font-size:13px;color:rgba(255,255,255,.85);margin-bottom:4px}.kpi-value{font-size:24px;font-weight:800;color:#fff}.kpi-sub{font-size:12px;color:rgba(255,255,255,.7);margin-top:4px}
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}
.form-label{display:block;font-size:12px;color:var(--text-muted);margin-bottom:4px;font-weight:600}
.form-input{padding:8px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg-body);color:var(--text);font-size:14px;font-family:inherit}
.btn-primary{padding:8px 16px;background:var(--accent);color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit}
.btn-secondary{padding:8px 16px;background:var(--bg-body);color:var(--text-muted);border:1px solid var(--border);border-radius:8px;cursor:pointer;font-size:14px;text-decoration:none;font-family:inherit}
.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:10px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}
</style>
@endpush
