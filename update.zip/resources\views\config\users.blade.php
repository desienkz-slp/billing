@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
Kelola User
@endsection
@section('content')
@if(session('success'))
<div class="cfg-alert ok">{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="cfg-alert err">{{ session('error') }}</div>
@endif

<div class="cfg-grid-2">
    {{-- FORM TAMBAH --}}
    <div class="cfg-card">
        <div class="cfg-card-title">➕ Tambah User Baru</div>
        <form method="POST" action="{{ route('config.users.store') }}">
            @csrf
            <div style="display:flex;flex-direction:column;gap:10px">
                <div><div class="cfg-label">Nama Lengkap</div><input type="text" name="name" class="cfg-input" required placeholder="Nama lengkap"></div>
                <div><div class="cfg-label">Username</div><input type="text" name="username" class="cfg-input" required placeholder="username_login"></div>
                <div><div class="cfg-label">Email (opsional)</div><input type="email" name="email" class="cfg-input" placeholder="email@example.com"></div>
                <div><div class="cfg-label">No. HP (opsional)</div><input type="text" name="phone" class="cfg-input" placeholder="08xx"></div>
                <div><div class="cfg-label">Password</div><input type="password" name="password" class="cfg-input" required minlength="6" placeholder="Min 6 karakter"></div>
                <div>
                    <div class="cfg-label">Role</div>
                    <select name="role_id" class="cfg-input" required>
                        <option value="">-- Pilih Role --</option>
                        @foreach($roles as $r)
                        <option value="{{ $r->id }}">{{ $r->name }}</option>
                        @endforeach
                    </select>
                </div>
                <button type="submit" class="cfg-btn cfg-btn-primary">✓ Tambah User</button>
            </div>
        </form>
    </div>

    {{-- DAFTAR USER --}}
    <div class="cfg-card">
        <div class="cfg-card-title">👥 Daftar User ({{ $users->count() }})</div>
        <div style="max-height:65vh;overflow:auto">
            <table class="cfg-table">
                <thead><tr><th>#</th><th>Nama</th><th>Username</th><th>Role</th><th>Status</th><th style="text-align:center">Aksi</th></tr></thead>
                <tbody>
                    @forelse($users as $i => $u)
                    <tr>
                        <td>{{ $i+1 }}</td>
                        <td style="font-weight:600;color:var(--text-primary)">
                            {{ $u->name }}
                            @if($u->is_default_sales)
                                <span style="background:#f59e0b; color:white; font-size:10px; padding:2px 6px; border-radius:4px; margin-left:6px;">Default Sales</span>
                            @endif
                        </td>
                        <td><code>{{ $u->username }}</code></td>
                        <td>{{ $u->role->name ?? '-' }}</td>
                        <td>
                            @if($u->is_active)
                            <span style="color:#4ade80;font-size:.78rem">● Aktif</span>
                            @else
                            <span style="color:#f87171;font-size:.78rem">● Nonaktif</span>
                            @endif
                        </td>
                        <td style="text-align:center; display:flex; gap:6px; justify-content:center;">
                            <button type="button" class="cfg-btn cfg-btn-secondary" style="padding:4px 10px;font-size:.72rem" onclick="editUser({{ $u->id }}, '{{ addslashes($u->name) }}', '{{ addslashes($u->username) }}', '{{ addslashes($u->email) }}', '{{ addslashes($u->phone) }}', {{ $u->role_id }})">
                                Edit
                            </button>
                            <form method="POST" action="{{ route('config.users.toggle', $u) }}" style="display:inline">
                                @csrf
                                <button type="submit" class="cfg-btn {{ $u->is_active ? 'cfg-btn-danger' : 'cfg-btn-primary' }}" style="padding:4px 10px;font-size:.72rem">
                                    {{ $u->is_active ? '⏸ Nonaktifkan' : '▶ Aktifkan' }}
                                </button>
                            </form>
                            @if(!$u->is_default_sales)
                            <form method="POST" action="{{ route('config.users.default_sales', $u) }}" style="display:inline" onsubmit="return confirm('Jadikan {{ $u->name }} sebagai Penanggung Jawab Default?')">
                                @csrf
                                <button type="submit" class="cfg-btn cfg-btn-primary" style="padding:4px 10px;font-size:.72rem; background:#f59e0b;">
                                    Set Default
                                </button>
                            </form>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="6" style="text-align:center;color:var(--text-muted)">Belum ada user.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- MODAL EDIT --}}
<div id="editUserModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:999; align-items:center; justify-content:center;">
    <div class="cfg-card" style="width:100%; max-width:400px; margin:20px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <div class="cfg-card-title" style="margin:0;">Edit User</div>
            <button type="button" onclick="document.getElementById('editUserModal').style.display='none'" style="background:none; border:none; font-size:20px; cursor:pointer;">&times;</button>
        </div>
        <form id="editUserForm" method="POST" action="">
            @csrf
            @method('PUT')
            <div style="display:flex;flex-direction:column;gap:10px">
                <div><div class="cfg-label">Nama Lengkap</div><input type="text" name="name" id="edit_name" class="cfg-input" required></div>
                <div><div class="cfg-label">Username</div><input type="text" name="username" id="edit_username" class="cfg-input" required></div>
                <div><div class="cfg-label">Email</div><input type="email" name="email" id="edit_email" class="cfg-input"></div>
                <div><div class="cfg-label">No. HP</div><input type="text" name="phone" id="edit_phone" class="cfg-input"></div>
                <div><div class="cfg-label">Password (Biarkan kosong jika tidak diubah)</div><input type="password" name="password" class="cfg-input" minlength="6"></div>
                <div>
                    <div class="cfg-label">Role</div>
                    <select name="role_id" id="edit_role_id" class="cfg-input" required>
                        @foreach($roles as $r)
                        <option value="{{ $r->id }}">{{ $r->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div style="display:flex; gap:10px; margin-top:10px;">
                    <button type="button" onclick="document.getElementById('editUserModal').style.display='none'" class="cfg-btn cfg-btn-secondary" style="flex:1;">Batal</button>
                    <button type="submit" class="cfg-btn cfg-btn-primary" style="flex:1;">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function editUser(id, name, username, email, phone, role_id) {
    document.getElementById('editUserForm').action = '/config/users/' + id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_username').value = username;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_phone').value = phone;
    document.getElementById('edit_role_id').value = role_id;
    document.getElementById('editUserModal').style.display = 'flex';
}
</script>

@endsection
