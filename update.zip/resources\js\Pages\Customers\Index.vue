<template>
    <AppLayout title="Data Pelanggan">
        <Card bodyClass="!p-0">
            <!-- Header & Actions -->
            <div class="px-6 py-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                <div class="flex items-center gap-2 w-full md:w-auto">
                    <Input v-model="search" placeholder="Cari nama, username..." class="w-full md:w-64" @keyup.enter="doSearch" />
                    <Button @click="doSearch" variant="secondary">Cari</Button>
                </div>
                <div>
                    <Link :href="route('customers.create')" class="inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-lg font-medium text-sm bg-indigo-600 text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                        ➕ Tambah Pelanggan
                    </Link>
                </div>
            </div>

            <!-- Table -->
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama & Kontak</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Area</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Paket</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="customer in customers.data" :key="customer.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ customer.name }}</div>
                                <div class="text-sm text-slate-500">{{ customer.username || '-' }} | {{ customer.phone || '-' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                                {{ customer.area?.name || '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                                {{ customer.package?.name || '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span v-if="customer.is_isolated" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Isolir</span>
                                <span v-else-if="customer.is_on_leave" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-amber-100 text-amber-800">Cuti</span>
                                <span v-else-if="customer.status === 'active'" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-emerald-100 text-emerald-800">Aktif</span>
                                <span v-else class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-slate-100 text-slate-800">Non-Aktif</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button @click="showDetail(customer.id)" class="text-indigo-600 hover:text-indigo-900 mr-3" title="Detail">
                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                                </button>
                                <Link :href="route('customers.edit', customer.id)" class="text-blue-600 hover:text-blue-900 mr-3" title="Edit">
                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                </Link>
                                <button @click="confirmDelete(customer)" class="text-red-600 hover:text-red-900" title="Hapus">
                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            </td>
                        </tr>
                        <tr v-if="customers.data.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">
                                Belum ada data pelanggan yang ditemukan
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50" v-if="customers.links.length > 3">
                <div class="flex flex-wrap gap-1">
                    <template v-for="(link, p) in customers.links" :key="p">
                        <Link v-if="link.url" :href="link.url" :class="['px-3 py-1 rounded border text-sm', link.active ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600']" v-html="link.label"></Link>
                        <span v-else class="px-3 py-1 rounded border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 text-slate-400 text-sm cursor-not-allowed" v-html="link.label"></span>
                    </template>
                </div>
            </div>
        </Card>

        <!-- Detail Modal Placeholder (for now we use simple native confirm for delete) -->
        <Modal :show="isDetailModalOpen" @close="isDetailModalOpen = false" title="Detail Pelanggan">
            <div v-if="selectedCustomer" class="space-y-4">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <div class="text-sm text-slate-500">Nama</div>
                        <div class="font-medium dark:text-white">{{ selectedCustomer.name }}</div>
                    </div>
                    <div>
                        <div class="text-sm text-slate-500">Username</div>
                        <div class="font-medium dark:text-white">{{ selectedCustomer.username || '-' }}</div>
                    </div>
                    <div>
                        <div class="text-sm text-slate-500">Telepon</div>
                        <div class="font-medium dark:text-white">{{ selectedCustomer.phone || '-' }}</div>
                    </div>
                    <div>
                        <div class="text-sm text-slate-500">Paket</div>
                        <div class="font-medium dark:text-white">{{ selectedCustomer.package?.name || '-' }}</div>
                    </div>
                    <div class="col-span-2">
                        <div class="text-sm text-slate-500">Alamat</div>
                        <div class="font-medium dark:text-white">{{ selectedCustomer.address || '-' }}</div>
                    </div>
                </div>
            </div>
            <div v-else class="text-center py-4 text-slate-500">Memuat...</div>
            <template #footer>
                <div class="flex justify-end gap-2">
                    <Link v-if="selectedCustomer" :href="route('customers.edit', selectedCustomer.id)" class="inline-flex justify-center rounded-lg border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none sm:text-sm">
                        Edit
                    </Link>
                    <Button @click="isDetailModalOpen = false" variant="secondary">Tutup</Button>
                </div>
            </template>
        </Modal>

        <!-- Delete Form (Hidden) -->
        <form ref="deleteForm" method="POST" :action="deleteUrl" class="hidden">
            <input type="hidden" name="_method" value="DELETE">
            <input type="hidden" name="_token" :value="$page.props.csrf_token">
        </form>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { router, Link } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    customers: Object,
});

const search = ref(new URLSearchParams(window.location.search).get('search') || '');

const doSearch = () => {
    router.get(route('customers.index'), { search: search.value }, { preserveState: true });
};

// Detail Modal state
const isDetailModalOpen = ref(false);
const selectedCustomer = ref(null);

const showDetail = async (id) => {
    isDetailModalOpen.value = true;
    selectedCustomer.value = null;
    try {
        const response = await fetch(`/customers/${id}`);
        const res = await response.json();
        if (res.status === 'success') {
            selectedCustomer.value = res.data;
        }
    } catch (err) {
        console.error(err);
    }
};

const deleteForm = ref(null);
const deleteUrl = ref('');

const confirmDelete = (customer) => {
    if (confirm(`Apakah Anda yakin ingin menghapus pelanggan ${customer.name}? Data tidak akan benar-benar hilang (soft delete).`)) {
        router.delete(route('customers.destroy', customer.id));
    }
};
</script>
