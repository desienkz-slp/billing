<template>
    <AppLayout title="Edit Pelanggan">
        <div class="flex justify-between items-center mb-6">
            <div>
                <h2 class="text-xl font-bold text-slate-800 dark:text-white">Edit Pelanggan: {{ customer.name }}</h2>
                <p class="text-sm text-slate-500 mt-1">Ubah informasi pelanggan sesuai kebutuhan.</p>
            </div>
            <Link :href="route('customers.index')" class="inline-flex items-center px-4 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg font-medium text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 focus:outline-none transition-colors">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                Kembali
            </Link>
        </div>

        <Card>
            <form @submit.prevent="submit" class="space-y-6">
                <!-- Data Pribadi -->
                <div>
                    <h3 class="text-lg font-medium leading-6 text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-2 mb-4">Informasi Dasar</h3>
                    <div class="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                        <Input label="Nama Lengkap *" v-model="form.name" required :error="form.errors.name" />
                        
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Username / ID PPPoe</label>
                            <input type="text" v-model="form.username" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" placeholder="Username (opsional)">
                            <p v-if="form.errors.username" class="mt-1 text-sm text-red-600">{{ form.errors.username }}</p>
                        </div>

                        <Input label="Nomor HP" v-model="form.phone" placeholder="Contoh: 08123456789" :error="form.errors.phone" />
                        
                        <div>
                            <Input label="Password PPPoE Baru" v-model="form.password_pppoe" placeholder="Kosongkan jika tidak ingin mengubah" :error="form.errors.password_pppoe" />
                            <p class="mt-1 text-xs text-amber-600">Kosongkan kolom ini jika Anda tidak ingin mengubah password lama.</p>
                        </div>

                        <div class="sm:col-span-2">
                            <Input label="Alamat Lengkap" v-model="form.address" :error="form.errors.address" />
                        </div>
                    </div>
                </div>

                <!-- Paket & Area -->
                <div>
                    <h3 class="text-lg font-medium leading-6 text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-2 mb-4">Layanan & Jaringan</h3>
                    <div class="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Pilih Paket *</label>
                            <select v-model="form.package_id" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Pilih Paket --</option>
                                <option v-for="pkg in packages" :key="pkg.id" :value="pkg.id">{{ pkg.name }} - Rp {{ pkg.price }}</option>
                            </select>
                            <p v-if="form.errors.package_id" class="mt-1 text-sm text-red-600">{{ form.errors.package_id }}</p>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Pilih Area *</label>
                            <select v-model="form.area_id" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Pilih Area --</option>
                                <option v-for="area in areas" :key="area.id" :value="area.id">{{ area.name }}</option>
                            </select>
                            <p v-if="form.errors.area_id" class="mt-1 text-sm text-red-600">{{ form.errors.area_id }}</p>
                        </div>

                        <Input label="Diskon (Rp)" type="number" v-model="form.diskon" min="0" :error="form.errors.diskon" />
                        <Input label="Tambahan Layanan (Rp)" type="number" v-model="form.tambahan_layanan" min="0" :error="form.errors.tambahan_layanan" />

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Router MikroTik</label>
                            <select v-model="form.router_id" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Tidak Terhubung ke Router --</option>
                                <option v-for="r in routers" :key="r.id" :value="r.id">{{ r.name }} ({{ r.host }})</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Server RADIUS</label>
                            <select v-model="form.server_id" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Tidak Terhubung RADIUS --</option>
                                <option v-for="s in servers" :key="s.id" :value="s.id">{{ s.name }}</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">ODP (Titik Distribusi)</label>
                            <select v-model="form.odp_id" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Tanpa ODP --</option>
                                <option v-for="odp in odps" :key="odp.id" :value="odp.id">{{ odp.name }}</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Penanggung Jawab (Sales) *</label>
                            <select v-model="form.sales_id" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option v-for="u in users" :key="u.id" :value="u.id">{{ u.name }} ({{ u.role?.name || 'User' }})</option>
                            </select>
                        </div>

                        <div class="sm:col-span-2 grid grid-cols-2 gap-4">
                            <Input label="Latitude" v-model="form.latitude" placeholder="Contoh: -6.200000" />
                            <Input label="Longitude" v-model="form.longitude" placeholder="Contoh: 106.816666" />
                        </div>
                    </div>
                </div>

                <!-- Pengaturan Tagihan -->
                <div>
                    <h3 class="text-lg font-medium leading-6 text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-2 mb-4">Pengaturan Penagihan</h3>
                    <div class="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2 mb-6">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Jenis Pembayaran *</label>
                            <select v-model="form.jenis_bayar" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="prabayar">Prabayar (Bayar di awal)</option>
                                <option value="pascabayar">Pascabayar (Bayar di akhir)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Status Pelanggan *</label>
                            <select v-model="form.status" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="active">Aktif</option>
                                <option value="inactive">Non-Aktif</option>
                            </select>
                        </div>
                    </div>

                    <div class="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-lg border border-slate-200 dark:border-slate-700 space-y-4">
                        <div class="flex items-center gap-6 flex-wrap">
                            <label class="flex items-center gap-2 cursor-pointer font-medium text-slate-700 dark:text-slate-300">
                                <input type="checkbox" v-model="form.auto_isolir" class="rounded border-slate-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                ISOLIR
                            </label>
                            
                            <div class="flex items-center gap-2">
                                <span class="text-sm text-slate-500">Telat:</span>
                                <input type="number" v-model="form.max_tunggakan" min="0" max="12" class="w-16 p-1 text-center rounded border-slate-300 shadow-sm focus:border-indigo-500 sm:text-sm dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                                <span class="text-sm text-slate-500">bulan</span>
                            </div>

                            <label class="flex items-center gap-2 cursor-pointer font-medium text-slate-700 dark:text-slate-300">
                                <input type="checkbox" v-model="form.pakai_ppn" class="rounded border-slate-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                PPN
                            </label>

                            <label class="flex items-center gap-2 cursor-pointer font-medium text-slate-700 dark:text-slate-300">
                                <input type="checkbox" v-model="form.auto_wa_tagihan" class="rounded border-slate-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                WA Tagihan
                            </label>

                            <label class="flex items-center gap-2 cursor-pointer font-medium text-blue-600 dark:text-blue-400">
                                <input type="checkbox" v-model="form.sync_db_pusat" class="rounded border-slate-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                Sync DB Pusat (API)
                            </label>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end pt-5 border-t border-slate-200 dark:border-slate-700">
                    <Button type="submit" :disabled="form.processing">
                        {{ form.processing ? 'Menyimpan...' : '💾 Simpan Perubahan' }}
                    </Button>
                </div>
            </form>
        </Card>
    </AppLayout>
</template>

<script setup>
import { useForm, Link } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';

const props = defineProps({
    customer: Object,
    areas: Array,
    packages: Array,
    routers: Array,
    servers: Array,
    odps: Array,
    users: Array,
});

const form = useForm({
    name: props.customer.name,
    username: props.customer.username || '',
    phone: props.customer.phone || '',
    password_pppoe: '',
    address: props.customer.address || '',
    package_id: props.customer.package_id || '',
    area_id: props.customer.area_id || '',
    diskon: props.customer.diskon || 0,
    tambahan_layanan: props.customer.tambahan_layanan || 0,
    router_id: props.customer.router_id || '',
    server_id: props.customer.server_id || '',
    odp_id: props.customer.odp_id || '',
    sales_id: props.customer.sales_id || '',
    latitude: props.customer.coordinate?.latitude || '',
    longitude: props.customer.coordinate?.longitude || '',
    jenis_bayar: props.customer.jenis_bayar || 'prabayar',
    status: props.customer.status || 'active',
    auto_isolir: Boolean(props.customer.auto_isolir),
    max_tunggakan: props.customer.max_tunggakan || 1,
    pakai_ppn: Boolean(props.customer.pakai_ppn),
    auto_wa_tagihan: Boolean(props.customer.auto_wa_tagihan),
    sync_db_pusat: Boolean(props.customer.sync_db_pusat),
});

const submit = () => {
    form.put(route('customers.update', props.customer.id));
};
</script>
