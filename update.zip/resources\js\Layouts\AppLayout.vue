<template>
    <div class="flex h-screen bg-slate-50 text-slate-800" :data-theme="theme">
        <Sidebar :isOpen="isSidebarOpen" />
        
        <div class="flex-1 flex flex-col md:ml-[260px] min-w-0 transition-all duration-300">
            <div v-if="page.props.flash?.license_warning" class="license-banner" :class="{ 'expired': page.props.flash?.license_expired }">
                ⚠️ {{ page.props.flash.license_warning }}
            </div>

            <Header :title="title" @toggle-sidebar="isSidebarOpen = !isSidebarOpen" />

            <main class="flex-1 overflow-y-auto p-4 md:p-7">
                <div v-if="page.props.flash?.success" class="mb-4 p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700">
                    {{ page.props.flash.success }}
                </div>
                <div v-if="page.props.flash?.error" class="mb-4 p-4 rounded-lg bg-red-50 border border-red-200 text-red-700">
                    {{ page.props.flash.error }}
                </div>

                <slot />
            </main>
        </div>

        <!-- Mobile overlay -->
        <div v-if="isSidebarOpen" @click="isSidebarOpen = false" class="fixed inset-0 bg-black/50 z-40 md:hidden"></div>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { usePage } from '@inertiajs/vue3';
import Sidebar from '../Components/Sidebar.vue';
import Header from '../Components/Header.vue';

defineProps({
    title: {
        type: String,
        default: 'Dashboard'
    }
});

const page = usePage();
const isSidebarOpen = ref(false);
const theme = ref('light');

onMounted(() => {
    theme.value = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', theme.value);
});
</script>
