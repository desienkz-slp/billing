@php
    $user = auth()->user()?->load('role', 'tenant');
    $tenant = $user?->tenant;
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>PPPoE · {{ $router->name }} · RADIUS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{--bg:#0b1120;--bg-card:rgba(15,23,42,.7);--border:rgba(255,255,255,.08);--text:#e2e8f0;--muted:#64748b;--accent:#8b5cf6;--accent-glow:rgba(139,92,246,.15);--success:#22c55e;--danger:#ef4444;--warning:#f59e0b}
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text);min-height:100vh}

        .rh{padding:16px 28px;border-bottom:1px solid var(--border);background:rgba(11,17,32,.85);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
        .rh h1{font-size:1.1rem;font-weight:700;display:flex;align-items:center;gap:8px}
        .rh h1 svg{width:22px;height:22px;color:var(--accent)}
        .rh-actions{display:flex;gap:8px}
        .btn{padding:7px 14px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.06);color:var(--text);font-size:.8rem;font-weight:500;cursor:pointer;transition:all .2s;font-family:inherit;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
        .btn:hover{background:rgba(255,255,255,.12)}
        .btn-accent{background:linear-gradient(135deg,#8b5cf6,#6366f1);border:none;color:#fff}

        .rc{padding:20px 28px;max-width:1400px;margin:0 auto}

        /* Summary bar */
        .summary{display:flex;gap:16px;margin-bottom:20px;flex-wrap:wrap}
        .summary-item{display:flex;align-items:center;gap:8px;padding:10px 16px;background:var(--bg-card);border:1px solid var(--border);border-radius:10px;font-size:.82rem}
        .summary-value{font-weight:700;font-size:1rem}

        /* Tabs */
        .tabs{display:flex;gap:2px;border-bottom:1px solid var(--border);margin-bottom:16px}
        .tab{padding:10px 18px;border:none;background:none;color:var(--muted);font-size:.85rem;font-weight:500;cursor:pointer;border-bottom:2px solid transparent;font-family:inherit;transition:all .2s}
        .tab.active{color:var(--text);font-weight:600;border-bottom-color:var(--accent)}
        .tab:hover{color:var(--text)}

        /* Search */
        .search{width:100%;max-width:400px;padding:8px 14px;background:rgba(0,0,0,.3);border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:.85rem;font-family:inherit;outline:none;margin-bottom:14px}
        .search:focus{border-color:var(--accent)}

        /* Table */
        table{width:100%;border-collapse:collapse;font-size:.82rem}
        th{text-align:left;padding:10px 12px;color:var(--muted);font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid var(--border);position:sticky;top:0;background:var(--bg)}
        td{padding:8px 12px;border-bottom:1px solid rgba(255,255,255,.04)}
        tr:hover td{background:rgba(255,255,255,.02)}
        code{font-size:.78rem;color:var(--accent);background:rgba(139,92,246,.1);padding:2px 6px;border-radius:4px}

        /* Status badges */
        .badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:99px;font-size:.7rem;font-weight:600}
        .badge .dot{width:5px;height:5px;border-radius:50%;background:currentColor}
        .badge-online{background:rgba(34,197,94,.15);color:#4ade80}
        .badge-offline{background:rgba(100,116,139,.15);color:#94a3b8}
        .badge-disabled{background:rgba(239,68,68,.15);color:#f87171}

        /* Action buttons */
        .act{padding:4px 10px;border-radius:6px;border:none;font-size:.72rem;font-weight:600;cursor:pointer;font-family:inherit;transition:all .2s}
        .act-isolir{background:rgba(239,68,68,.15);color:#f87171}
        .act-isolir:hover{background:rgba(239,68,68,.25)}
        .act-unisolir{background:rgba(34,197,94,.15);color:#4ade80}
        .act-unisolir:hover{background:rgba(34,197,94,.25)}

        .tab-content{display:none}
        .tab-content.active{display:block}

        @media(max-width:768px){.rc{padding:12px}.summary{flex-direction:column}}
    </style>
</head>
<body>
    <header class="rh">
        <h1>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            {{ $router->name }}
            <span style="font-weight:400;color:var(--muted);font-size:.82rem">· {{ $router->host }}:{{ $router->port }}</span>
        </h1>
        <div class="rh-actions">
            <button class="btn btn-accent" onclick="syncPppoe()">🔄 Sync dari Router</button>
            <a href="{{ route('radius.index') }}" class="btn">← Kembali</a>
        </div>
    </header>

    <div class="rc">
        {{-- Summary --}}
        <div class="summary">
            <div class="summary-item">
                <span class="summary-value" style="color:var(--accent)">{{ $enrichedSecrets->count() }}</span>
                PPPoE Secrets
            </div>
            <div class="summary-item">
                <span class="summary-value" style="color:var(--success)">{{ collect($active)->count() }}</span>
                Aktif Online
            </div>
            <div class="summary-item">
                <span class="summary-value" style="color:var(--danger)">{{ $enrichedSecrets->where('disabled', true)->count() }}</span>
                Disabled
            </div>
            <div class="summary-item">
                <span class="summary-value" style="color:var(--warning)">{{ count($profiles) }}</span>
                Profiles
            </div>
        </div>

        {{-- Tabs --}}
        <div class="tabs">
            <button class="tab active" onclick="switchTab('secrets')">PPPoE Secrets</button>
            <button class="tab" onclick="switchTab('profiles')">Profiles</button>
        </div>

        {{-- Secrets Tab --}}
        <div class="tab-content active" id="tab-secrets">
            <input type="text" class="search" id="searchSecrets" placeholder="Cari username atau pelanggan..." oninput="filterTable()">
            <div style="overflow-x:auto">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Username</th>
                            <th>Profile</th>
                            <th>Service</th>
                            <th>Status</th>
                            <th>Pelanggan</th>
                            <th>Comment</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="secretsBody">
                        @foreach($enrichedSecrets as $i => $s)
                        <tr class="secret-row" data-search="{{ strtolower($s['name'] . ' ' . ($s['customer_name'] ?? '')) }}">
                            <td style="color:var(--muted)">{{ $i + 1 }}</td>
                            <td><code>{{ $s['name'] }}</code></td>
                            <td>{{ $s['profile'] }}</td>
                            <td style="color:var(--muted)">{{ $s['service'] }}</td>
                            <td>
                                @if($s['disabled'])
                                    <span class="badge badge-disabled"><span class="dot"></span> Disabled</span>
                                @elseif($s['is_online'])
                                    <span class="badge badge-online"><span class="dot"></span> Online</span>
                                @else
                                    <span class="badge badge-offline"><span class="dot"></span> Offline</span>
                                @endif
                            </td>
                            <td>
                                @if($s['customer_name'])
                                    <span style="color:#fff;font-weight:500">{{ $s['customer_name'] }}</span>
                                @else
                                    <span style="color:var(--muted)">—</span>
                                @endif
                            </td>
                            <td style="color:var(--muted);font-size:.75rem;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $s['comment'] ?: '—' }}</td>
                            <td>
                                @if($s['customer_id'])
                                    @if($s['disabled'])
                                    <button class="act act-unisolir" onclick="unisolir({{ $s['customer_id'] }}, '{{ $s['name'] }}')">Unisolir</button>
                                    @else
                                    <button class="act act-isolir" onclick="isolir({{ $s['customer_id'] }}, '{{ $s['name'] }}')">Isolir</button>
                                    @endif
                                @endif
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Profiles Tab --}}
        <div class="tab-content" id="tab-profiles">
            <div style="overflow-x:auto">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Rate Limit</th>
                            <th>Local Address</th>
                            <th>Remote Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($profiles as $i => $p)
                        <tr>
                            <td style="color:var(--muted)">{{ $i + 1 }}</td>
                            <td style="font-weight:600;color:#fff">{{ $p['name'] ?? '—' }}</td>
                            <td style="color:var(--accent)">{{ $p['rate-limit'] ?? '-' }}</td>
                            <td style="color:var(--muted)">{{ $p['local-address'] ?? '-' }}</td>
                            <td style="color:var(--muted)">{{ $p['remote-address'] ?? '-' }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
    var routerId = {{ $router->id }};
    var csrfToken = '{{ csrf_token() }}';

    function switchTab(tab) {
        document.querySelectorAll('.tab-content').forEach(function(el) { el.classList.remove('active'); });
        document.querySelectorAll('.tab').forEach(function(el) { el.classList.remove('active'); });
        document.getElementById('tab-' + tab).classList.add('active');
        event.target.classList.add('active');
    }

    function filterTable() {
        var q = document.getElementById('searchSecrets').value.toLowerCase();
        document.querySelectorAll('.secret-row').forEach(function(row) {
            row.style.display = row.dataset.search.indexOf(q) !== -1 ? '' : 'none';
        });
    }

    function syncPppoe() {
        if (!confirm('Sync PPPoE data dari router ini?')) return;
        fetch('/radius/router/' + routerId + '/sync', {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken},
        })
        .then(function(r) { return r.json(); })
        .then(function(res) { alert(res.message); if (res.status === 'success') location.reload(); })
        .catch(function() { alert('Gagal sync'); });
    }

    function isolir(customerId, name) {
        if (!confirm('Isolir "' + name + '"? Secret akan di-disable di router.')) return;
        fetch('/radius/router/' + routerId + '/isolir/' + customerId, {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken},
        })
        .then(function(r) { return r.json(); })
        .then(function(res) { alert(res.message); if (res.status === 'success') location.reload(); })
        .catch(function() { alert('Gagal isolir'); });
    }

    function unisolir(customerId, name) {
        if (!confirm('Unisolir "' + name + '"? Secret akan di-enable di router.')) return;
        fetch('/radius/router/' + routerId + '/unisolir/' + customerId, {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken},
        })
        .then(function(r) { return r.json(); })
        .then(function(res) { alert(res.message); if (res.status === 'success') location.reload(); })
        .catch(function() { alert('Gagal unisolir'); });
    }
    </script>
</body>
</html>
