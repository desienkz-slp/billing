@extends('layouts.superadmin')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
Subscription
@endsection
@section('content')
@if(session('success'))<div class="sa-alert ok">✅ {{ session('success') }}</div>@endif
@if(session('error'))<div class="sa-alert err">❌ {{ session('error') }}</div>@endif

<div class="sa-grid-2">
    {{-- FORM TAMBAH --}}
    <div class="sa-card">
        <div class="sa-card-title">➕ Tambah Subscription</div>
        <form method="POST" action="{{ route('superadmin.subscriptions.store') }}">
            @csrf
            <div style="display:flex;flex-direction:column;gap:10px">
                <div>
                    <div class="sa-label">Tenant *</div>
                    <select name="tenant_id" class="sa-input" required>
                        <option value="">-- Pilih Tenant --</option>
                        @foreach($tenants as $t)
                        <option value="{{ $t->id }}">{{ $t->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <div class="sa-label">Plan *</div>
                    <select name="plan" class="sa-input" required>
                        <option value="trial">Trial (30 hari)</option>
                        <option value="starter">Starter</option>
                        <option value="pro">Pro</option>
                        <option value="unlimited" selected>Unlimited</option>
                    </select>
                </div>
                <div>
                    <div class="sa-label">Max Pelanggan *</div>
                    <input type="number" name="max_customers" class="sa-input" required value="9999" min="1">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                    <div>
                        <div class="sa-label">Mulai *</div>
                        <input type="date" name="starts_at" class="sa-input" required value="{{ now()->format('Y-m-d') }}">
                    </div>
                    <div>
                        <div class="sa-label">Berakhir *</div>
                        <input type="date" name="expires_at" class="sa-input" required value="{{ now()->addYear()->format('Y-m-d') }}">
                    </div>
                </div>
                <div>
                    <div class="sa-label">Status</div>
                    <select name="status" class="sa-input">
                        <option value="active">Active</option>
                        <option value="grace">Grace Period</option>
                        <option value="expired">Expired</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                <button type="submit" class="sa-btn sa-btn-primary" style="margin-top:8px">📋 Tambah Subscription</button>
            </div>
        </form>
    </div>

    {{-- DAFTAR --}}
    <div class="sa-card">
        <div class="sa-card-title">📋 Semua Subscription ({{ $subscriptions->count() }})</div>
        <div style="max-height:70vh;overflow:auto">
            <table class="sa-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tenant</th>
                        <th>Plan</th>
                        <th>Max Cust.</th>
                        <th>License Key</th>
                        <th>Mulai</th>
                        <th>Berakhir</th>
                        <th>Status</th>
                        <th style="text-align:center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($subscriptions as $i => $s)
                    @php
                        $statusClass = match($s->status) {
                            'active' => $s->expires_at->isFuture() ? 'active' : 'expired',
                            'grace' => 'grace',
                            default => 'expired',
                        };
                    @endphp
                    <tr>
                        <td>{{ $i+1 }}</td>
                        <td style="font-weight:600;color:#fff">{{ $s->tenant->name ?? '(deleted)' }}</td>
                        <td><span class="sa-status sa-status-active" style="background:rgba(249,115,22,.12);color:#fb923c">{{ ucfirst($s->plan) }}</span></td>
                        <td>{{ number_format($s->max_customers) }}</td>
                        <td><code style="font-size:.7rem">{{ Str::limit($s->license_key, 16) }}</code></td>
                        <td style="font-size:.78rem">{{ $s->starts_at->format('d/m/Y') }}</td>
                        <td style="font-size:.78rem">{{ $s->expires_at->format('d/m/Y') }}</td>
                        <td><span class="sa-status sa-status-{{ $statusClass }}">{{ ucfirst($s->status) }}</span></td>
                        <td style="text-align:center">
                            <button class="sa-btn sa-btn-secondary" style="padding:4px 10px;font-size:.72rem" onclick="editSub({{ $s->id }})">✏️</button>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:30px">Belum ada subscription.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- MODAL EDIT --}}
<div class="sa-modal-overlay" id="editSubModal">
    <div class="sa-modal">
        <div class="sa-modal-header">
            <h3>✏️ Edit Subscription</h3>
            <button class="sa-modal-close" onclick="document.getElementById('editSubModal').classList.remove('show')">&times;</button>
        </div>
        <div id="editSubMsg" class="sa-alert"></div>
        <form id="editSubForm">
            <input type="hidden" id="editSubId">
            <div style="display:flex;flex-direction:column;gap:10px">
                <div>
                    <div class="sa-label">Plan</div>
                    <select id="editSubPlan" class="sa-input">
                        <option value="trial">Trial</option>
                        <option value="starter">Starter</option>
                        <option value="pro">Pro</option>
                        <option value="unlimited">Unlimited</option>
                    </select>
                </div>
                <div>
                    <div class="sa-label">Max Pelanggan</div>
                    <input type="number" id="editSubMax" class="sa-input" min="1">
                </div>
                <div>
                    <div class="sa-label">Berakhir</div>
                    <input type="date" id="editSubExpires" class="sa-input">
                </div>
                <div>
                    <div class="sa-label">Status</div>
                    <select id="editSubStatus" class="sa-input">
                        <option value="active">Active</option>
                        <option value="grace">Grace Period</option>
                        <option value="expired">Expired</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                <div style="display:flex;gap:8px;margin-top:12px">
                    <button type="submit" class="sa-btn sa-btn-primary">✓ Simpan</button>
                    <button type="button" class="sa-btn sa-btn-secondary" onclick="document.getElementById('editSubModal').classList.remove('show')">Batal</button>
                </div>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
var subsData = @json($subscriptions->keyBy('id'));

function editSub(id) {
    var s = subsData[id];
    if (!s) return;
    document.getElementById('editSubId').value = id;
    document.getElementById('editSubPlan').value = s.plan || 'trial';
    document.getElementById('editSubMax').value = s.max_customers || 50;
    document.getElementById('editSubExpires').value = s.expires_at ? s.expires_at.substring(0, 10) : '';
    document.getElementById('editSubStatus').value = s.status || 'active';
    document.getElementById('editSubModal').classList.add('show');
}

document.getElementById('editSubForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var id = document.getElementById('editSubId').value;
    var data = {
        plan: document.getElementById('editSubPlan').value,
        max_customers: parseInt(document.getElementById('editSubMax').value),
        expires_at: document.getElementById('editSubExpires').value,
        status: document.getElementById('editSubStatus').value,
    };
    fetch('/superadmin/subscriptions/' + id, {
        method: 'PUT',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}'},
        body: JSON.stringify(data)
    })
    .then(function(r) { return r.json(); })
    .then(function(res) {
        if (res.status === 'success') location.reload();
        else { var m = document.getElementById('editSubMsg'); m.className='sa-alert err'; m.textContent=res.message; }
    });
});
</script>
@endpush
@endsection
