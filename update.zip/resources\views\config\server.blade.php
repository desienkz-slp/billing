@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><circle cx="6" cy="6" r="1"/><circle cx="6" cy="18" r="1"/></svg>
Server Geniacs
@endsection
@section('content')
<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.7fr);gap:16px;align-items:flex-start">
    {{-- FORM TAMBAH / EDIT --}}
    <div class="cfg-card">
        <div class="cfg-card-title" id="serverFormTitle">➕ Tambah Server</div>
        <div id="serverFormMsg" class="cfg-alert" style="margin-bottom:8px"></div>
        <input type="hidden" id="sId">
        <div style="display:flex;flex-direction:column;gap:10px">
            <div>
                <div class="cfg-label">Nama Server</div>
                <input type="text" id="sNama" class="cfg-input" placeholder="Contoh: Server Geniacs Utama">
            </div>
            <div>
                <div class="cfg-label">IP Address</div>
                <input type="text" id="sIp" class="cfg-input" placeholder="192.168.1.100">
            </div>
            <div>
                <div class="cfg-label">Port</div>
                <input type="number" id="sPort" class="cfg-input" placeholder="7557" value="7557">
            </div>
            <div>
                <div class="cfg-label">Username <span style="color:var(--text-muted);font-weight:400">(opsional)</span></div>
                <input type="text" id="sUser" class="cfg-input" placeholder="admin (opsional)" autocomplete="off">
            </div>
            <div>
                <div class="cfg-label">Password <span style="color:var(--text-muted);font-weight:400">(opsional)</span> <span id="sPassHint" style="color:var(--text-muted);display:none">(kosong = tidak diubah)</span></div>
                <input type="password" id="sPass" class="cfg-input" placeholder="•••••• (opsional)" autocomplete="new-password">
            </div>
            <div style="display:flex;gap:8px;margin-top:4px">
                <button id="sSaveBtn" class="cfg-btn cfg-btn-primary" style="flex:1" onclick="saveServer()">✓ Simpan</button>
                <button id="sCancelBtn" class="cfg-btn cfg-btn-secondary" style="display:none" onclick="resetServerForm()">✕ Batal</button>
            </div>
        </div>
    </div>

    {{-- DAFTAR SERVER --}}
    <div class="cfg-card">
        <div class="cfg-card-title">📋 Daftar Server</div>
        <div id="serverListMsg" class="cfg-alert" style="margin-bottom:8px"></div>
        <div style="max-height:60vh;overflow:auto">
            <table class="cfg-table">
                <thead>
                    <tr>
                        <th>#</th><th>Nama</th><th>IP Address</th><th>Port</th>
                        <th style="text-align:center">Status</th>
                        <th style="text-align:center">Aksi</th>
                    </tr>
                </thead>
                <tbody id="serverTb">
                    <tr><td colspan="6" style="text-align:center;color:var(--text-muted)">Memuat…</td></tr>
                </tbody>
            </table>
        </div>
        <p style="font-size:.75rem;color:var(--text-muted);margin-top:12px">
            ℹ️ Server <span style="color:var(--success);font-weight:600">Aktif</span> terhubung dengan sistem Geniacs (ACS/TR-069).
        </p>
    </div>
</div>

@push('styles')
<style>
    .s-btn{display:inline-flex;align-items:center;gap:3px;padding:3px 8px;border-radius:6px;border:1px solid var(--border);background:rgba(0,0,0,.3);color:var(--text-secondary);font-size:.72rem;cursor:pointer;transition:all .15s;font-family:inherit}
    .s-btn:hover{background:rgba(255,255,255,.08);color:var(--text-primary)}
    .s-btn.edit{border-color:rgba(14,165,233,.5)}
    .s-btn.del{border-color:rgba(239,68,68,.5)}
    .s-btn.test{border-color:rgba(168,85,247,.5)}
    .s-btn.toggle-on{border-color:rgba(234,179,8,.5);color:#fde047}
    .s-btn.toggle-off{border-color:rgba(34,197,94,.5)}
    .badge-on{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.4);color:#4ade80;font-size:.7rem;font-weight:600}
    .badge-off{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(100,116,139,.08);border:1px solid rgba(100,116,139,.3);color:var(--text-muted);font-size:.7rem}
    @media(max-width:900px){
        div[style*="grid-template-columns:minmax(0,1fr) minmax(0,1.7fr)"]{grid-template-columns:1fr !important}
    }
</style>
@endpush

@push('scripts')
<script>
const CSRF = '{{ csrf_token() }}';
const ROUTES = {
    list: '{{ route("config.server") }}',
    store: '{{ route("config.server.store") }}',
    update: id => `/config/server/${id}`,
    destroy: id => `/config/server/${id}`,
    toggle: id => `/config/server/${id}/toggle`,
    test: id => `/config/server/${id}/test`,
};
let editing = false;

function resetServerForm(){
    editing = false;
    document.getElementById('sId').value = '';
    ['sNama','sIp','sUser','sPass'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('sPort').value = '7557';
    document.getElementById('serverFormTitle').textContent = '➕ Tambah Server';
    document.getElementById('sCancelBtn').style.display = 'none';
    document.getElementById('sPassHint').style.display = 'none';
    hideMsg('serverFormMsg');
}

function loadServers(){
    fetch(ROUTES.list, {headers:{'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res => {
        const tb = document.getElementById('serverTb');
        if(!res.data || !res.data.length){
            tb.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted)">Belum ada server. Tambahkan di form kiri.</td></tr>';
            return;
        }
        tb.innerHTML = res.data.map((s,i) => {
            const active = s.is_active;
            return `<tr>
                <td>${i+1}</td>
                <td style="font-weight:${active?'600':'400'};color:${active?'var(--text-primary)':'var(--text-muted)'}">${esc(s.name)}</td>
                <td><code>${esc(s.host)}</code></td>
                <td>${s.port}</td>
                <td style="text-align:center">${active?'<span class="badge-on">● Aktif</span>':'<span class="badge-off">Nonaktif</span>'}</td>
                <td style="text-align:center">
                    <div style="display:flex;gap:4px;justify-content:center;flex-wrap:wrap">
                        <button class="s-btn test" onclick="testServer(${s.id},'${esc(s.name)}')">🔌 Tes</button>
                        ${active
                            ?`<button class="s-btn toggle-on" onclick="toggleServer(${s.id},'${esc(s.name)}')">⏸</button>`
                            :`<button class="s-btn toggle-off" onclick="toggleServer(${s.id},'${esc(s.name)}')">▶ Aktifkan</button>`}
                        <button class="s-btn edit" onclick='editServer(${JSON.stringify(s)})'>✏️</button>
                        <button class="s-btn del" onclick="deleteServer(${s.id},'${esc(s.name)}')">🗑</button>
                    </div>
                </td>
            </tr>`;
        }).join('');
    })
    .catch(() => {
        document.getElementById('serverTb').innerHTML = '<tr><td colspan="6" style="text-align:center;color:#f87171">Gagal memuat data.</td></tr>';
    });
}

function saveServer(){
    const id = document.getElementById('sId').value;
    const payload = {
        name: document.getElementById('sNama').value.trim(),
        host: document.getElementById('sIp').value.trim(),
        port: parseInt(document.getElementById('sPort').value || '7557'),
        username: document.getElementById('sUser').value.trim() || null,
        password: document.getElementById('sPass').value || null,
    };

    if(!payload.name || !payload.host || !payload.port){
        showMsg('serverFormMsg','err','Nama, IP address, dan port wajib diisi.');
        return;
    }

    const url = editing ? ROUTES.update(id) : ROUTES.store;
    const method = editing ? 'PUT' : 'POST';

    const btn = document.getElementById('sSaveBtn');
    btn.disabled = true; btn.textContent = 'Menyimpan…';

    fetch(url, {
        method, headers:{'Content-Type':'application/json','X-CSRF-TOKEN':CSRF,'Accept':'application/json'},
        body: JSON.stringify(payload)
    })
    .then(r=>r.json())
    .then(res => {
        if(res.status==='success'){ showMsg('serverFormMsg','ok',res.message); resetServerForm(); loadServers(); }
        else showMsg('serverFormMsg','err',res.message||'Gagal menyimpan.');
    })
    .catch(()=>showMsg('serverFormMsg','err','Gagal menghubungi server.'))
    .finally(()=>{ btn.disabled=false; btn.textContent='✓ Simpan'; });
}

function editServer(s){
    editing = true;
    document.getElementById('sId').value = s.id;
    document.getElementById('sNama').value = s.name;
    document.getElementById('sIp').value = s.host;
    document.getElementById('sPort').value = s.port;
    document.getElementById('sUser').value = s.username || '';
    document.getElementById('sPass').value = '';
    document.getElementById('serverFormTitle').textContent = '✏️ Edit Server';
    document.getElementById('sCancelBtn').style.display = 'inline-flex';
    document.getElementById('sPassHint').style.display = 'inline';
    hideMsg('serverFormMsg');
    window.scrollTo({top:0,behavior:'smooth'});
}

function deleteServer(id, name){
    if(!confirm(`Hapus server "${name}"?`)) return;
    fetch(ROUTES.destroy(id), {method:'DELETE',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{ showMsg('serverListMsg',res.status==='success'?'ok':'err',res.message); if(res.status==='success') loadServers(); })
    .catch(()=>showMsg('serverListMsg','err','Gagal menghubungi server.'));
}

function toggleServer(id, name){
    if(!confirm(`Toggle status server "${name}"?`)) return;
    fetch(ROUTES.toggle(id), {method:'POST',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{ showMsg('serverListMsg',res.status==='success'?'ok':'err',res.message); if(res.status==='success') loadServers(); })
    .catch(()=>showMsg('serverListMsg','err','Gagal.'));
}

function testServer(id, name){
    showMsg('serverListMsg','info',`Mengecek koneksi ke "${name}"…`);
    fetch(ROUTES.test(id), {method:'POST',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>showMsg('serverListMsg',res.status==='success'?'ok':'err',res.message))
    .catch(()=>showMsg('serverListMsg','err','Gagal menghubungi server.'));
}

function showMsg(elId, cls, msg){
    const el = document.getElementById(elId);
    el.className = 'cfg-alert ' + cls;
    el.textContent = msg;
    el.style.display = 'block';
    if(cls !== 'info') setTimeout(()=>{ el.style.display='none'; }, 5000);
}
function hideMsg(elId){ document.getElementById(elId).style.display='none'; }
function esc(s){ return (s||'').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

// Init
loadServers();
</script>
@endpush
@endsection
