<?php
namespace App\Models;

use App\Traits\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AuditLog extends Model
{
    use BelongsToTenant;
    protected $guarded = ['id'];
    protected $casts = ['old_values' => 'array', 'new_values' => 'array'];
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
