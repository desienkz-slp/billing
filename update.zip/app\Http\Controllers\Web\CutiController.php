<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Services\PermissionService;
use Illuminate\Http\Request;

class CutiController extends Controller
{
    public function __construct(private PermissionService $permissionService) {}

    public function index(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;

        $customers = Customer::with(['package', 'area', 'sales'])
            ->where('is_on_leave', true)
            ->orderByDesc('id')
            ->get();

        return view('cuti.index', compact('user', 'capabilities', 'tenant', 'customers'));
    }

    public function store(Request $request, Customer $customer)
    {
        $customer->update([
            'is_on_leave' => true,
            'status' => 'inactive',
            'leave_start' => now(),
        ]);

        return back()->with('success', "{$customer->name} berhasil dinonaktifkan (Cuti).");
    }

    public function restore(Request $request, Customer $customer)
    {
        $customer->update([
            'is_on_leave' => false,
            'status' => 'active',
            'leave_start' => null,
            'leave_end' => null,
        ]);

        return back()->with('success', "{$customer->name} berhasil dikembalikan ke Daftar Pelanggan.");
    }

    public function destroy(Customer $customer)
    {
        $name = $customer->name;
        $customer->forceDelete();
        return back()->with('success', "{$name} berhasil dihapus permanen.");
    }
}
