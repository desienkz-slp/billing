@extends('layouts.app')
@section('title', 'Users & Roles')
@section('content')
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <div><h1 style="font-size:22px; font-weight:700;">👤 Users & Roles</h1><p style="color:var(--text-muted); font-size:14px;">{{ $users->count() }} pengguna</p></div>
    <button class="btn-primary" onclick="document.getElementById('addUserModal').style.display='flex'">+ Tambah User</button>
</div>
@if(session('success'))<div class="alert-success">✅ {{ session('success') }}</div>@endif
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>Nama</th><th>Username</th><th>Role</th><th>Email</th><th>Status</th><th>Login Terakhir</th><th>Aksi</th></tr></thead>
        <tbody>
        @foreach($users as $u)
        <tr>
            <td>
                <strong>{{ $u->name }}</strong>
                <div style="font-size:11px; color:var(--text-muted);">
                    @if($u->fee_persen > 0) Fee: {{ (float)$u->fee_persen }}% @endif
                    @if($u->fee_fix > 0) +Rp{{ number_format($u->fee_fix, 0, ',', '.') }} @endif
                </div>
                @if($u->is_default_sales)
                    <span class="badge" style="background:#f59e0b; color:white; font-size:10px; margin-left:8px;">Default Sales</span>
                @endif
            </td>
            <td style="font-family:monospace; font-size:13px;">{{ $u->username }}</td>
            <td><span class="badge">{{ $u->role?->name ?? '-' }}</span></td>
            <td style="font-size:13px; color:var(--text-muted);">{{ $u->email ?? '-' }}</td>
            <td>
                @if($u->is_active)<span class="status-badge status-success">Aktif</span>
                @else<span class="status-badge status-muted">Non-Aktif</span>@endif
            </td>
            <td style="font-size:13px; color:var(--text-muted);">{{ $u->last_login_at ? \Carbon\Carbon::parse($u->last_login_at)->diffForHumans() : 'Belum pernah' }}</td>
            <td>
                <form method="POST" action="{{ route('settings.users.toggle', $u) }}" style="display:inline;" onsubmit="return confirm('{{ $u->is_active ? 'Nonaktifkan' : 'Aktifkan' }} {{ $u->name }}?')">
                    @csrf
                    <button type="submit" class="action-btn-sm {{ $u->is_active ? 'btn-danger-sm' : 'btn-success-sm' }}">{{ $u->is_active ? 'Disable' : 'Enable' }}</button>
                </form>
                @if(!$u->is_default_sales)
                <form method="POST" action="{{ route('settings.users.default_sales', $u) }}" style="display:inline;" onsubmit="return confirm('Jadikan {{ $u->name }} sebagai Penanggung Jawab Default?')">
                    @csrf
                    <button type="submit" class="action-btn-sm btn-primary" style="padding:4px 8px; font-size:11px;">Set Default Sales</button>
                </form>
                @endif
                <button type="button" class="action-btn-sm" style="padding:4px 8px; font-size:11px; background:var(--bg-hover);" onclick="openEditModal({{ $u->id }}, '{{ addslashes($u->name) }}', '{{ $u->phone }}', {{ $u->role_id }}, {{ $u->fee_persen ?? 0 }}, {{ $u->fee_fix ?? 0 }})">Edit</button>
            </td>
        </tr>
        @endforeach
        </tbody>
    </table>
</div>

<div id="addUserModal" class="modal-overlay" style="display:none;" onclick="if(event.target===this)this.style.display='none'">
    <div class="modal-content">
        <div class="modal-header"><h3>Tambah User</h3><button onclick="this.closest('.modal-overlay').style.display='none'" class="modal-close">&times;</button></div>
        <form method="POST" action="{{ route('settings.users.store') }}">
            @csrf
            <div class="modal-body">
                <div class="form-row"><div class="form-group"><label>Nama *</label><input type="text" name="name" required class="input-field"></div><div class="form-group"><label>Username *</label><input type="text" name="username" required class="input-field"></div></div>
                <div class="form-row"><div class="form-group"><label>Email</label><input type="email" name="email" class="input-field"></div><div class="form-group"><label>No. HP</label><input type="text" name="phone" class="input-field"></div></div>
                <div class="form-row"><div class="form-group"><label>Password *</label><input type="password" name="password" required class="input-field" minlength="6"></div><div class="form-group"><label>Role *</label><select name="role_id" required class="input-field">@foreach($roles as $r)<option value="{{ $r->id }}">{{ $r->name }}</option>@endforeach</select></div></div>
                <div class="form-row"><div class="form-group"><label>Fee Persentase (%)</label><input type="number" name="fee_persen" class="input-field" step="0.01" min="0" max="100" placeholder="Contoh: 10"></div><div class="form-group"><label>Fee Fix (Rp)</label><input type="number" name="fee_fix" class="input-field" min="0" placeholder="Contoh: 5000"></div></div>
            </div>
            <div class="modal-footer"><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Batal</button><button type="submit" class="btn-primary">Simpan</button></div>
        </form>
    </div>
</div>

<div id="editUserModal" class="modal-overlay" style="display:none;" onclick="if(event.target===this)this.style.display='none'">
    <div class="modal-content">
        <div class="modal-header"><h3>Edit User</h3><button onclick="this.closest('.modal-overlay').style.display='none'" class="modal-close">&times;</button></div>
        <form method="POST" id="editUserForm">
            @csrf
            @method('PUT')
            <div class="modal-body">
                <div class="form-row"><div class="form-group"><label>Nama *</label><input type="text" name="name" id="editName" required class="input-field"></div><div class="form-group"><label>No. HP</label><input type="text" name="phone" id="editPhone" class="input-field"></div></div>
                <div class="form-row"><div class="form-group"><label>Password (Kosongkan jika tidak ubah)</label><input type="password" name="password" class="input-field" minlength="6"></div><div class="form-group"><label>Role *</label><select name="role_id" id="editRole" required class="input-field">@foreach($roles as $r)<option value="{{ $r->id }}">{{ $r->name }}</option>@endforeach</select></div></div>
                <div class="form-row"><div class="form-group"><label>Fee Persentase (%)</label><input type="number" name="fee_persen" id="editFeePersen" class="input-field" step="0.01" min="0" max="100"></div><div class="form-group"><label>Fee Fix (Rp)</label><input type="number" name="fee_fix" id="editFeeFix" class="input-field" min="0"></div></div>
            </div>
            <div class="modal-footer"><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Batal</button><button type="submit" class="btn-primary">Update</button></div>
        </form>
    </div>
</div>

@endsection
@push('scripts')
<script>
function openEditModal(id, name, phone, role_id, fee_persen, fee_fix) {
    let form = document.getElementById('editUserForm');
    form.action = `/settings/users/${id}`;
    document.getElementById('editName').value = name;
    document.getElementById('editPhone').value = phone || '';
    document.getElementById('editRole').value = role_id;
    document.getElementById('editFeePersen').value = fee_persen;
    document.getElementById('editFeeFix').value = fee_fix;
    document.getElementById('editUserModal').style.display = 'flex';
}
</script>
@endpush
@push('styles')
<style>
.btn-primary{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;background:var(--gradient);border:none;border-radius:10px;color:white;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit}
.btn-secondary{padding:8px 16px;background:var(--bg-card);border:1px solid var(--border);border-radius:8px;color:var(--text-secondary);font-size:13px;cursor:pointer;font-family:inherit}
.alert-success{padding:12px 16px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:10px;color:#22c55e;margin-bottom:16px;font-size:14px}
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow-sm)}
.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:12px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}
.badge{display:inline-block;padding:3px 10px;border-radius:6px;font-size:12px;font-weight:500;background:rgba(99,102,241,.1);color:var(--accent)}
.status-badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600}.status-success{background:rgba(34,197,94,.1);color:#22c55e}.status-muted{background:rgba(148,163,184,.1);color:var(--text-muted)}
.action-btn-sm{padding:5px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid}
.btn-danger-sm{background:rgba(239,68,68,.1);border-color:rgba(239,68,68,.3);color:#ef4444}.btn-success-sm{background:rgba(34,197,94,.1);border-color:rgba(34,197,94,.3);color:#22c55e}
.input-field{padding:8px 12px;background:var(--bg-card);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);font-size:14px;font-family:inherit;outline:none;width:100%}.input-field:focus{border-color:var(--accent)}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}
.modal-content{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;width:100%;max-width:520px;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.3)}
.modal-header{display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid var(--border)}.modal-close{width:32px;height:32px;border:none;background:none;font-size:24px;color:var(--text-muted);cursor:pointer}
.modal-body{padding:24px}.modal-footer{padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}.form-group{margin-bottom:16px}.form-group label{display:block;font-size:13px;font-weight:500;color:var(--text-secondary);margin-bottom:6px}
</style>
@endpush
