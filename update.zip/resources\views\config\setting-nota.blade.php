@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
Setting Nota & Perusahaan
@endsection
@section('content')
<div id="settingMsg" class="cfg-alert"></div>

<div class="cfg-grid-2">
    {{-- Kiri: Template Nota --}}
    <div>
        <div class="cfg-card">
            <div class="cfg-card-title">🧾 Template Nota Struk</div>
            <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:12px">Atur tampilan nota pembayaran untuk printer termal 58mm / 80mm.</p>
            <div style="display:flex;flex-direction:column;gap:10px">
                <div><div class="cfg-label">Header Struk</div><input type="text" id="notaHeader" class="cfg-input" placeholder="Nama Usaha" value="{{ $configs['nota_header'] ?? '' }}"></div>
                <div><div class="cfg-label">Judul Nota</div><input type="text" id="notaTitle" class="cfg-input" placeholder="NOTA PEMBAYARAN" value="{{ $configs['nota_title'] ?? '' }}"></div>
                <div><div class="cfg-label">Support By (opsional)</div><input type="text" id="notaSupportBy" class="cfg-input" placeholder="Support By..." value="{{ $configs['nota_support_by'] ?? '' }}"></div>
                <div><div class="cfg-label">Footer</div><textarea id="notaFooter" class="cfg-input" rows="2" placeholder="Terima kasih">{{ $configs['nota_footer'] ?? '' }}</textarea></div>
                <div style="display:flex;gap:10px">
                    <div style="flex:1"><div class="cfg-label">Ukuran Kertas</div>
                        <select id="notaWidth" class="cfg-input"><option value="58" {{ ($configs['nota_width_mm'] ?? '58') == '58' ? 'selected' : '' }}>58mm</option><option value="80" {{ ($configs['nota_width_mm'] ?? '') == '80' ? 'selected' : '' }}>80mm</option></select>
                    </div>
                    <div style="flex:1"><div class="cfg-label">Font Size (px)</div><input type="number" id="notaFontSize" class="cfg-input" min="8" max="16" value="{{ $configs['nota_font_size'] ?? 11 }}"></div>
                </div>
                <button class="cfg-btn cfg-btn-primary" onclick="saveNota()">✓ Simpan Nota</button>
            </div>
        </div>

        <div class="cfg-card">
            <div class="cfg-card-title">💰 PPN</div>
            <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:8px">PPN (%) ditambahkan ke total bayar.</p>
            <div style="display:flex;gap:10px;align-items:flex-end">
                <div><div class="cfg-label">PPN (%)</div><input type="number" id="ppnPct" class="cfg-input" min="0" max="100" step="0.1" value="{{ $configs['ppn_pct'] ?? 0 }}" style="width:120px"></div>
                <button class="cfg-btn cfg-btn-primary" onclick="savePPN()">✓ Simpan PPN</button>
            </div>
        </div>
    </div>

    {{-- Kanan: Data Perusahaan --}}
    <div>
        <div class="cfg-card">
            <div class="cfg-card-title">🏢 Data Perusahaan</div>
            <div style="display:flex;flex-direction:column;gap:10px">
                <div><div class="cfg-label">Nama</div><input type="text" id="compNama" class="cfg-input" value="{{ $configs['company_nama'] ?? '' }}"></div>
                <div><div class="cfg-label">Alamat</div><textarea id="compAlamat" class="cfg-input" rows="2">{{ $configs['company_alamat'] ?? '' }}</textarea></div>
                <div><div class="cfg-label">Telepon</div><input type="text" id="compTelp" class="cfg-input" value="{{ $configs['company_telepon'] ?? '' }}"></div>
                <div><div class="cfg-label">Nomor CS (WA)</div><input type="text" id="compCS" class="cfg-input" value="{{ $configs['company_nomer_cs'] ?? '' }}"></div>
                <div><div class="cfg-label">Terms & Conditions</div><textarea id="compTerms" class="cfg-input" rows="2">{{ $configs['company_terms'] ?? '' }}</textarea></div>
                <div><div class="cfg-label">Payment Info</div><input type="text" id="compPayment" class="cfg-input" value="{{ $configs['company_payment_info'] ?? '' }}"></div>
                <button class="cfg-btn cfg-btn-primary" onclick="saveCompany()">✓ Simpan Perusahaan</button>
            </div>
        </div>
    </div>
</div>

{{-- Template Tagihan --}}
<div class="cfg-card">
    <div class="cfg-card-title">📝 Template Tagihan Pelanggan</div>
    <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:12px">Template WA untuk pelanggan yang belum lunas. Variabel: @{{nama}}, @{{paket}}, @{{harga_paket}}, @{{tagihan_belum_bayar}}</p>
    <div class="cfg-grid-2">
        <div><div class="cfg-label">Sebelum data</div><textarea id="tplSebelum" class="cfg-input" rows="4">{{ $configs['template_sebelum'] ?? '' }}</textarea></div>
        <div><div class="cfg-label">Sesudah data</div><textarea id="tplSesudah" class="cfg-input" rows="4">{{ $configs['template_sesudah'] ?? '' }}</textarea></div>
    </div>
    <button class="cfg-btn cfg-btn-primary" style="margin-top:12px" onclick="saveTemplate()">✓ Simpan Template</button>
</div>

{{-- Template Nota Digital --}}
<div class="cfg-card">
    <div class="cfg-card-title">📨 Template Nota Digital (WA)</div>
    <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:12px">Template untuk nota pembayaran digital via WhatsApp setelah pembayaran berhasil.</p>
    <div class="cfg-grid-2">
        <div><div class="cfg-label">Sebelum data nota</div><textarea id="rcptSebelum" class="cfg-input" rows="4">{{ $configs['receipt_tpl_sebelum'] ?? '' }}</textarea></div>
        <div><div class="cfg-label">Sesudah data nota</div><textarea id="rcptSesudah" class="cfg-input" rows="4">{{ $configs['receipt_tpl_sesudah'] ?? '' }}</textarea></div>
    </div>
    <button class="cfg-btn cfg-btn-primary" style="margin-top:12px" onclick="saveReceipt()">✓ Simpan Nota Digital</button>
</div>

@push('scripts')
<script>
function saveConfig(data, msg) {
    fetch('{{ route("config.setting-nota.update") }}', {
        method: 'POST', headers: {'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}'},
        body: JSON.stringify(data)
    }).then(r=>r.json()).then(res => {
        var el = document.getElementById('settingMsg');
        el.className = 'cfg-alert ' + (res.status==='success'?'ok':'err');
        el.textContent = res.message || msg;
        window.scrollTo({top:0,behavior:'smooth'});
    });
}
function saveNota() {
    saveConfig({nota_header:document.getElementById('notaHeader').value,nota_title:document.getElementById('notaTitle').value,nota_support_by:document.getElementById('notaSupportBy').value,nota_footer:document.getElementById('notaFooter').value,nota_width_mm:document.getElementById('notaWidth').value,nota_font_size:document.getElementById('notaFontSize').value}, 'Nota berhasil disimpan');
}
function savePPN() { saveConfig({ppn_pct:document.getElementById('ppnPct').value}, 'PPN disimpan'); }
function saveCompany() {
    saveConfig({company_nama:document.getElementById('compNama').value,company_alamat:document.getElementById('compAlamat').value,company_telepon:document.getElementById('compTelp').value,company_nomer_cs:document.getElementById('compCS').value,company_terms:document.getElementById('compTerms').value,company_payment_info:document.getElementById('compPayment').value}, 'Data perusahaan disimpan');
}
function saveTemplate() { saveConfig({template_sebelum:document.getElementById('tplSebelum').value,template_sesudah:document.getElementById('tplSesudah').value}, 'Template disimpan'); }
function saveReceipt() { saveConfig({receipt_tpl_sebelum:document.getElementById('rcptSebelum').value,receipt_tpl_sesudah:document.getElementById('rcptSesudah').value}, 'Nota digital disimpan'); }
</script>
@endpush
@endsection
