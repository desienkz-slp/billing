@extends('layouts.superadmin')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
Detail: {{ $tenant->name }}
@endsection
@section('content')

{{-- Breadcrumb --}}
<div style="margin-bottom:16px;font-size:.82rem">
    <a href="{{ route('superadmin.tenants') }}" style="color:var(--accent);text-decoration:none">← Kembali ke Daftar Tenant</a>
</div>

{{-- Stats --}}
<div class="sa-stats">
    <div class="sa-stat">
        <div class="sa-stat-value" style="color:{{ $tenant->is_active ? '#4ade80' : '#f87171' }}">{{ $tenant->is_active ? 'Aktif' : 'Nonaktif' }}</div>
        <div class="sa-stat-label">Status</div>
    </div>
    <div class="sa-stat">
        <div class="sa-stat-value">{{ $stats['total_users'] }}</div>
        <div class="sa-stat-label">Users ({{ $stats['active_users'] }} aktif)</div>
    </div>
    <div class="sa-stat">
        <div class="sa-stat-value">{{ number_format($stats['total_customers']) }}</div>
        <div class="sa-stat-label">Pelanggan</div>
    </div>
    <div class="sa-stat">
        <div class="sa-stat-value">{{ $stats['total_roles'] }}</div>
        <div class="sa-stat-label">Role</div>
    </div>
</div>

<div class="sa-grid-2">
    {{-- INFO TENANT --}}
    <div>
        <div class="sa-card">
            <div class="sa-card-title">🏢 Info Tenant</div>
            <table style="width:100%;font-size:.85rem">
                <tr><td style="color:var(--text-muted);padding:6px 0;width:120px">ID</td><td style="padding:6px 0;color:#fff;font-weight:600">{{ $tenant->id }}</td></tr>
                <tr><td style="color:var(--text-muted);padding:6px 0">UUID</td><td style="padding:6px 0"><code style="font-size:.75rem;color:var(--accent);background:rgba(249,115,22,.1);padding:2px 6px;border-radius:4px">{{ $tenant->uuid }}</code></td></tr>
                <tr><td style="color:var(--text-muted);padding:6px 0">Nama</td><td style="padding:6px 0;color:#fff;font-weight:600">{{ $tenant->name }}</td></tr>
                <tr><td style="color:var(--text-muted);padding:6px 0">Slug</td><td style="padding:6px 0"><code style="font-size:.78rem;color:var(--accent);background:rgba(249,115,22,.1);padding:2px 6px;border-radius:4px">{{ $tenant->slug }}</code></td></tr>
                <tr><td style="color:var(--text-muted);padding:6px 0">Domain</td><td style="padding:6px 0">{{ $tenant->domain ?: '-' }}</td></tr>
                <tr><td style="color:var(--text-muted);padding:6px 0">Timezone</td><td style="padding:6px 0">{{ $tenant->timezone }}</td></tr>
                @php $cp = $tenant->company_profile ?? []; @endphp
                <tr><td style="color:var(--text-muted);padding:6px 0">Perusahaan</td><td style="padding:6px 0">{{ $cp['name'] ?? '-' }}</td></tr>
                <tr><td style="color:var(--text-muted);padding:6px 0">Alamat</td><td style="padding:6px 0">{{ $cp['address'] ?? '-' }}</td></tr>
                <tr><td style="color:var(--text-muted);padding:6px 0">Telepon</td><td style="padding:6px 0">{{ $cp['phone'] ?? '-' }}</td></tr>
                <tr><td style="color:var(--text-muted);padding:6px 0">Dibuat</td><td style="padding:6px 0">{{ $tenant->created_at->format('d/m/Y H:i') }}</td></tr>
            </table>
        </div>

        {{-- SUBSCRIPTION --}}
        <div class="sa-card">
            <div class="sa-card-title">📋 Riwayat Subscription</div>
            @forelse($subscriptions as $s)
            @php
                $statusClass = match($s->status) {
                    'active' => $s->expires_at->isFuture() ? 'active' : 'expired',
                    'grace' => 'grace',
                    default => 'expired',
                };
            @endphp
            <div style="padding:10px;background:rgba(0,0,0,.2);border-radius:8px;margin-bottom:8px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <span class="sa-status sa-status-{{ $statusClass }}">{{ ucfirst($s->plan) }} — {{ ucfirst($s->status) }}</span>
                        <div style="font-size:.72rem;color:var(--text-muted);margin-top:4px">
                            {{ $s->starts_at->format('d/m/Y') }} → {{ $s->expires_at->format('d/m/Y') }}
                            · Max: {{ number_format($s->max_customers) }} pelanggan
                        </div>
                    </div>
                    <code style="font-size:.65rem;color:var(--text-muted)">{{ $s->license_key }}</code>
                </div>
            </div>
            @empty
            <p style="text-align:center;color:var(--text-muted);padding:20px;font-size:.85rem">Belum ada subscription.</p>
            @endforelse
        </div>
    </div>

    {{-- USERS & ROLES --}}
    <div>
        {{-- ROLES --}}
        <div class="sa-card">
            <div class="sa-card-title">🛡️ Role ({{ $roles->count() }})</div>
            <div style="display:flex;flex-wrap:wrap;gap:8px">
                @foreach($roles as $r)
                <div style="padding:8px 12px;background:rgba(0,0,0,.2);border-radius:8px;font-size:.82rem">
                    <span style="font-weight:600;color:#fff">{{ $r->name }}</span>
                    <span style="color:var(--text-muted);font-size:.72rem;margin-left:4px">({{ $r->users_count }} user)</span>
                </div>
                @endforeach
            </div>
        </div>

        {{-- USERS --}}
        <div class="sa-card">
            <div class="sa-card-title">👥 User ({{ $users->count() }})</div>
            <div style="max-height:50vh;overflow:auto">
                <table class="sa-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Login Terakhir</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($users as $i => $u)
                        <tr>
                            <td>{{ $i+1 }}</td>
                            <td style="font-weight:600;color:#fff">{{ $u->name }}</td>
                            <td><code>{{ $u->username }}</code></td>
                            <td>{{ $u->role->name ?? '-' }}</td>
                            <td>
                                @if($u->is_active)
                                <span class="sa-status sa-status-active">● Aktif</span>
                                @else
                                <span class="sa-status sa-status-inactive">● Nonaktif</span>
                                @endif
                            </td>
                            <td style="font-size:.78rem;color:var(--text-muted)">
                                {{ $u->last_login_at ? $u->last_login_at->format('d/m/Y H:i') : '-' }}
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:20px">Belum ada user.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
