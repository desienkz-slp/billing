@extends('layouts.app')
@section('title', 'Master Area')
@section('content')
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <h1 style="font-size:22px; font-weight:700;">📍 Master Area</h1>
    <button class="btn-primary" onclick="document.getElementById('addModal').style.display='flex'">+ Tambah Area</button>
</div>
@if(session('success'))<div class="alert-success">✅ {{ session('success') }}</div>@endif
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>Nama Area</th><th>Kode</th><th>Deskripsi</th><th>Pelanggan</th></tr></thead>
        <tbody>
        @foreach($areas as $a)
        <tr>
            <td><strong>{{ $a->name }}</strong></td>
            <td><span class="badge">{{ $a->code ?? '-' }}</span></td>
            <td style="color:var(--text-muted); font-size:13px;">{{ $a->description ?? '-' }}</td>
            <td><strong>{{ $a->customers_count ?? 0 }}</strong></td>
        </tr>
        @endforeach
        </tbody>
    </table>
</div>
<div id="addModal" class="modal-overlay" style="display:none;" onclick="if(event.target===this)this.style.display='none'">
    <div class="modal-content">
        <div class="modal-header"><h3>Tambah Area</h3><button onclick="this.closest('.modal-overlay').style.display='none'" class="modal-close">&times;</button></div>
        <form method="POST" action="{{ route('settings.areas.store') }}">@csrf
            <div class="modal-body">
                <div class="form-row"><div class="form-group"><label>Nama *</label><input type="text" name="name" required class="input-field"></div><div class="form-group"><label>Kode</label><input type="text" name="code" class="input-field" placeholder="BLT-01"></div></div>
                <div class="form-group"><label>Deskripsi</label><textarea name="description" rows="2" class="input-field"></textarea></div>
            </div>
            <div class="modal-footer"><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Batal</button><button type="submit" class="btn-primary">Simpan</button></div>
        </form>
    </div>
</div>
@endsection
@push('styles')
<style>
.btn-primary{padding:10px 20px;background:var(--gradient);border:none;border-radius:10px;color:white;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit}
.btn-secondary{padding:8px 16px;background:var(--bg-card);border:1px solid var(--border);border-radius:8px;color:var(--text-secondary);font-size:13px;cursor:pointer;font-family:inherit}
.alert-success{padding:12px 16px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:10px;color:#22c55e;margin-bottom:16px;font-size:14px}
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow-sm)}
.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:14px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}
.badge{display:inline-block;padding:3px 10px;border-radius:6px;font-size:12px;font-weight:500;background:rgba(99,102,241,.1);color:var(--accent)}
.input-field{padding:8px 12px;background:var(--bg-card);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);font-size:14px;font-family:inherit;outline:none;width:100%}textarea.input-field{resize:vertical}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}.modal-content{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.3)}.modal-header{display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid var(--border)}.modal-close{width:32px;height:32px;border:none;background:none;font-size:24px;color:var(--text-muted);cursor:pointer}.modal-body{padding:24px}.modal-footer{padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}.form-group{margin-bottom:16px}.form-group label{display:block;font-size:13px;font-weight:500;color:var(--text-secondary);margin-bottom:6px}
</style>
@endpush
