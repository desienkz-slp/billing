@extends('layouts.app')
@section('title', 'Dashboard & Pelanggan')

@section('content')
<div class="welcome-card" style="margin-bottom:20px;">
    <h1>Selamat datang, {{ $user->name }}! 👋</h1>
    <p>{{ $tenant->name }} — {{ now()->locale('id')->isoFormat('dddd, D MMMM Y') }}</p>
</div>

{{-- Stats Cards --}}
<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px,1fr)); gap:20px; margin-bottom:28px;">
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(99,102,241,0.1); color:var(--accent);">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        </div>
        <div class="stat-value">{{ number_format($stats['total_customers']) }}</div>
        <div class="stat-label">Total Pelanggan</div>
        <div class="stat-sub">{{ $stats['active_customers'] }} aktif</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(34,197,94,0.1); color:var(--success);">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
        </div>
        <div class="stat-value">Rp {{ number_format($stats['revenue_this_month'],0,',','.') }}</div>
        <div class="stat-label">Pendapatan Bulan Ini</div>
        <div class="stat-sub">{{ $stats['payments_this_month'] }} pembayaran</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(239,68,68,0.1); color:var(--danger);">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
        </div>
        <div class="stat-value">{{ $stats['isolated'] }}</div>
        <div class="stat-label">Isolir Aktif</div>
        <div class="stat-sub">Pelanggan terisolir</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(245,158,11,0.1); color:var(--warning);">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
        </div>
        <div class="stat-value">{{ $stats['new_this_month'] }}</div>
        <div class="stat-label">Pelanggan Baru</div>
        <div class="stat-sub">Bulan ini</div>
    </div>
</div>

{{-- Header Tabel Pelanggan --}}
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:12px;">
    <div>
        <h2 style="font-size:18px; font-weight:700;">Data Pelanggan & Aksi Cepat</h2>
    </div>
    <div style="display:flex; gap:10px;">
        @if($user->is_system_admin || $user->role?->can_process_payment)
        <button id="btnBatchBayar" class="btn-primary" style="display:none; background:#22c55e;" onclick="openBatchModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            Batch Bayar (<span id="batchCount">0</span>)
        </button>
        @endif
    </div>
</div>

{{-- Filters --}}
<div class="card" style="margin-bottom:20px; padding:16px 20px;">
    <form method="GET" action="{{ route('dashboard') }}" style="display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
        <div style="flex:1; min-width:200px;">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari nama, username, HP..."
                class="input-field" style="width:100%;">
        </div>
        <select name="area_id" class="input-field" style="min-width:140px;">
            <option value="">Semua Area</option>
            @foreach($areas as $area)
                <option value="{{ $area->id }}" {{ request('area_id') == $area->id ? 'selected' : '' }}>{{ $area->name }}</option>
            @endforeach
        </select>
        <select name="package_id" class="input-field" style="min-width:140px;">
            <option value="">Semua Paket</option>
            @foreach($packages as $pkg)
                <option value="{{ $pkg->id }}" {{ request('package_id') == $pkg->id ? 'selected' : '' }}>{{ $pkg->name }}</option>
            @endforeach
        </select>
        <select name="status" class="input-field" style="min-width:120px;">
            <option value="">Status</option>
            <option value="active" {{ request('status') == 'active' ? 'selected' : '' }}>Aktif</option>
            <option value="inactive" {{ request('status') == 'inactive' ? 'selected' : '' }}>Non-Aktif</option>
        </select>
        <button type="submit" class="btn-secondary">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            Filter
        </button>
        @if(request()->hasAny(['search','area_id','package_id','status']))
            <a href="{{ route('dashboard') }}" class="btn-ghost">Reset</a>
        @endif
    </form>
</div>

{{-- Table --}}
<div class="card" style="padding:0; overflow:hidden;">
    <div style="overflow-x:auto; min-height:300px;">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width:40px; text-align:center;">
                        <input type="checkbox" id="selectAll">
                    </th>
                    <th>Pelanggan</th>
                    <th>Paket</th>
                    <th>Area</th>
                    <th>Status</th>
                    <th style="width:180px; text-align:right;">Aksi Cepat</th>
                </tr>
            </thead>
            <tbody>
                @forelse($customers as $c)
                <tr>
                    <td style="text-align:center;">
                        <input type="checkbox" class="cb-customer" value="{{ $c->id }}" data-name="{{ $c->name }}">
                    </td>
                    <td>
                        <div style="font-weight:600;">{{ $c->name }}</div>
                        <div style="font-size:12px; color:var(--text-muted);">{{ ucfirst($c->jenis_bayar ?? 'prabayar') }}</div>
                    </td>
                    <td>
                        <span class="badge">{{ $c->package?->name ?? '-' }}</span>
                        <div style="font-size:12px; color:var(--text-muted); margin-top:2px;">
                            Rp {{ number_format($c->getEffectivePrice(),0,',','.') }}
                        </div>
                    </td>
                    <td>{{ $c->area?->name ?? '-' }}</td>
                    <td>
                        @if($c->is_on_leave)
                            <span class="status-badge status-muted">Cuti</span>
                        @elseif($c->is_isolated)
                            <span class="status-badge status-danger">Isolir</span>
                        @elseif($c->status === 'active')
                            <span class="status-badge status-success">Aktif</span>
                        @else
                            <span class="status-badge status-muted">{{ ucfirst($c->status) }}</span>
                        @endif
                    </td>
                    <td style="text-align:right;">
                        <div style="display:flex; gap:4px; justify-content:flex-end;">
                            {{-- Action: Bayar --}}
                            @if($user->is_system_admin || $user->role?->can_process_payment)
                            <button class="action-btn pay-btn" onclick="openPaymentModal({{ $c->id }})" title="Bayar">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                            </button>
                            @endif

                            {{-- Action: Isolir / Unisolir --}}
                            @if($user->is_system_admin || $user->role?->can_manage_isolir)
                                @if($c->is_isolated)
                                    <form action="{{ route('isolir.release', $c->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Lepas isolir untuk {{ $c->name }}?')">
                                        @csrf
                                        <button type="submit" class="action-btn" title="Lepas Isolir (Unisolir)">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2"><path d="M2 12h4l2-9 5 18 5-18 2 9h4"/></svg>
                                        </button>
                                    </form>
                                @else
                                    <form action="{{ route('isolir.isolate', $c->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Isolir pelanggan {{ $c->name }}?')">
                                        @csrf
                                        <button type="submit" class="action-btn" title="Isolir Pelanggan">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                                        </button>
                                    </form>
                                @endif
                            @endif

                            {{-- Action: Cuti --}}
                            @if($user->is_system_admin || $user->role?->can_manage_cuti)
                                @if(!$c->is_on_leave)
                                <form action="{{ route('cuti.store', $c->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Non-aktifkan (Cuti) pelanggan {{ $c->name }}?')">
                                    @csrf
                                    <button type="submit" class="action-btn" title="Set Cuti">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
                                    </button>
                                </form>
                                @endif
                            @endif

                            {{-- Detail --}}
                            <button type="button" class="action-btn" title="Detail" onclick="openCustomerDetail({{ $c->id }})">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                            </button>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align:center; padding:48px; color:var(--text-muted);">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" style="margin:0 auto 12px; display:block; opacity:0.3;"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        Belum ada data pelanggan
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($customers->hasPages())
        <div style="padding:16px 20px; border-top:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:13px; color:var(--text-muted);">
                Menampilkan {{ $customers->firstItem() }}-{{ $customers->lastItem() }} dari {{ $customers->total() }}
            </span>
            {{ $customers->links('pagination.simple') }}
        </div>
    @endif
</div>



@if($user->is_system_admin || $user->role?->can_process_payment)
{{-- Payment Modal --}}
<div id="paymentModal" class="modal-overlay" style="display:none;" onclick="if(event.target===this)this.style.display='none'">
    <div class="modal-content" style="max-width:600px;">
        <div class="modal-header">
            <h3>Catat Pembayaran</h3>
            <button onclick="this.closest('.modal-overlay').style.display='none'" class="modal-close">&times;</button>
        </div>
        <div class="modal-body" id="payLoading" style="text-align:center; padding:40px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spin"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Memuat data...
        </div>
        <form id="paymentForm" style="display:none;" onsubmit="submitPayment(event)">
            <input type="hidden" id="payCustomerId">
            <div class="modal-body" style="background:rgba(99,102,241,0.05); border-bottom:1px solid var(--border);">
                <div style="font-size:18px; font-weight:700; color:var(--text-primary);" id="payCustomerName">-</div>
                <div style="font-size:13px; color:var(--text-muted); margin-top:4px;" id="payCustomerInfo">-</div>
            </div>
            <div class="modal-body">
                <label style="display:block; font-size:13px; font-weight:600; margin-bottom:8px;">Pilih Bulan Tagihan:</label>
                <div id="payMonthsGrid" class="months-grid"></div>

                <div class="form-row" style="margin-top:16px;">
                    <div class="form-group">
                        <label>Diskon (Rp)</label>
                        <input type="number" id="payDiskon" value="0" min="0" class="input-field" oninput="calculateTotal()">
                    </div>
                    <div class="form-group">
                        <label>Bayar Sebagian (Rp) - Opsional</label>
                        <input type="number" id="payPartial" placeholder="Kosongi jika lunas" class="input-field" oninput="calculateTotal()">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Metode Pembayaran</label>
                        <select id="payMetode" class="input-field">
                            <option value="cash">Tunai (Cash)</option>
                            <option value="transfer">Transfer Bank</option>
                            <option value="qris">QRIS</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tanggal Bayar</label>
                        <input type="date" id="payTgl" value="{{ date('Y-m-d') }}" class="input-field">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Keterangan</label>
                    <input type="text" id="payNotes" class="input-field" placeholder="Opsional...">
                </div>

                <div style="background:var(--bg-body); padding:16px; border-radius:8px; border:1px solid var(--border); margin-top:16px;">
                    <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:13px;">
                        <span>Subtotal Tagihan:</span>
                        <strong id="summarySubtotal">Rp 0</strong>
                    </div>
                    <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:13px; color:#ef4444;" id="summaryDiskonRow">
                        <span>Diskon:</span>
                        <strong id="summaryDiskon">- Rp 0</strong>
                    </div>
                    <div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:13px;" id="summaryPpnRow">
                        <span>PPN (11%):</span>
                        <strong id="summaryPpn">Rp 0</strong>
                    </div>
                    <div style="display:flex; justify-content:space-between; font-size:18px; font-weight:700; padding-top:12px; border-top:1px dashed var(--border);">
                        <span>TOTAL BAYAR:</span>
                        <strong id="summaryTotal" style="color:#22c55e;">Rp 0</strong>
                    </div>
                    <div id="summaryPartialNote" style="font-size:12px; color:#f59e0b; margin-top:8px; text-align:right; display:none;">
                        * Pembayaran Sebagian. Sisa tagihan: <b id="summarySisa">Rp 0</b>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Batal</button>
                <button type="submit" id="btnSubmitPayment" class="btn-primary" style="background:#22c55e;" disabled>
                    Simpan Pembayaran
                </button>
            </div>
        </form>
    </div>
</div>

{{-- Batch Payment Modal --}}
<div id="batchModal" class="modal-overlay" style="display:none;" onclick="if(event.target===this)this.style.display='none'">
    <div class="modal-content" style="max-width:500px;">
        <div class="modal-header">
            <h3>Batch Pembayaran</h3>
            <button onclick="this.closest('.modal-overlay').style.display='none'" class="modal-close">&times;</button>
        </div>
        <form id="batchForm" onsubmit="submitBatchPayment(event)">
            <div class="modal-body">
                <div style="margin-bottom:16px; padding:12px; background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; color:#1e40af; font-size:13px;">
                    Anda akan memproses pelunasan untuk <b id="batchSelCount">0</b> pelanggan sekaligus. Pembayaran akan mencakup seluruh tunggakan setiap pelanggan sampai bulan yang dipilih.
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Tunggakan Sampai Bulan</label>
                        <input type="month" id="batchSampai" value="{{ date('Y-m') }}" class="input-field" required>
                    </div>
                    <div class="form-group">
                        <label>Metode Pembayaran</label>
                        <select id="batchMetode" class="input-field">
                            <option value="cash">Tunai (Cash)</option>
                            <option value="transfer">Transfer Bank</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Batal</button>
                <button type="submit" id="btnSubmitBatch" class="btn-primary" style="background:#22c55e;">
                    Bayar Semua
                </button>
            </div>
        </form>
    </div>
</div>
@endif
<!-- Customer Detail Modal -->
<div id="customerDetailModal" class="modal-overlay" style="display:none;" onclick="if(event.target===this)closeCustomerDetail()">
    <div class="modal-content" style="max-width:700px; display:flex; flex-direction:column; max-height:90vh;">
        <div class="modal-header">
            <h3>Detail Pelanggan</h3>
            <button type="button" class="modal-close" onclick="closeCustomerDetail()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <div class="modal-body" id="customerDetailBody" style="overflow-y:auto; padding:20px;">
            <div style="text-align:center; padding:40px; color:var(--text-muted);">Memuat data...</div>
        </div>
    </div>
</div>

@endsection

@push('styles')
<style>
/* Detail Grid Styles */
.detail-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px; }
.detail-box { background:var(--bg-body); padding:12px; border-radius:8px; border:1px solid var(--border); }
.detail-label { font-size:12px; color:var(--text-muted); margin-bottom:4px; text-transform:uppercase; letter-spacing:0.5px; font-weight:600; }
.detail-value { font-size:14px; font-weight:500; color:var(--text-primary); word-break:break-word; }
.detail-row { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid var(--border); }
.detail-row:last-child { border-bottom:none; }
.detail-section-title { font-size:15px; font-weight:600; color:var(--text-primary); margin:16px 0 8px; border-bottom:2px solid var(--border); padding-bottom:4px; }

    .welcome-card {
        background: var(--gradient);
        border-radius: var(--radius);
        padding: 32px;
        color: white;
        position: relative;
        overflow: hidden;
    }
    .welcome-card::after {
        content: '';
        position: absolute;
        right: -20px; top: -20px;
        width: 200px; height: 200px;
        background: rgba(255,255,255,0.05);
        border-radius: 50%;
    }
    .stat-card {
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow-sm);
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
    .stat-icon { width:44px; height:44px; border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:14px; }
    .stat-value { font-size:24px; font-weight:700; margin-bottom:2px; }
    .stat-label { font-size:13px; color:var(--text-secondary); }
    .stat-sub { font-size:12px; color:var(--text-muted); margin-top:4px; }

    .btn-primary { display:inline-flex; align-items:center; gap:6px; padding:10px 20px; background:var(--gradient); border:none; border-radius:10px; color:white; font-size:14px; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s; }
    .btn-primary:hover { transform:translateY(-1px); box-shadow:0 4px 15px rgba(99,102,241,0.4); }
    .btn-primary:disabled { opacity:0.6; cursor:not-allowed; transform:none; box-shadow:none; }
    .btn-secondary { display:inline-flex; align-items:center; gap:6px; padding:8px 16px; background:var(--bg-card); border:1px solid var(--border); border-radius:8px; color:var(--text-secondary); font-size:13px; font-weight:500; cursor:pointer; font-family:inherit; transition:all 0.2s; text-decoration:none; }
    .btn-secondary:hover { border-color:var(--accent); color:var(--accent); }
    .btn-ghost { padding:8px 12px; background:none; border:none; color:var(--text-muted); font-size:13px; cursor:pointer; text-decoration:none; }
    .btn-ghost:hover { color:var(--accent); }

    .input-field { padding:8px 12px; background:var(--bg-card); border:1px solid var(--border); border-radius:8px; color:var(--text-primary); font-size:14px; font-family:inherit; outline:none; transition:border-color 0.2s; }
    .input-field:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(99,102,241,0.15); }
    select.input-field { cursor:pointer; }
    textarea.input-field { resize:vertical; width:100%; }

    .card { background:var(--bg-card); border:1px solid var(--border); border-radius:var(--radius); padding:24px; box-shadow:var(--shadow-sm); }
    .data-table { width:100%; border-collapse:collapse; font-size:14px; }
    .data-table th { text-align:left; padding:12px 16px; color:var(--text-muted); font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:0.5px; border-bottom:2px solid var(--border); background:var(--bg-body); }
    .data-table td { padding:14px 16px; border-bottom:1px solid var(--border); }
    .data-table tbody tr { transition:background 0.15s; }
    .data-table tbody tr:hover { background:var(--accent-bg); }

    .badge { display:inline-block; padding:3px 10px; border-radius:6px; font-size:12px; font-weight:500; background:rgba(99,102,241,0.1); color:var(--accent); }
    .status-badge { display:inline-block; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:600; }
    .status-success { background:rgba(34,197,94,0.1); color:#22c55e; }
    .status-danger { background:rgba(239,68,68,0.1); color:#ef4444; }
    .status-muted { background:rgba(148,163,184,0.1); color:var(--text-muted); }

    .action-btn { width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; border-radius:8px; color:var(--text-muted); transition:all 0.15s; text-decoration:none; background:none; border:none; cursor:pointer;}
    .action-btn:hover { background:var(--accent-bg); color:var(--accent); }
    .action-btn.pay-btn:hover { background:rgba(34,197,94,0.1); }

    .modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:100; display:flex; align-items:center; justify-content:center; backdrop-filter:blur(4px); }
    .modal-content { background:var(--bg-card); border:1px solid var(--border); border-radius:16px; width:100%; max-width:560px; max-height:90vh; overflow-y:auto; box-shadow:0 20px 60px rgba(0,0,0,0.3); }
    .modal-header { display:flex; justify-content:space-between; align-items:center; padding:20px 24px; border-bottom:1px solid var(--border); }
    .modal-header h3 { font-size:17px; font-weight:600; }
    .modal-close { width:32px; height:32px; border:none; background:none; font-size:24px; color:var(--text-muted); cursor:pointer; border-radius:8px; }
    .modal-close:hover { background:var(--accent-bg); }
    .modal-body { padding:24px; }
    .modal-footer { padding:16px 24px; border-top:1px solid var(--border); display:flex; justify-content:flex-end; gap:10px; }
    .form-row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
    .form-group { margin-bottom:16px; }
    .form-group label { display:block; font-size:13px; font-weight:500; color:var(--text-secondary); margin-bottom:6px; }
    .form-group .input-field { width:100%; }
    .spin { animation: spin 1s linear infinite; }
    @keyframes spin { 100% { transform: rotate(360deg); } }

    /* Month Grid UI */
    .months-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(130px, 1fr)); gap:10px; }
    .month-cb { display:none; }
    .month-label { display:block; padding:10px; border:1px solid var(--border); border-radius:8px; cursor:pointer; position:relative; overflow:hidden; transition:all 0.2s; user-select:none;}
    .month-label:hover { border-color:#93c5fd; }
    .month-label.paid { background:#f1f5f9; cursor:not-allowed; opacity:0.7; }
    .month-cb:checked + .month-label { border-color:#3b82f6; background:#eff6ff; box-shadow:0 0 0 1px #3b82f6; }
    .month-cb:checked + .month-label::after { content:'✓'; position:absolute; top:2px; right:8px; color:#3b82f6; font-weight:bold; }
    .month-label .m-name { display:block; font-size:13px; font-weight:600; color:var(--text-primary); }
    .month-label .m-status { display:block; font-size:11px; margin-top:2px; }
    .month-label .m-status.s-paid { color:#10b981; }
    .month-label .m-status.s-unpaid { color:#ef4444; }
    .month-label .m-status.s-partial { color:#f59e0b; }
</style>
@endpush

@push('scripts')
<script>
    // --- Checkbox Logic ---
    const selectAll = document.getElementById('selectAll');
    const cbs = document.querySelectorAll('.cb-customer');
    const btnBatch = document.getElementById('btnBatchBayar');
    const batchCount = document.getElementById('batchCount');

    function updateBatchButton() {
        const checked = document.querySelectorAll('.cb-customer:checked');
        batchCount.innerText = checked.length;
        btnBatch.style.display = checked.length > 0 ? 'inline-flex' : 'none';
        if (selectAll) selectAll.checked = checked.length > 0 && checked.length === cbs.length;
    }

    if (selectAll) {
        selectAll.addEventListener('change', (e) => {
            cbs.forEach(cb => cb.checked = e.target.checked);
            updateBatchButton();
        });
    }

    cbs.forEach(cb => {
        cb.addEventListener('change', updateBatchButton);
    });

    // --- Payment Logic ---
    let currentCustomer = null;
    let paymentMonths = {};
    let selectedMonths = [];
    let basePrice = 0;

    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    function formatYm(ym) {
        const parts = ym.split('-');
        return monthNames[parseInt(parts[1])-1] + ' ' + parts[0];
    }

    function openPaymentModal(customerId) {
        document.getElementById('paymentModal').style.display = 'flex';
        document.getElementById('payLoading').style.display = 'block';
        document.getElementById('paymentForm').style.display = 'none';
        
        fetch(`/api-web/payments/months/${customerId}`)
            .then(res => res.json())
            .then(res => {
                if(res.status !== 'success') throw new Error(res.message);
                currentCustomer = res.customer;
                paymentMonths = res.paid_months;
                basePrice = res.customer.harga;
                
                document.getElementById('payCustomerName').innerText = res.customer.name;
                document.getElementById('payCustomerInfo').innerText = 
                    `${res.customer.nama_paket} · Rp ${res.customer.harga.toLocaleString('id-ID')} · ${res.customer.jenis_bayar.toUpperCase()}`;
                
                renderMonthsGrid();
                calculateTotal();
                
                document.getElementById('payLoading').style.display = 'none';
                document.getElementById('paymentForm').style.display = 'block';
            })
            .catch(err => {
                alert("Gagal memuat data: " + err.message);
                document.getElementById('paymentModal').style.display = 'none';
            });
    }

    function renderMonthsGrid() {
        const grid = document.getElementById('payMonthsGrid');
        grid.innerHTML = '';
        selectedMonths = [];

        Object.keys(paymentMonths).sort().forEach(ym => {
            const info = paymentMonths[ym];
            const isPaid = info.lunas;
            const remaining = info.remaining || 0;
            const isPartial = !isPaid && remaining > 0 && remaining < basePrice;
            
            let statusHtml = '';
            if (isPaid) statusHtml = `<span class="m-status s-paid">Lunas</span>`;
            else if (isPartial) statusHtml = `<span class="m-status s-partial">Sisa Rp ${remaining.toLocaleString('id-ID')}</span>`;
            else statusHtml = `<span class="m-status s-unpaid">Belum Bayar</span>`;

            grid.innerHTML += `
                <label>
                    <input type="checkbox" class="month-cb" value="${ym}" onchange="calculateTotal()" ${isPaid ? 'disabled' : ''}>
                    <div class="month-label ${isPaid ? 'paid' : ''}">
                        <span class="m-name">${formatYm(ym)}</span>
                        ${statusHtml}
                    </div>
                </label>
            `;
        });
    }

    function calculateTotal() {
        selectedMonths = Array.from(document.querySelectorAll('.month-cb:checked')).map(cb => cb.value);
        
        let totalCharge = 0;
        selectedMonths.forEach(ym => {
            const info = paymentMonths[ym];
            if (info.remaining > 0) {
                totalCharge += info.remaining;
            } else {
                totalCharge += basePrice;
            }
        });

        const diskon = parseInt(document.getElementById('payDiskon').value) || 0;
        const subtotal = Math.max(0, totalCharge - diskon);
        const ppn = Math.round(subtotal * 0.11);
        const grandTotal = subtotal + ppn;

        document.getElementById('summarySubtotal').innerText = 'Rp ' + totalCharge.toLocaleString('id-ID');
        document.getElementById('summaryDiskon').innerText = '- Rp ' + diskon.toLocaleString('id-ID');
        document.getElementById('summaryPpn').innerText = 'Rp ' + ppn.toLocaleString('id-ID');
        document.getElementById('summaryTotal').innerText = 'Rp ' + grandTotal.toLocaleString('id-ID');

        const btn = document.getElementById('btnSubmitPayment');
        btn.disabled = selectedMonths.length === 0;

        // Partial Note
        const paidPartial = parseFloat(document.getElementById('payPartial').value) || 0;
        const noteEl = document.getElementById('summaryPartialNote');
        if (paidPartial > 0 && paidPartial < grandTotal && selectedMonths.length > 0) {
            noteEl.style.display = 'block';
            document.getElementById('summarySisa').innerText = 'Rp ' + (grandTotal - paidPartial).toLocaleString('id-ID');
        } else {
            noteEl.style.display = 'none';
        }
    }

    function submitPayment(e) {
        e.preventDefault();
        const btn = document.getElementById('btnSubmitPayment');
        btn.innerText = 'Menyimpan...';
        btn.disabled = true;

        const payload = {
            _token: '{{ csrf_token() }}',
            customer_id: currentCustomer.id,
            bulan_bayar: selectedMonths,
            tgl_bayar: document.getElementById('payTgl').value,
            metode: document.getElementById('payMetode').value,
            diskon: document.getElementById('payDiskon').value || 0,
            paid_amount: document.getElementById('payPartial').value || null,
            keterangan: document.getElementById('payNotes').value
        };

        fetch('{{ route("api.payments.single") }}', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(res => {
            if (res.status === 'success') {
                alert(res.message);
                location.reload();
            } else {
                alert('Gagal: ' + res.message);
                btn.innerText = 'Simpan Pembayaran';
                btn.disabled = false;
            }
        })
        .catch(err => {
            alert('Error: ' + err.message);
            btn.innerText = 'Simpan Pembayaran';
            btn.disabled = false;
        });
    }

    // --- Batch Payment ---
    function openBatchModal() {
        const checked = document.querySelectorAll('.cb-customer:checked');
        if (checked.length === 0) return;
        document.getElementById('batchSelCount').innerText = checked.length;
        document.getElementById('batchModal').style.display = 'flex';
    }

    function submitBatchPayment(e) {
        e.preventDefault();
        const btn = document.getElementById('btnSubmitBatch');
        btn.innerText = 'Memproses...';
        btn.disabled = true;

        const customerIds = Array.from(document.querySelectorAll('.cb-customer:checked')).map(cb => cb.value);

        const payload = {
            _token: '{{ csrf_token() }}',
            customer_ids: customerIds,
            sampai_bulan: document.getElementById('batchSampai').value,
            tgl_bayar: '{{ date('Y-m-d') }}',
            metode: document.getElementById('batchMetode').value,
            keterangan: 'Batch Payment'
        };

        fetch('{{ route("api.payments.batch") }}', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(res => {
            if (res.status === 'success') {
                alert(res.message);
                location.reload();
            } else {
                alert('Gagal: ' + res.message);
                btn.innerText = 'Bayar Semua';
                btn.disabled = false;
            }
        })
        .catch(err => {
            alert('Error: ' + err.message);
            btn.innerText = 'Bayar Semua';
            btn.disabled = false;
        });
    }

    // --- Detail Modal ---
    function openCustomerDetail(id) {
        document.getElementById('customerDetailModal').style.display = 'flex';
        document.getElementById('customerDetailBody').innerHTML = '<div style="text-align:center; padding:40px; color:var(--text-muted);">Memuat data...</div>';

        fetch(`/customers/${id}`)
            .then(res => res.json())
            .then(res => {
                if (res.status === 'success') {
                    const data = res.data;
                    let statBadge = '';
                    if(data.is_on_leave) statBadge = '<span class="status-badge status-muted">Cuti</span>';
                    else if(data.is_isolated) statBadge = '<span class="status-badge status-danger">Isolir</span>';
                    else if(data.status === 'active') statBadge = '<span class="status-badge status-success">Aktif</span>';
                    else statBadge = `<span class="status-badge status-muted">${data.status}</span>`;

                    const html = `
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px;">
                            <div>
                                <h2 style="margin:0 0 4px; font-size:20px; font-weight:700;">${data.name}</h2>
                                <div style="color:var(--text-muted); font-size:14px;">Username: ${data.username || '-'}</div>
                            </div>
                            <div>${statBadge}</div>
                        </div>

                        <div class="detail-grid">
                            <div class="detail-box">
                                <div class="detail-label">Nomor Telepon</div>
                                <div class="detail-value">${data.phone || '-'}</div>
                            </div>
                            <div class="detail-box">
                                <div class="detail-label">Paket Internet</div>
                                <div class="detail-value">${data.package}</div>
                            </div>
                            <div class="detail-box">
                                <div class="detail-label">Area / Wilayah</div>
                                <div class="detail-value">${data.area}</div>
                            </div>
                            <div class="detail-box">
                                <div class="detail-label">Titik ODP</div>
                                <div class="detail-value">${data.odp}</div>
                            </div>
                            <div class="detail-box">
                                <div class="detail-label">Router MikroTik</div>
                                <div class="detail-value">${data.router}</div>
                            </div>
                            <div class="detail-box">
                                <div class="detail-label">Server RADIUS</div>
                                <div class="detail-value">${data.server}</div>
                            </div>
                        </div>

                        <div class="detail-section-title">Alamat & Tanggung Jawab</div>
                        <div style="background:var(--bg-body); padding:12px; border-radius:8px; border:1px solid var(--border); margin-bottom:20px;">
                            <div style="margin-bottom:8px;">
                                <span class="detail-label">Alamat Lengkap:</span>
                                <div class="detail-value">${data.address || '-'}</div>
                            </div>
                            <div>
                                <span class="detail-label">Penanggung Jawab (Sales/Agen):</span>
                                <div class="detail-value">${data.sales}</div>
                            </div>
                        </div>

                        <div class="detail-section-title">Pengaturan Tagihan & Sinkronisasi</div>
                        <div style="background:var(--bg-body); padding:12px; border-radius:8px; border:1px solid var(--border);">
                            <div class="detail-row">
                                <span class="detail-label">Auto Isolir</span>
                                <span class="detail-value">${data.auto_isolir ? `Aktif (Max telat: ${data.max_tunggakan} bulan)` : 'Nonaktif'}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Pakai PPN</span>
                                <span class="detail-value">${data.pakai_ppn ? 'Ya' : 'Tidak'}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Auto WA Tagihan</span>
                                <span class="detail-value">${data.auto_wa_tagihan ? 'Aktif' : 'Nonaktif'}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Sync DB Pusat (API)</span>
                                <span class="detail-value">${data.sync_db_pusat ? '<span style="color:#3b82f6; font-weight:600;">Ya (Sinkron)</span>' : 'Tidak'}</span>
                            </div>
                        </div>
                        
                        <div style="margin-top:20px; display:flex; justify-content:flex-end;">
                            <a href="/customers/${id}/edit" class="btn-primary" style="text-decoration:none;">Edit Lengkap</a>
                        </div>
                    `;
                    document.getElementById('customerDetailBody').innerHTML = html;
                } else {
                    document.getElementById('customerDetailBody').innerHTML = `<div style="text-align:center; padding:40px; color:#ef4444;">Gagal memuat detail pelanggan.</div>`;
                }
            })
            .catch(err => {
                document.getElementById('customerDetailBody').innerHTML = `<div style="text-align:center; padding:40px; color:#ef4444;">Terjadi kesalahan jaringan.</div>`;
            });
    }

    function closeCustomerDetail() {
        document.getElementById('customerDetailModal').style.display = 'none';
    }
</script>
@endpush
