@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/></svg>
Server RADIUS (FreeRADIUS)
@endsection
@section('content')
<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.7fr);gap:16px;align-items:flex-start">
    {{-- FORM TAMBAH / EDIT --}}
    <div class="cfg-card">
        <div class="cfg-card-title" id="rsFormTitle">➕ Tambah Server RADIUS</div>
        <div id="rsFormMsg" class="cfg-alert" style="margin-bottom:8px"></div>
        <input type="hidden" id="rsId">
        <div style="display:flex;flex-direction:column;gap:10px">
            <div>
                <div class="cfg-label">Tipe Server</div>
                <select id="rsType" class="cfg-input" onchange="toggleRsType()">
                    <option value="freeradius">FreeRADIUS MySQL DB</option>
                    <option value="daloradius_api">DaloRADIUS API (Web Token)</option>
                    <option value="radiusdesk_api">RADIUSdesk API (Web Token)</option>
                </select>
            </div>
            <div>
                <div class="cfg-label">Nama Server</div>
                <input type="text" id="rsNama" class="cfg-input" placeholder="Contoh: RADIUS Utama">
            </div>
            
            <!-- DATABASE FIELDS -->
            <div id="rsDbFields" style="display:flex;flex-direction:column;gap:10px">
                <div>
                    <div class="cfg-label">IP / Hostname MySQL</div>
                    <input type="text" id="rsHost" class="cfg-input" placeholder="10.0.0.3">
                </div>
            <div class="cfg-grid-2">
                <div>
                    <div class="cfg-label">Port MySQL</div>
                    <input type="number" id="rsPort" class="cfg-input" placeholder="3306" value="3306">
                </div>
                <div>
                    <div class="cfg-label">Nama Database</div>
                    <input type="text" id="rsDbName" class="cfg-input" placeholder="radius" value="radius">
                </div>
            </div>
            <div>
                <div class="cfg-label">Username MySQL</div>
                <input type="text" id="rsUser" class="cfg-input" placeholder="radius_sync" autocomplete="off">
            </div>
            <div>
                <div class="cfg-label">Password MySQL <span id="rsPassHint" style="color:var(--text-muted);display:none">(kosong = tidak diubah)</span></div>
                <input type="password" id="rsPass" class="cfg-input" placeholder="••••••" autocomplete="new-password">
            </div>
            </div>

            <!-- API FIELDS -->
            <div id="rsApiFields" style="display:none;flex-direction:column;gap:10px">
                <div>
                    <div class="cfg-label">API Endpoint (Base URL)</div>
                    <input type="text" id="rsApiEndpoint" class="cfg-input" placeholder="https://radius.domain.com/api">
                </div>
                <div>
                    <div class="cfg-label">API Token <span id="rsTokenHint" style="color:var(--text-muted);display:none">(kosong = tidak diubah)</span></div>
                    <input type="password" id="rsApiToken" class="cfg-input" placeholder="Token otorisasi API">
                </div>
            </div>

            <div style="display:flex;gap:8px;margin-top:4px">
                <button id="rsSaveBtn" class="cfg-btn cfg-btn-primary" style="flex:1" onclick="saveRS()">✓ Simpan</button>
                <button id="rsCancelBtn" class="cfg-btn cfg-btn-secondary" style="display:none" onclick="resetRSForm()">✕ Batal</button>
            </div>
        </div>
    </div>

    {{-- DAFTAR SERVER RADIUS --}}
    <div class="cfg-card">
        <div class="cfg-card-title">📋 Daftar Server RADIUS</div>
        <div id="rsListMsg" class="cfg-alert" style="margin-bottom:8px"></div>
        <div style="max-height:60vh;overflow:auto">
            <table class="cfg-table">
                <thead>
                    <tr>
                        <th>#</th><th>Nama</th><th>Tipe</th><th>Target (Host/API)</th>
                        <th style="text-align:center">Router</th>
                        <th style="text-align:center">Status</th>
                        <th style="text-align:center">Aksi</th>
                    </tr>
                </thead>
                <tbody id="rsTb">
                    <tr><td colspan="7" style="text-align:center;color:var(--text-muted)">Memuat…</td></tr>
                </tbody>
            </table>
        </div>
        <p style="font-size:.75rem;color:var(--text-muted);margin-top:12px">
            ℹ️ Server RADIUS digunakan untuk autentikasi PPPoE pelanggan.
            Setiap server terhubung ke database MySQL FreeRADIUS (radcheck, radreply, dll).
        </p>
    </div>
</div>

@push('styles')
<style>
    .s-btn{display:inline-flex;align-items:center;gap:3px;padding:3px 8px;border-radius:6px;border:1px solid var(--border);background:rgba(0,0,0,.3);color:var(--text-secondary);font-size:.72rem;cursor:pointer;transition:all .15s;font-family:inherit}
    .s-btn:hover{background:rgba(255,255,255,.08);color:var(--text-primary)}
    .s-btn.edit{border-color:rgba(14,165,233,.5)}
    .s-btn.del{border-color:rgba(239,68,68,.5)}
    .s-btn.test{border-color:rgba(168,85,247,.5)}
    .s-btn.toggle-on{border-color:rgba(234,179,8,.5);color:#fde047}
    .s-btn.toggle-off{border-color:rgba(34,197,94,.5)}
    .badge-on{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.4);color:#4ade80;font-size:.7rem;font-weight:600}
    .badge-off{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(100,116,139,.08);border:1px solid rgba(100,116,139,.3);color:var(--text-muted);font-size:.7rem}
    .badge-count{display:inline-block;padding:2px 8px;border-radius:999px;background:rgba(14,165,233,.1);border:1px solid rgba(14,165,233,.3);color:var(--accent);font-size:.7rem;font-weight:600}
    @media(max-width:900px){
        div[style*="grid-template-columns:minmax(0,1fr) minmax(0,1.7fr)"]{grid-template-columns:1fr !important}
    }
</style>
@endpush

@push('scripts')
<script>
const CSRF = '{{ csrf_token() }}';
const RS = {
    list: '{{ route("config.radius-server") }}',
    store: '{{ route("config.radius-server.store") }}',
    update: id => `/config/radius-server/${id}`,
    destroy: id => `/config/radius-server/${id}`,
    toggle: id => `/config/radius-server/${id}/toggle`,
    test: id => `/config/radius-server/${id}/test`,
};
let editing = false;

function toggleRsType(){
    const t = document.getElementById('rsType').value;
    if(t === 'freeradius'){
        document.getElementById('rsDbFields').style.display = 'flex';
        document.getElementById('rsApiFields').style.display = 'none';
    }else{
        document.getElementById('rsDbFields').style.display = 'none';
        document.getElementById('rsApiFields').style.display = 'flex';
    }
}

function resetRSForm(){
    editing = false;
    document.getElementById('rsId').value = '';
    document.getElementById('rsType').value = 'freeradius';
    ['rsNama','rsHost','rsUser','rsPass','rsDbName','rsApiEndpoint','rsApiToken'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('rsPort').value = '3306';
    document.getElementById('rsDbName').value = 'radius';
    document.getElementById('rsFormTitle').textContent = '➕ Tambah Server RADIUS';
    document.getElementById('rsCancelBtn').style.display = 'none';
    document.getElementById('rsPassHint').style.display = 'none';
    document.getElementById('rsTokenHint').style.display = 'none';
    toggleRsType();
    hideMsg('rsFormMsg');
}

function loadRS(){
    fetch(RS.list, {headers:{'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res => {
        const tb = document.getElementById('rsTb');
        if(!res.data || !res.data.length){
            tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">Belum ada server RADIUS. Tambahkan di form kiri.</td></tr>';
            return;
        }
        tb.innerHTML = res.data.map((s,i) => {
            const active = s.is_active;
            const target = s.type === 'freeradius' ? `<code>${esc(s.host)}:${s.port}</code>` : `<code>${esc(s.api_endpoint)}</code>`;
            let typeLabel = s.type === 'freeradius' ? 'MySQL DB' : (s.type === 'daloradius_api' ? 'DaloRADIUS API' : 'RADIUSdesk API');
            return `<tr>
                <td>${i+1}</td>
                <td style="font-weight:${active?'600':'400'};color:${active?'var(--text-primary)':'var(--text-muted)'}">${esc(s.name)}</td>
                <td><span style="font-size:11px;background:#e2e8f0;padding:2px 6px;border-radius:4px;">${typeLabel}</span></td>
                <td>${target}</td>
                <td style="text-align:center">${s.routers_count > 0 ? `<span class="badge-count">${s.routers_count} router</span>` : '<span style="color:var(--text-muted);font-size:.72rem">—</span>'}</td>
                <td style="text-align:center">${active?'<span class="badge-on">● Aktif</span>':'<span class="badge-off">Nonaktif</span>'}</td>
                <td style="text-align:center">
                    <div style="display:flex;gap:4px;justify-content:center;flex-wrap:wrap">
                        <button class="s-btn test" onclick="testRS(${s.id},'${esc(s.name)}')">🔌 Tes</button>
                        ${active
                            ?`<button class="s-btn toggle-on" onclick="toggleRS(${s.id},'${esc(s.name)}')">⏸</button>`
                            :`<button class="s-btn toggle-off" onclick="toggleRS(${s.id},'${esc(s.name)}')">▶ Aktifkan</button>`}
                        <button class="s-btn edit" onclick='editRS(${JSON.stringify(s)})'>✏️</button>
                        <button class="s-btn del" onclick="deleteRS(${s.id},'${esc(s.name)}')">🗑</button>
                    </div>
                </td>
            </tr>`;
        }).join('');
    })
    .catch(() => {
        document.getElementById('rsTb').innerHTML = '<tr><td colspan="7" style="text-align:center;color:#f87171">Gagal memuat data.</td></tr>';
    });
}

function saveRS(){
    const id = document.getElementById('rsId').value;
    const type = document.getElementById('rsType').value;
    const payload = {
        name: document.getElementById('rsNama').value.trim(),
        type: type,
        host: document.getElementById('rsHost').value.trim(),
        port: parseInt(document.getElementById('rsPort').value || '3306'),
        db_name: document.getElementById('rsDbName').value.trim() || 'radius',
        username: document.getElementById('rsUser').value.trim() || null,
        db_password: document.getElementById('rsPass').value || null,
        api_endpoint: document.getElementById('rsApiEndpoint').value.trim() || null,
        api_token: document.getElementById('rsApiToken').value || null,
    };

    if(!payload.name || (type==='freeradius' && !payload.host) || (type!=='freeradius' && !payload.api_endpoint)){
        showMsg('rsFormMsg','err','Lengkapi isian yang wajib (Host / Endpoint).');
        return;
    }

    const url = editing ? RS.update(id) : RS.store;
    const method = editing ? 'PUT' : 'POST';

    const btn = document.getElementById('rsSaveBtn');
    btn.disabled = true; btn.textContent = 'Menyimpan…';

    fetch(url, {
        method, headers:{'Content-Type':'application/json','X-CSRF-TOKEN':CSRF,'Accept':'application/json'},
        body: JSON.stringify(payload)
    })
    .then(r=>r.json())
    .then(res => {
        if(res.status==='success'){ showMsg('rsFormMsg','ok',res.message); resetRSForm(); loadRS(); }
        else showMsg('rsFormMsg','err',res.message||'Gagal menyimpan.');
    })
    .catch(()=>showMsg('rsFormMsg','err','Gagal menghubungi server.'))
    .finally(()=>{ btn.disabled=false; btn.textContent='✓ Simpan'; });
}

function editRS(s){
    editing = true;
    document.getElementById('rsId').value = s.id;
    document.getElementById('rsType').value = s.type;
    document.getElementById('rsNama').value = s.name;
    document.getElementById('rsHost').value = s.host || '';
    document.getElementById('rsPort').value = s.port || '3306';
    document.getElementById('rsDbName').value = s.db_name || 'radius';
    document.getElementById('rsUser').value = s.username || '';
    document.getElementById('rsPass').value = '';
    document.getElementById('rsApiEndpoint').value = s.api_endpoint || '';
    document.getElementById('rsApiToken').value = '';
    document.getElementById('rsFormTitle').textContent = '✏️ Edit Server RADIUS';
    document.getElementById('rsCancelBtn').style.display = 'inline-flex';
    document.getElementById('rsPassHint').style.display = 'inline';
    document.getElementById('rsTokenHint').style.display = 'inline';
    toggleRsType();
    hideMsg('rsFormMsg');
    window.scrollTo({top:0,behavior:'smooth'});
}

function deleteRS(id, name){
    if(!confirm(`Hapus server RADIUS "${name}"?`)) return;
    fetch(RS.destroy(id), {method:'DELETE',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{ showMsg('rsListMsg',res.status==='success'?'ok':'err',res.message); if(res.status==='success') loadRS(); })
    .catch(()=>showMsg('rsListMsg','err','Gagal menghubungi server.'));
}

function toggleRS(id, name){
    if(!confirm(`Toggle status server RADIUS "${name}"?`)) return;
    fetch(RS.toggle(id), {method:'POST',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res=>{ showMsg('rsListMsg',res.status==='success'?'ok':'err',res.message); if(res.status==='success') loadRS(); })
    .catch(()=>showMsg('rsListMsg','err','Gagal.'));
}

function testRS(id, name){
    showMsg('rsListMsg','ok',`🔄 Mengecek koneksi ke "${name}"…`);
    fetch(RS.test(id), {method:'POST',headers:{'X-CSRF-TOKEN':CSRF,'Accept':'application/json'}})
    .then(r=>r.json())
    .then(res => {
        let msg = res.message;
        if(res.status === 'success' && res.has_radcheck !== undefined){
            msg += res.has_radcheck
                ? ` — Tabel radcheck ditemukan (${res.user_count} user).`
                : ' — ⚠️ Tabel radcheck TIDAK ditemukan!';
        }
        showMsg('rsListMsg', res.status==='success'?'ok':'err', msg);
    })
    .catch(()=>showMsg('rsListMsg','err','Gagal menghubungi server.'));
}

function showMsg(elId, cls, msg){
    const el = document.getElementById(elId);
    el.className = 'cfg-alert ' + cls;
    el.textContent = msg;
    el.style.display = 'block';
    if(cls !== 'info') setTimeout(()=>{ el.style.display='none'; }, 8000);
}
function hideMsg(elId){ document.getElementById(elId).style.display='none'; }
function esc(s){ return (s||'').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

// Init
loadRS();
</script>
@endpush
@endsection
