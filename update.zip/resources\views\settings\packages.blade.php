@extends('layouts.app')
@section('title', 'Master Paket')
@section('content')
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
    <h1 style="font-size:22px; font-weight:700;">📦 Master Paket</h1>
    <button class="btn-primary" onclick="document.getElementById('addModal').style.display='flex'">+ Tambah Paket</button>
</div>
@if(session('success'))<div class="alert-success">✅ {{ session('success') }}</div>@endif
@if(session('error'))<div class="alert-error">❌ {{ session('error') }}</div>@endif

<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(320px,1fr)); gap:16px;">
    @foreach($packages as $pkg)
    @php $routerMap = $pkg->packageRouters->keyBy('router_id'); @endphp
    <div class="card" style="position:relative; {{ !$pkg->is_active ? 'opacity:.5' : '' }}">
        <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:8px;">
            <h3 style="font-size:16px; font-weight:700;">{{ $pkg->name }}</h3>
            <span class="badge">{{ $pkg->speed }}</span>
        </div>
        <div style="font-size:22px; font-weight:700; color:var(--accent); margin-bottom:8px;">Rp {{ number_format($pkg->price,0,',','.') }}</div>
        @if($pkg->description)<div style="font-size:13px; color:var(--text-muted); margin-bottom:8px;">{{ $pkg->description }}</div>@endif

        {{-- Router assignments --}}
        @if($pkg->packageRouters->count() > 0)
        <div style="padding:8px;background:rgba(99,102,241,.06);border-radius:8px;margin-bottom:8px;">
            <div style="font-size:11px;font-weight:600;color:var(--accent);margin-bottom:4px;text-transform:uppercase;">🖥️ Router</div>
            @foreach($pkg->packageRouters as $pr)
            <div style="font-size:12px;color:var(--text-secondary);padding:2px 0;display:flex;gap:8px;align-items:center;">
                <strong>{{ $pr->router?->name ?? '?' }}</strong>
                @if($pr->pppoe_profile)<span style="color:#a78bfa;">profil: {{ $pr->pppoe_profile }}</span>@endif
                @if($pr->isolir_profile)<span style="color:#f97316;">isolir: {{ $pr->isolir_profile }}</span>@endif
            </div>
            @endforeach
        </div>
        @endif

        {{-- RADIUS --}}
        @if($pkg->radius_group || $pkg->radius_group_isolir)
        <div style="padding:8px;background:rgba(96,165,250,.06);border-radius:8px;margin-bottom:8px;">
            <div style="font-size:11px;font-weight:600;color:#60a5fa;margin-bottom:4px;text-transform:uppercase;">🔵 RADIUS</div>
            @if($pkg->radius_group)<div style="font-size:12px;color:var(--text-secondary);">Group: <strong>{{ $pkg->radius_group }}</strong></div>@endif
            @if($pkg->radius_group_isolir)<div style="font-size:12px;color:var(--text-secondary);">Isolir: <strong>{{ $pkg->radius_group_isolir }}</strong></div>@endif
        </div>
        @endif

        <div style="font-size:12px; color:var(--text-muted); padding-top:8px; border-top:1px solid var(--border); margin-top:8px; display:flex; justify-content:space-between; align-items:center;">
            <div>👥 {{ $pkg->customers_count ?? 0 }} pelanggan</div>
            <div style="display:flex;gap:6px;">
                <button onclick="openEdit({{ $pkg->id }})" class="btn-sm" title="Edit">✏️</button>
                @if(($pkg->customers_count ?? 0) == 0)
                <form method="POST" action="{{ route('settings.packages.destroy', $pkg) }}" onsubmit="return confirm('Hapus paket {{ $pkg->name }}?')" style="display:inline">@csrf @method('DELETE')
                    <button type="submit" class="btn-sm btn-danger-sm" title="Hapus">🗑️</button>
                </form>
                @endif
            </div>
        </div>
        @if(!$pkg->is_active)<div style="position:absolute;top:8px;right:8px;padding:2px 8px;border-radius:99px;font-size:10px;font-weight:600;background:rgba(239,68,68,.15);color:#f87171;">Nonaktif</div>@endif
    </div>
    @endforeach
</div>

{{-- ========== MODAL TAMBAH ========== --}}
<div id="addModal" class="modal-overlay" style="display:none;" onclick="if(event.target===this)this.style.display='none'">
    <div class="modal-content">
        <div class="modal-header"><h3>Tambah Paket</h3><button onclick="this.closest('.modal-overlay').style.display='none'" class="modal-close">&times;</button></div>
        <form method="POST" action="{{ route('settings.packages.store') }}">@csrf
            <div class="modal-body">
                <div class="form-row"><div class="form-group"><label>Nama *</label><input type="text" name="name" required class="input-field" placeholder="Paket 10M"></div><div class="form-group"><label>Speed *</label><input type="text" name="speed" required class="input-field" placeholder="10Mbps"></div></div>
                <div class="form-group"><label>Harga (Rp) *</label><input type="number" name="price" required class="input-field" min="0" placeholder="150000"></div>

                {{-- ROUTER SECTION --}}
                @if($routers->isNotEmpty())
                <div class="section-toggle">
                    <label class="toggle-label"><input type="checkbox" id="addUseRouter" onchange="toggleSection('addRouterSection', this.checked)"><span class="toggle-text">🖥️ Gunakan Router</span></label>
                </div>
                <div id="addRouterSection" class="toggle-content" style="display:none;">
                    @foreach($routers as $r)
                    @php $profilesJson = $r->pppoeProfiles->map(fn($p) => ['name' => $p->name])->values()->toJson(); @endphp
                    <div class="router-item">
                        <label class="router-toggle"><input type="checkbox" name="router_profiles[{{ $r->id }}][enabled]" value="1" onchange="toggleRouterDetail(this, 'add-router-{{ $r->id }}')"><strong>{{ $r->name }}</strong> <small style="color:var(--text-muted)">({{ $r->host }})</small></label>
                        <div id="add-router-{{ $r->id }}" class="router-detail" style="display:none;" data-router-id="{{ $r->id }}">
                            <div class="form-row">
                                <div class="form-group"><label>PPPoE Profile</label><select name="router_profiles[{{ $r->id }}][pppoe_profile]" class="input-field profile-select"><option value="">-- Pilih Profil --</option></select></div>
                                <div class="form-group"><label>Profil Isolir</label><select name="router_profiles[{{ $r->id }}][isolir_profile]" class="input-field isolir-select"><option value="">-- Pilih Profil --</option></select></div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                @endif

                {{-- RADIUS SECTION --}}
                <div class="section-toggle">
                    <label class="toggle-label"><input type="checkbox" id="addUseRadius" onchange="toggleSection('addRadiusSection', this.checked)"><span class="toggle-text">🔵 Gunakan RADIUS</span></label>
                </div>
                <div id="addRadiusSection" class="toggle-content" style="display:none;">
                    <div class="form-row">
                        <div class="form-group"><label>RADIUS Group</label><input type="text" name="radius_group" class="input-field" list="db_pusat_profiles_list" placeholder="group-10m"></div>
                        <div class="form-group"><label>RADIUS Isolir Group</label><input type="text" name="radius_group_isolir" class="input-field" list="db_pusat_profiles_list" placeholder="group-isolir"></div>
                    </div>
                </div>

                <div class="form-group" style="margin-top:12px;"><label>Deskripsi</label><textarea name="description" rows="2" class="input-field"></textarea></div>
            </div>
            <div class="modal-footer"><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Batal</button><button type="submit" class="btn-primary">Simpan</button></div>
        </form>
    </div>
</div>

{{-- ========== MODAL EDIT (per paket) ========== --}}
@foreach($packages as $pkg)
@php $assignedRouters = $pkg->packageRouters->keyBy('router_id'); @endphp
<div id="editModal-{{ $pkg->id }}" class="modal-overlay" style="display:none;" onclick="if(event.target===this)this.style.display='none'">
    <div class="modal-content">
        <div class="modal-header"><h3>Edit: {{ $pkg->name }}</h3><button onclick="this.closest('.modal-overlay').style.display='none'" class="modal-close">&times;</button></div>
        <form method="POST" action="{{ route('settings.packages.update', $pkg) }}">@csrf @method('PUT')
            <div class="modal-body">
                <div class="form-row"><div class="form-group"><label>Nama *</label><input type="text" name="name" required class="input-field" value="{{ $pkg->name }}"></div><div class="form-group"><label>Speed *</label><input type="text" name="speed" required class="input-field" value="{{ $pkg->speed }}"></div></div>
                <div class="form-group"><label>Harga (Rp) *</label><input type="number" name="price" required class="input-field" min="0" value="{{ $pkg->price }}"></div>

                {{-- ROUTER SECTION --}}
                @if($routers->isNotEmpty())
                <div class="section-toggle">
                    <label class="toggle-label"><input type="checkbox" {{ $assignedRouters->count() > 0 ? 'checked' : '' }} onchange="toggleSection('editRouterSection-{{ $pkg->id }}', this.checked)"><span class="toggle-text">🖥️ Gunakan Router</span></label>
                </div>
                <div id="editRouterSection-{{ $pkg->id }}" class="toggle-content" style="{{ $assignedRouters->count() > 0 ? '' : 'display:none;' }}">
                    @foreach($routers as $r)
                    @php
                        $profilesJson = $r->pppoeProfiles->map(fn($p) => ['name' => $p->name])->values()->toJson();
                        $assigned = $assignedRouters->get($r->id);
                        $isAssigned = $assigned !== null;
                    @endphp
                    <div class="router-item">
                        <label class="router-toggle"><input type="checkbox" name="router_profiles[{{ $r->id }}][enabled]" value="1" {{ $isAssigned ? 'checked' : '' }} onchange="toggleRouterDetail(this, 'edit{{ $pkg->id }}-router-{{ $r->id }}')"><strong>{{ $r->name }}</strong> <small style="color:var(--text-muted)">({{ $r->host }})</small></label>
                        <div id="edit{{ $pkg->id }}-router-{{ $r->id }}" class="router-detail" style="{{ $isAssigned ? '' : 'display:none;' }}" data-router-id="{{ $r->id }}" data-selected-profile="{{ $assigned?->pppoe_profile }}" data-selected-isolir="{{ $assigned?->isolir_profile }}">
                            <div class="form-row">
                                <div class="form-group"><label>PPPoE Profile</label><select name="router_profiles[{{ $r->id }}][pppoe_profile]" class="input-field profile-select"><option value="">-- Pilih Profil --</option></select></div>
                                <div class="form-group"><label>Profil Isolir</label><select name="router_profiles[{{ $r->id }}][isolir_profile]" class="input-field isolir-select"><option value="">-- Pilih Profil --</option></select></div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                @endif

                {{-- RADIUS SECTION --}}
                <div class="section-toggle">
                    <label class="toggle-label"><input type="checkbox" {{ ($pkg->radius_group || $pkg->radius_group_isolir) ? 'checked' : '' }} onchange="toggleSection('editRadiusSection-{{ $pkg->id }}', this.checked)"><span class="toggle-text">🔵 Gunakan RADIUS</span></label>
                </div>
                <div id="editRadiusSection-{{ $pkg->id }}" class="toggle-content" style="{{ ($pkg->radius_group || $pkg->radius_group_isolir) ? '' : 'display:none;' }}">
                    <div class="form-row">
                        <div class="form-group"><label>RADIUS Group</label><input type="text" name="radius_group" class="input-field" list="db_pusat_profiles_list" value="{{ $pkg->radius_group }}"></div>
                        <div class="form-group"><label>RADIUS Isolir Group</label><input type="text" name="radius_group_isolir" class="input-field" list="db_pusat_profiles_list" value="{{ $pkg->radius_group_isolir }}"></div>
                    </div>
                </div>

                <div class="form-group" style="margin-top:12px;"><label>Deskripsi</label><textarea name="description" rows="2" class="input-field">{{ $pkg->description }}</textarea></div>
                <label class="toggle-label" style="margin-top:8px"><input type="checkbox" name="is_active" {{ $pkg->is_active ? 'checked' : '' }}><span class="toggle-text">Aktif</span></label>
            </div>
            <div class="modal-footer"><button type="button" onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Batal</button><button type="submit" class="btn-primary">Update</button></div>
        </form>
    </div>
</div>
@endforeach

<script>
function toggleSection(id, show) {
    document.getElementById(id).style.display = show ? '' : 'none';
}

function toggleRouterDetail(checkbox, detailId) {
    const detail = document.getElementById(detailId);
    detail.style.display = checkbox.checked ? '' : 'none';
    if (checkbox.checked && !detail.dataset.loaded) {
        loadProfilesFromAPI(detail);
    }
}

function loadProfilesFromAPI(detail) {
    const routerId = detail.dataset.routerId;
    const profileSelect = detail.querySelector('.profile-select');
    const isolirSelect = detail.querySelector('.isolir-select');
    const selectedProfile = detail.dataset.selectedProfile || '';
    const selectedIsolir = detail.dataset.selectedIsolir || '';

    // Show loading
    profileSelect.innerHTML = '<option value="">⏳ Memuat...</option>';
    isolirSelect.innerHTML = '<option value="">⏳ Memuat...</option>';

    fetch('/settings/packages/router/' + routerId + '/profiles')
        .then(r => r.json())
        .then(profiles => {
            profileSelect.innerHTML = '<option value="">-- Pilih Profil --</option>';
            isolirSelect.innerHTML = '<option value="">-- Pilih Profil Isolir --</option>';

            if (profiles.length === 0) {
                profileSelect.innerHTML += '<option value="" disabled>Tidak ada profil</option>';
                isolirSelect.innerHTML += '<option value="" disabled>Tidak ada profil</option>';
            }

            profiles.forEach(p => {
                const label = p.rate_limit ? p.name + ' (' + p.rate_limit + ')' : p.name;
                profileSelect.add(new Option(label, p.name, false, p.name === selectedProfile));
                isolirSelect.add(new Option(label, p.name, false, p.name === selectedIsolir));
            });

            detail.dataset.loaded = '1';
        })
        .catch(() => {
            profileSelect.innerHTML = '<option value="">❌ Gagal memuat</option>';
            isolirSelect.innerHTML = '<option value="">❌ Gagal memuat</option>';
        });
}

function openEdit(id) {
    const modal = document.getElementById('editModal-' + id);
    modal.style.display = 'flex';
    // Load profiles for checked routers
    modal.querySelectorAll('.router-detail').forEach(detail => {
        if (!detail.dataset.loaded && detail.style.display !== 'none') {
            loadProfilesFromAPI(detail);
        }
    });
}
</script>
<datalist id="db_pusat_profiles_list">
    @foreach($db_pusat_profiles ?? [] as $p)
        <option value="{{ $p }}">
    @endforeach
</datalist>
@endpush
@endsection
@push('styles')
<style>
.btn-primary{padding:10px 20px;background:var(--gradient);border:none;border-radius:10px;color:white;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px}
.btn-secondary{padding:8px 16px;background:var(--bg-card);border:1px solid var(--border);border-radius:8px;color:var(--text-secondary);font-size:13px;cursor:pointer;font-family:inherit}
.btn-sm{width:30px;height:30px;border:1px solid var(--border);background:rgba(255,255,255,.06);border-radius:6px;cursor:pointer;font-size:12px;display:inline-flex;align-items:center;justify-content:center;transition:all .2s}
.btn-sm:hover{background:rgba(255,255,255,.12)}
.btn-danger-sm:hover{background:rgba(239,68,68,.2)!important;border-color:rgba(239,68,68,.3)!important}
.alert-success{padding:12px 16px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:10px;color:#22c55e;margin-bottom:16px;font-size:14px}
.alert-error{padding:12px 16px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);border-radius:10px;color:#f87171;margin-bottom:16px;font-size:14px}
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:20px;box-shadow:var(--shadow-sm);transition:transform .2s}.card:hover{transform:translateY(-2px)}
.badge{display:inline-block;padding:3px 10px;border-radius:6px;font-size:12px;font-weight:500;background:rgba(99,102,241,.1);color:var(--accent)}
.input-field{padding:8px 12px;background:var(--bg-card);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);font-size:14px;font-family:inherit;outline:none;width:100%}.input-field:focus{border-color:var(--accent)}
select.input-field{appearance:auto}
textarea.input-field{resize:vertical}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)}.modal-content{background:var(--bg-card);border:1px solid var(--border);border-radius:16px;width:100%;max-width:560px;box-shadow:0 20px 60px rgba(0,0,0,.3);max-height:90vh;overflow-y:auto}.modal-header{display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid var(--border)}.modal-close{width:32px;height:32px;border:none;background:none;font-size:24px;color:var(--text-muted);cursor:pointer}.modal-body{padding:24px}.modal-footer{padding:16px 24px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:10px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.form-group{margin-bottom:12px}.form-group label{display:block;font-size:13px;font-weight:500;color:var(--text-secondary);margin-bottom:4px}
.section-toggle{margin:12px 0 4px;padding:8px 12px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:8px}
.toggle-label{display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;font-weight:500;color:var(--text-primary)}
.toggle-label input{accent-color:var(--accent)}
.toggle-text{font-size:14px}
.toggle-content{padding:8px 0;}
.router-item{padding:8px 12px;margin-bottom:6px;background:rgba(0,0,0,.12);border:1px solid var(--border);border-radius:8px}
.router-toggle{display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px;color:var(--text-primary)}
.router-toggle input{accent-color:var(--accent)}
.router-detail{margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,.06)}
</style>
@endpush
