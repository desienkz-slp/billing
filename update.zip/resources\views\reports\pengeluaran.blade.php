@extends('layouts.app')
@section('title', 'Detail Pengeluaran')
@section('content')
<div style="margin-bottom:20px;"><h1 style="font-size:22px; font-weight:700;">💰 Laporan Pengeluaran</h1><p style="color:var(--text-muted); font-size:14px;">Periode {{ \Carbon\Carbon::parse($month.'-01')->locale('id')->isoFormat('MMMM YYYY') }}</p></div>
@if(session('success'))<div class="alert-success">✅ {{ session('success') }}</div>@endif
<div class="kpi-grid"><div class="kpi-card" style="background:linear-gradient(135deg,#7f1d1d,#b91c1c);"><div class="kpi-label">Total Pengeluaran</div><div class="kpi-value" style="color:#fca5a5">Rp {{ number_format($total) }}</div><div class="kpi-sub">{{ $expenses->count() }} item</div></div></div>
<div class="card" style="padding:16px; margin-bottom:16px;">
    <form method="GET" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
        <div><label class="form-label">Periode</label><input type="month" name="month" value="{{ $month }}" class="form-input"></div>
        <button type="submit" class="btn-primary">🔍 Filter</button>
    </form>
</div>
@if($user->is_system_admin || $user->role?->can_manage_expenses)
<div class="card" style="padding:16px; margin-bottom:16px;">
    <h3 style="font-size:15px; font-weight:600; margin-bottom:12px;">➕ Tambah Pengeluaran</h3>
    <form method="POST" action="{{ route('reports.pengeluaran.store') }}" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
        @csrf
        <div><label class="form-label">Deskripsi</label><input type="text" name="description" required class="form-input" placeholder="Nama pengeluaran"></div>
        <div><label class="form-label">Kategori</label><select name="category" class="form-input">@foreach($categories as $c)<option value="{{ $c }}">{{ ucfirst($c) }}</option>@endforeach</select></div>
        <div><label class="form-label">Nominal (Rp)</label><input type="number" name="amount" required min="1" class="form-input" placeholder="0"></div>
        <button type="submit" class="btn-primary">💾 Simpan</button>
    </form>
</div>
@endif
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>#</th><th>Tgl</th><th>Deskripsi</th><th>Kategori</th><th>Dibuat Oleh</th><th style="text-align:right">Nominal</th></tr></thead>
        <tbody>
        @forelse($expenses as $i => $e)
        <tr><td>{{ $i+1 }}</td><td style="font-size:12px;color:var(--text-muted)">{{ $e->expense_date->format('d/m/Y') }}</td><td>{{ $e->description }}</td><td>{{ ucfirst($e->category ?? 'lainnya') }}</td><td style="font-size:12px;color:var(--text-muted)">{{ $e->creator?->name ?? '-' }}</td><td style="text-align:right;color:#fca5a5;font-weight:600">{{ number_format($e->amount) }}</td></tr>
        @empty
        <tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted);">Belum ada pengeluaran.</td></tr>
        @endforelse
        @if($expenses->count())<tr style="border-top:2px solid var(--border);font-weight:700;background:rgba(239,68,68,.06);"><td colspan="5" style="text-align:right">Total:</td><td style="text-align:right;color:#dc2626">{{ number_format($total) }}</td></tr>@endif
        </tbody>
    </table>
</div>
@endsection
@push('styles')<style>.alert-success{padding:12px 16px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:10px;color:#22c55e;margin-bottom:16px;font-size:14px}.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:20px}.kpi-card{padding:20px;border-radius:var(--radius);border:1px solid var(--border)}.kpi-label{font-size:13px;color:rgba(255,255,255,.85);margin-bottom:4px}.kpi-value{font-size:24px;font-weight:800;color:#fff}.kpi-sub{font-size:12px;color:rgba(255,255,255,.7);margin-top:4px}.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}.form-label{display:block;font-size:12px;color:var(--text-muted);margin-bottom:4px;font-weight:600}.form-input{padding:8px 12px;border:1px solid var(--border);border-radius:8px;background:var(--bg-body);color:var(--text);font-size:14px;font-family:inherit}.btn-primary{padding:8px 16px;background:var(--accent);color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit}.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:10px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}</style>@endpush
