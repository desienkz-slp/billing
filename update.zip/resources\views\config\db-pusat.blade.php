@extends('layouts.config')

@section('title', 'DB Pusat - Config')

@section('content')
<div class="cfg-card">
    <div style="margin-bottom:24px;">
        <h2 class="cfg-card-title" style="font-size:18px; margin:0 0 4px;">Integrasi DB Pusat</h2>
        <p style="color:var(--text-muted); font-size:13px; margin:0;">Atur koneksi ke database RADIUS terpusat (daloRADIUS / RADIUSdesk) untuk sinkronisasi otomatis.</p>
    </div>

    @if(session('success'))
        <div class="cfg-alert ok" style="margin-bottom:20px;">
            <div style="display:flex; align-items:center; gap:8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                {{ session('success') }}
            </div>
        </div>
    @endif

    <form action="{{ route('config.db-pusat.update') }}" method="POST">
        @csrf

        <div class="cfg-grid-2" style="margin-bottom:16px;">
            <div>
                <div class="cfg-label">Software DB Pusat <span style="color:#ef4444;">*</span></div>
                <select name="db_pusat_software" class="cfg-input" required>
                    <option value="daloradius" {{ ($configs['db_pusat_software'] ?? '') == 'daloradius' ? 'selected' : '' }}>daloRADIUS</option>
                    <option value="radiusdesk" {{ ($configs['db_pusat_software'] ?? '') == 'radiusdesk' ? 'selected' : '' }}>RADIUSdesk</option>
                </select>
            </div>
            <div>
                <div class="cfg-label">Tipe Database <span style="color:#ef4444;">*</span></div>
                <select name="db_pusat_type" class="cfg-input" required>
                    <option value="mysql" {{ ($configs['db_pusat_type'] ?? '') == 'mysql' ? 'selected' : '' }}>MySQL / MariaDB</option>
                    <option value="pgsql" {{ ($configs['db_pusat_type'] ?? '') == 'pgsql' ? 'selected' : '' }}>PostgreSQL</option>
                    <option value="api" {{ ($configs['db_pusat_type'] ?? '') == 'api' ? 'selected' : '' }}>Hanya API (REST)</option>
                </select>
            </div>
        </div>

        <div style="margin-bottom:16px;">
            <div class="cfg-label">Tipe Autentikasi API / Web <span style="color:#ef4444;">*</span></div>
            <select name="db_pusat_auth_type" id="authTypeSelect" class="cfg-input" required onchange="toggleAuthFields()">
                <option value="token" {{ ($configs['db_pusat_auth_type'] ?? 'token') == 'token' ? 'selected' : '' }}>API Web Token</option>
                <option value="web" {{ ($configs['db_pusat_auth_type'] ?? '') == 'web' ? 'selected' : '' }}>Web Tanpa Token (Username & Password)</option>
            </select>
        </div>

        <div style="margin-bottom:16px;">
            <div class="cfg-label">URL DB Pusat / Endpoint API <span style="color:#ef4444;">*</span></div>
            <input type="url" name="db_pusat_url" value="{{ $configs['db_pusat_url'] ?? '' }}" class="cfg-input" placeholder="https://radius.domain.com/api" required>
        </div>

        <div id="tokenFieldGroup" style="margin-bottom:16px;">
            <div class="cfg-label">Token / API Key</div>
            <input type="text" name="db_pusat_token" value="{{ $configs['db_pusat_token'] ?? '' }}" class="cfg-input" placeholder="Masukkan token akses (Bearer/API Key)">
        </div>

        <div id="webAuthGroup" class="cfg-grid-2" style="display:none; margin-bottom:16px;">
            <div>
                <div class="cfg-label">Username</div>
                <input type="text" name="db_pusat_username" value="{{ $configs['db_pusat_username'] ?? '' }}" class="cfg-input" placeholder="Username untuk login">
            </div>
            <div>
                <div class="cfg-label">Password</div>
                <input type="password" name="db_pusat_password" value="{{ $configs['db_pusat_password'] ?? '' }}" class="cfg-input" placeholder="Password untuk login">
            </div>
        </div>

        <div style="display:flex; justify-content:flex-end; margin-top:24px; padding-top:20px; border-top:1px solid var(--border);">
            <button type="submit" class="cfg-btn cfg-btn-primary">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Simpan Konfigurasi
            </button>
        </div>
    </form>
</div>

@push('scripts')
<script>
    function toggleAuthFields() {
        const authType = document.getElementById('authTypeSelect').value;
        const tokenGroup = document.getElementById('tokenFieldGroup');
        const webGroup = document.getElementById('webAuthGroup');

        if (authType === 'token') {
            tokenGroup.style.display = 'block';
            webGroup.style.display = 'none';
        } else {
            tokenGroup.style.display = 'none';
            webGroup.style.display = 'grid'; // because of cfg-grid-2
        }
    }

    // Run on init
    document.addEventListener('DOMContentLoaded', toggleAuthFields);
</script>
@endpush
@endsection
