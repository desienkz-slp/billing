<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Payment;
use App\Models\Package;
use App\Services\PermissionService;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function __construct(private PermissionService $permissionService) {}

    public function statistics(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;

        // Monthly revenue (12 months)
        $revenueMonthly = Payment::where('status', 'paid')
            ->where('payment_date', '>=', now()->subMonths(12)->startOfMonth())
            ->selectRaw("to_char(payment_date, 'YYYY-MM') as period, COUNT(*) as count, SUM(paid_amount) as total")
            ->groupByRaw("to_char(payment_date, 'YYYY-MM')")
            ->orderBy('period')
            ->get();

        // Customer growth
        $customerGrowth = Customer::where('registration_date', '>=', now()->subMonths(6)->startOfMonth())
            ->selectRaw("to_char(registration_date, 'YYYY-MM') as period, COUNT(*) as count")
            ->groupByRaw("to_char(registration_date, 'YYYY-MM')")
            ->orderBy('period')
            ->get();

        // Package distribution
        $packageDist = Customer::where('status', 'active')
            ->selectRaw('package_id, COUNT(*) as count')
            ->groupBy('package_id')
            ->with('package')
            ->get();

        // Payment method stats
        $methodStats = Payment::where('status', 'paid')
            ->whereYear('payment_date', now()->year)
            ->selectRaw('payment_method, COUNT(*) as count, SUM(paid_amount) as total')
            ->groupBy('payment_method')
            ->get();

        // Top collectors
        $topCollectors = Payment::where('status', 'paid')
            ->whereMonth('payment_date', now()->month)
            ->whereYear('payment_date', now()->year)
            ->selectRaw('collected_by, COUNT(*) as count, SUM(paid_amount) as total')
            ->groupBy('collected_by')
            ->with('collector')
            ->orderByDesc('total')
            ->limit(10)
            ->get();

        return view('reports.statistics', compact(
            'user', 'capabilities', 'tenant',
            'revenueMonthly', 'customerGrowth', 'packageDist', 'methodStats', 'topCollectors'
        ));
    }

    public function finance(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $year = $request->get('year', now()->year);

        // Monthly P&L
        $monthlyData = [];
        for ($m = 1; $m <= 12; $m++) {
            $revenue = Payment::where('status', 'paid')
                ->whereMonth('payment_date', $m)->whereYear('payment_date', $year)
                ->sum('paid_amount');
            $ppn = Payment::where('status', 'paid')
                ->whereMonth('payment_date', $m)->whereYear('payment_date', $year)
                ->sum('ppn_amount');
            $discount = Payment::where('status', 'paid')
                ->whereMonth('payment_date', $m)->whereYear('payment_date', $year)
                ->sum('discount');
            $count = Payment::where('status', 'paid')
                ->whereMonth('payment_date', $m)->whereYear('payment_date', $year)
                ->count();

            $monthlyData[] = [
                'month' => \Carbon\Carbon::create($year, $m)->locale('id')->isoFormat('MMM'),
                'revenue' => $revenue,
                'ppn' => $ppn,
                'discount' => $discount,
                'net' => $revenue - $ppn,
                'count' => $count,
            ];
        }

        $yearTotal = [
            'revenue' => array_sum(array_column($monthlyData, 'revenue')),
            'ppn' => array_sum(array_column($monthlyData, 'ppn')),
            'discount' => array_sum(array_column($monthlyData, 'discount')),
            'net' => array_sum(array_column($monthlyData, 'net')),
            'count' => array_sum(array_column($monthlyData, 'count')),
        ];

        return view('reports.finance', compact('user', 'capabilities', 'tenant', 'monthlyData', 'yearTotal', 'year'));
    }

    // ===== BATCH B: Detail Pendapatan =====
    public function detailPendapatan(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $payments = Payment::with(['customer.package', 'customer.area', 'collector'])
            ->where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])
            ->orderByDesc('payment_date')->orderByDesc('id')
            ->get();

        $totals = [
            'harga' => $payments->sum('amount'),
            'diskon' => $payments->sum('discount'),
            'ppn' => $payments->sum('ppn_amount'),
            'paid' => $payments->sum('paid_amount'),
            'count' => $payments->count(),
        ];

        $areas = \App\Models\Area::orderBy('name')->get();
        return view('reports.detail-pendapatan', compact('user', 'capabilities', 'tenant', 'payments', 'totals', 'month', 'areas'));
    }

    // ===== Detail Pengeluaran =====
    public function pengeluaran(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $expenses = \App\Models\Expense::with('creator')
            ->whereRaw("to_char(expense_date, 'YYYY-MM') = ?", [$month])
            ->where('status', 'active')
            ->orderByDesc('id')->get();

        $total = $expenses->sum('amount');
        $categories = ['operasional','promosi','transport','perlengkapan','deviden','lainnya'];

        return view('reports.pengeluaran', compact('user', 'capabilities', 'tenant', 'expenses', 'total', 'month', 'categories'));
    }

    public function storePengeluaran(Request $request)
    {
        $data = $request->validate([
            'description' => 'required|string|max:255',
            'category' => 'required|string|max:100',
            'amount' => 'required|integer|min:1',
        ]);
        $data['tenant_id'] = $request->user()->tenant_id;
        $data['created_by'] = $request->user()->id;
        $data['expense_date'] = now()->toDateString();
        $data['status'] = 'active';
        \App\Models\Expense::create($data);
        return back()->with('success', 'Pengeluaran berhasil ditambahkan.');
    }

    // ===== PPN =====
    public function ppn(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $payments = Payment::with(['customer'])
            ->where('status', 'paid')
            ->where('ppn_amount', '>', 0)
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])
            ->orderByDesc('payment_date')->get();

        $totalPpn = $payments->sum('ppn_amount');
        return view('reports.ppn', compact('user', 'capabilities', 'tenant', 'payments', 'totalPpn', 'month'));
    }

    // ===== Total =====
    public function total(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $pendapatan = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])->sum('paid_amount');
        $ppn = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])->sum('ppn_amount');
        $txnCount = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])->count();
        $pengeluaran = \App\Models\Expense::where('status', 'active')
            ->whereRaw("to_char(expense_date, 'YYYY-MM') = ?", [$month])->sum('amount');
        $setoran = \App\Models\Deposit::where('status', 'active')
            ->whereRaw("to_char(deposit_date, 'YYYY-MM') = ?", [$month])->sum('amount');

        return view('reports.total', compact('user', 'capabilities', 'tenant', 'pendapatan', 'ppn', 'txnCount', 'pengeluaran', 'setoran', 'month'));
    }

    // ===== Arus Kas =====
    public function cashflow(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $pemasukan = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])
            ->selectRaw("payment_date as tanggal, SUM(paid_amount) as total")
            ->groupBy('payment_date')->orderBy('payment_date')->get();

        $pengeluaranHarian = \App\Models\Expense::where('status', 'active')
            ->whereRaw("to_char(expense_date, 'YYYY-MM') = ?", [$month])
            ->selectRaw("expense_date as tanggal, SUM(amount) as total")
            ->groupBy('expense_date')->orderBy('expense_date')->get();

        $totalMasuk = $pemasukan->sum('total');
        $totalKeluar = $pengeluaranHarian->sum('total');

        return view('reports.cashflow', compact('user', 'capabilities', 'tenant', 'pemasukan', 'pengeluaranHarian', 'totalMasuk', 'totalKeluar', 'month'));
    }

    // ===== BATCH C: Fee =====
    public function fee(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $collectors = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])
            ->whereNotNull('collected_by')
            ->selectRaw("collected_by, COUNT(*) as count, SUM(paid_amount) as total")
            ->groupBy('collected_by')
            ->with('collector')
            ->orderByDesc('total')->get();

        return view('reports.fee', compact('user', 'capabilities', 'tenant', 'collectors', 'month'));
    }

    // ===== Setoran =====
    public function setoran(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $deposits = \App\Models\Deposit::with(['sales', 'receiver'])
            ->where('status', 'active')
            ->whereRaw("to_char(deposit_date, 'YYYY-MM') = ?", [$month])
            ->orderByDesc('id')->get();

        $total = $deposits->sum('amount');
        $salesUsers = \App\Models\User::where('is_active', true)->orderBy('name')->get();

        return view('reports.setoran', compact('user', 'capabilities', 'tenant', 'deposits', 'total', 'month', 'salesUsers'));
    }

    public function storeSetoran(Request $request)
    {
        $data = $request->validate([
            'sales_id' => 'required|exists:users,id',
            'amount' => 'required|integer|min:1',
            'method' => 'required|string|max:30',
            'notes' => 'nullable|string|max:255',
        ]);
        $data['tenant_id'] = $request->user()->tenant_id;
        $data['received_by'] = $request->user()->id;
        $data['deposit_date'] = now()->toDateString();
        $data['status'] = 'active';
        \App\Models\Deposit::create($data);
        return back()->with('success', 'Setoran berhasil dicatat.');
    }

    // ===== Mitra =====
    public function mitra(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $salesData = \App\Models\User::where('is_active', true)
            ->withCount(['collectedPayments as collected_count' => function($q) use ($month) {
                $q->where('status', 'paid')->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month]);
            }])
            ->withSum(['collectedPayments as collected_total' => function($q) use ($month) {
                $q->where('status', 'paid')->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month]);
            }], 'paid_amount')
            ->withSum(['deposits as deposit_total' => function($q) use ($month) {
                $q->where('status', 'active')->whereRaw("to_char(deposit_date, 'YYYY-MM') = ?", [$month]);
            }], 'amount')
            ->orderByDesc('collected_total')
            ->get()
            ->filter(fn($u) => $u->collected_count > 0)
            ->values();

        return view('reports.mitra', compact('user', 'capabilities', 'tenant', 'salesData', 'month'));
    }

    // ===== Saldo =====
    public function saldo(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;

        $salesUsers = \App\Models\User::where('is_active', true)
            ->withSum(['collectedPayments as total_collected' => fn($q) => $q->where('status', 'paid')], 'paid_amount')
            ->withSum(['deposits as total_deposited' => fn($q) => $q->where('status', 'active')], 'amount')
            ->orderByDesc('total_collected')
            ->get()
            ->filter(fn($u) => $u->total_collected > 0)
            ->values();

        return view('reports.saldo', compact('user', 'capabilities', 'tenant', 'salesUsers'));
    }
}
