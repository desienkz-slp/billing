@extends('layouts.app')
@section('title', 'Keuangan')
@section('content')
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
    <h1 style="font-size:22px; font-weight:700;">💰 Laporan Keuangan {{ $year }}</h1>
    <form method="GET" style="display:flex; gap:8px; align-items:center;">
        <select name="year" class="input-field" onchange="this.form.submit()">
            @for($y = now()->year; $y >= now()->year - 3; $y--)
                <option value="{{ $y }}" {{ $year == $y ? 'selected' : '' }}>{{ $y }}</option>
            @endfor
        </select>
    </form>
</div>

{{-- Year Summary --}}
<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px,1fr)); gap:16px; margin-bottom:24px;">
    <div class="stat-card"><div class="stat-value" style="color:var(--accent);">Rp {{ number_format($yearTotal['revenue'],0,',','.') }}</div><div class="stat-label">Total Revenue</div></div>
    <div class="stat-card"><div class="stat-value" style="color:var(--warning);">Rp {{ number_format($yearTotal['ppn'],0,',','.') }}</div><div class="stat-label">Total PPN</div></div>
    <div class="stat-card"><div class="stat-value" style="color:var(--success);">Rp {{ number_format($yearTotal['net'],0,',','.') }}</div><div class="stat-label">Pendapatan Bersih</div></div>
    <div class="stat-card"><div class="stat-value">{{ number_format($yearTotal['count']) }}</div><div class="stat-label">Total Transaksi</div></div>
</div>

{{-- Monthly Table --}}
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead>
            <tr><th>Bulan</th><th style="text-align:right;">Revenue</th><th style="text-align:right;">PPN</th><th style="text-align:right;">Diskon</th><th style="text-align:right;">Nett</th><th style="text-align:right;">Transaksi</th></tr>
        </thead>
        <tbody>
        @foreach($monthlyData as $md)
        <tr style="{{ $md['revenue'] > 0 ? '' : 'opacity:0.4;' }}">
            <td><strong>{{ $md['month'] }}</strong></td>
            <td style="text-align:right;">Rp {{ number_format($md['revenue'],0,',','.') }}</td>
            <td style="text-align:right; color:var(--warning);">Rp {{ number_format($md['ppn'],0,',','.') }}</td>
            <td style="text-align:right; color:var(--danger);">Rp {{ number_format($md['discount'],0,',','.') }}</td>
            <td style="text-align:right; font-weight:600; color:var(--success);">Rp {{ number_format($md['net'],0,',','.') }}</td>
            <td style="text-align:right;">{{ $md['count'] }}</td>
        </tr>
        @endforeach
        </tbody>
        <tfoot>
            <tr style="background:var(--accent-bg); font-weight:700;">
                <td>TOTAL {{ $year }}</td>
                <td style="text-align:right;">Rp {{ number_format($yearTotal['revenue'],0,',','.') }}</td>
                <td style="text-align:right;">Rp {{ number_format($yearTotal['ppn'],0,',','.') }}</td>
                <td style="text-align:right;">Rp {{ number_format($yearTotal['discount'],0,',','.') }}</td>
                <td style="text-align:right; color:var(--success);">Rp {{ number_format($yearTotal['net'],0,',','.') }}</td>
                <td style="text-align:right;">{{ number_format($yearTotal['count']) }}</td>
            </tr>
        </tfoot>
    </table>
</div>
@endsection
@push('styles')
<style>
.stat-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:20px 24px;box-shadow:var(--shadow-sm)}
.stat-value{font-size:20px;font-weight:700;margin-bottom:2px}.stat-label{font-size:13px;color:var(--text-muted)}
.input-field{padding:8px 12px;background:var(--bg-card);border:1px solid var(--border);border-radius:8px;color:var(--text-primary);font-size:14px;font-family:inherit;outline:none}
.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow-sm)}
.data-table{width:100%;border-collapse:collapse;font-size:14px}
.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}
.data-table td{padding:12px 16px;border-bottom:1px solid var(--border)}
.data-table tbody tr:hover{background:var(--accent-bg)}
.data-table tfoot td{padding:14px 16px;border-top:2px solid var(--border)}
</style>
@endpush
