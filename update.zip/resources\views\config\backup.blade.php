@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
Backup & Restore
@endsection
@section('content')
<div class="cfg-grid-2">
    <div class="cfg-card">
        <div class="cfg-card-title">💾 Backup Database</div>
        <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:16px">Export seluruh data billing ke file SQL. File backup akan di-download ke perangkat Anda.</p>
        <button class="cfg-btn cfg-btn-primary" onclick="alert('Fitur backup akan segera tersedia.')">📥 Download Backup</button>
    </div>
    <div class="cfg-card">
        <div class="cfg-card-title">📤 Restore Database</div>
        <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:16px">Import data dari file backup SQL. <strong style="color:#f87171">⚠ Data saat ini akan ditimpa!</strong></p>
        <div style="margin-bottom:12px">
            <div class="cfg-label">File Backup (.sql)</div>
            <input type="file" accept=".sql" class="cfg-input" style="padding:6px">
        </div>
        <button class="cfg-btn cfg-btn-danger" onclick="alert('Fitur restore akan segera tersedia.')">⚠ Restore Database</button>
    </div>
</div>
<div class="cfg-card">
    <div class="cfg-card-title">ℹ️ Informasi</div>
    <p style="font-size:.82rem;color:var(--text-secondary);line-height:1.6">
        Backup mencakup: pelanggan, pembayaran, invoice, konfigurasi, user, role, area, paket, ODP, dan semua data billing.<br>
        Disarankan untuk melakukan backup secara rutin, terutama sebelum melakukan perubahan besar pada sistem.
    </p>
</div>
@endsection
