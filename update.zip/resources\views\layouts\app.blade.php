<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') — LadaPala-Bill</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --sidebar-width: 260px;
            --header-height: 64px;
            --bg-body: #f8fafc;
            --bg-sidebar: #0f172a;
            --bg-header: #ffffff;
            --bg-card: #ffffff;
            --border: #e2e8f0;
            --text-primary: #0f172a;
            --text-secondary: #475569;
            --text-muted: #94a3b8;
            --text-sidebar: #cbd5e1;
            --text-sidebar-active: #ffffff;
            --accent: #6366f1;
            --accent-light: #818cf8;
            --accent-bg: rgba(99, 102, 241, 0.08);
            --success: #22c55e;
            --warning: #f59e0b;
            --danger: #ef4444;
            --gradient: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1);
            --radius: 12px;
        }

        /* Dark mode */
        [data-theme="dark"] {
            --bg-body: #0f172a;
            --bg-sidebar: #020617;
            --bg-header: #1e293b;
            --bg-card: #1e293b;
            --border: #334155;
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.2);
            --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.3);
        }

        body {
            font-family: 'Inter', -apple-system, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            display: flex;
            min-height: 100vh;
        }

        /* ==================== SIDEBAR ==================== */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--bg-sidebar);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            z-index: 50;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }

        .sidebar-brand {
            padding: 20px 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }

        .sidebar-brand .brand-icon {
            width: 36px; height: 36px;
            background: var(--gradient);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .sidebar-brand .brand-icon svg { width: 18px; height: 18px; fill: white; }

        .sidebar-brand .brand-text {
            font-size: 16px;
            font-weight: 700;
            color: #fff;
            letter-spacing: -0.3px;
        }

        .sidebar-brand .brand-version {
            font-size: 10px;
            color: var(--text-muted);
            font-weight: 400;
        }

        .sidebar-nav {
            flex: 1;
            padding: 16px 12px;
        }

        .nav-section {
            margin-bottom: 20px;
        }

        .nav-section-title {
            font-size: 11px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 0 12px;
            margin-bottom: 8px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: 10px;
            color: var(--text-sidebar);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.15s;
            margin-bottom: 2px;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.06);
            color: #fff;
        }

        .nav-item.active {
            background: var(--accent);
            color: var(--text-sidebar-active);
        }

        .nav-item svg {
            width: 20px; height: 20px;
            flex-shrink: 0;
            opacity: 0.7;
        }

        .nav-item.active svg { opacity: 1; }

        .sidebar-footer {
            padding: 16px;
            border-top: 1px solid rgba(255,255,255,0.06);
        }

        .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px;
            border-radius: 10px;
            background: rgba(255,255,255,0.04);
        }

        .user-avatar {
            width: 36px; height: 36px;
            background: var(--gradient);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 14px;
            flex-shrink: 0;
        }

        .user-info { flex: 1; min-width: 0; }
        .user-name { font-size: 13px; font-weight: 600; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .user-role { font-size: 11px; color: var(--text-muted); }

        /* ==================== MAIN ==================== */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            min-height: 100vh;
        }

        .header {
            height: var(--header-height);
            background: var(--bg-header);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
            position: sticky;
            top: 0;
            z-index: 40;
            box-shadow: var(--shadow-sm);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-left h2 {
            font-size: 18px;
            font-weight: 600;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .btn-theme-toggle {
            width: 36px; height: 36px;
            border: 1px solid var(--border);
            border-radius: 10px;
            background: var(--bg-card);
            color: var(--text-secondary);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }

        .btn-theme-toggle:hover {
            border-color: var(--accent);
            color: var(--accent);
        }

        .btn-logout {
            padding: 8px 16px;
            background: none;
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.2s;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .btn-logout:hover {
            border-color: var(--danger);
            color: var(--danger);
        }

        .page-content {
            padding: 28px;
        }

        /* License Warning Banner */
        .license-banner {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            color: white;
            padding: 10px 28px;
            font-size: 13px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .license-banner.expired {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        }

        /* Welcome Card */
        .welcome-card {
            background: var(--gradient);
            border-radius: var(--radius);
            padding: 32px;
            color: white;
            margin-bottom: 28px;
            position: relative;
            overflow: hidden;
        }

        .welcome-card::after {
            content: '';
            position: absolute;
            right: -20px; top: -20px;
            width: 200px; height: 200px;
            background: rgba(255,255,255,0.05);
            border-radius: 50%;
        }

        .welcome-card h1 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .welcome-card p {
            opacity: 0.8;
            font-size: 14px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
        }
    </style>
    @stack('styles')
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <div class="brand-icon">
                <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
            </div>
            <div>
                <div class="brand-text">LadaPala-Bill</div>
                <div class="brand-version">v2.0 — {{ $tenant->name ?? 'ISP' }}</div>
            </div>
        </div>

        <nav class="sidebar-nav">
            @php $user = auth()->user(); $role = $user?->role; $isAdmin = $user?->is_system_admin; @endphp

            <div class="nav-section">
                <div class="nav-section-title">Utama</div>
                <a href="{{ route('dashboard') }}" class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                    Dashboard
                </a>

                @if($isAdmin || $role?->can_view_all_customers)
                <a href="{{ route('customers.index') }}" class="nav-item {{ request()->routeIs('customers.*') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    Pelanggan
                </a>
                @endif


                @if($isAdmin || $role?->can_manage_cuti)
                <a href="{{ route('cuti.index') }}" class="nav-item {{ request()->routeIs('cuti.*') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
                    Pelanggan Cuti
                </a>
                @endif
                @if($isAdmin || $role?->can_manage_isolir)
                <a href="{{ route('isolir.index') }}" class="nav-item {{ request()->routeIs('isolir.*') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                    Isolir
                </a>
                @endif
            </div>



            @if($isAdmin || $role?->can_view_reports || $role?->can_view_finance)
            <div class="nav-section">
                <div class="nav-section-title">Laporan</div>
                @if($isAdmin || $role?->can_view_reports)
                <a href="{{ route('reports.detail-pendapatan') }}" class="nav-item {{ request()->routeIs('reports.detail-pendapatan') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    Detail Pendapatan
                </a>
                @endif
                @if($isAdmin || $role?->can_view_finance)
                <a href="{{ route('expenses.index') }}" class="nav-item {{ request()->routeIs('expenses.*') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    Pengeluaran Operasional
                </a>
                <a href="{{ route('reports.ppn') }}" class="nav-item {{ request()->routeIs('reports.ppn') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                    PPN
                </a>
                <a href="{{ route('reports.total') }}" class="nav-item {{ request()->routeIs('reports.total') ? 'active' : '' }}">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
                    Total/Rekapitulasi
                </a>
                <a href="{{ route('statistics.index') }}" class="nav-item {{ request()->routeIs('statistics.*') ? 'active' : '' }}">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                    Statistik Bisnis
                </a>
                @endif
                @if($isAdmin || $role?->can_view_finance)
                <a href="{{ route('reports.cashflow') }}" class="nav-item {{ request()->routeIs('reports.cashflow') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                    Arus Kas
                </a>
                @endif
            </div>
            @endif

            @if($isAdmin || $role?->can_view_finance || $role?->can_manage_deposits)
            <div class="nav-section">
                <div class="nav-section-title">Laporan Sales</div>
                @if($isAdmin || $role?->can_view_finance)
                <a href="{{ route('fee_withdrawals.index') }}" class="nav-item {{ request()->routeIs('fee_withdrawals.*') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M15 9.5a3 3 0 0 0-6 0c0 2 6 3 6 6a3 3 0 0 1-6 0"/></svg>
                    Fee & Pencairan
                </a>
                @endif
                @if($isAdmin || $role?->can_manage_deposits)
                <a href="{{ route('reports.setoran') }}" class="nav-item {{ request()->routeIs('reports.setoran') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 7V5a4 4 0 0 0-8 0v2"/></svg>
                    Setoran
                </a>
                @endif
                @if($isAdmin || $role?->can_view_finance)
                <a href="{{ route('reports.mitra') }}" class="nav-item {{ request()->routeIs('reports.mitra') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    Mitra
                </a>
                <a href="{{ route('reports.saldo') }}" class="nav-item {{ request()->routeIs('reports.saldo') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
                    Saldo
                </a>
                @endif
            </div>
            @endif

            @if($isAdmin || $role?->can_manage_packages || $role?->can_manage_areas || $role?->can_manage_odp)
            <div class="nav-section">
                <div class="nav-section-title">Master</div>
                @if($isAdmin || $role?->can_manage_packages)
                <a href="{{ route('settings.packages') }}" class="nav-item {{ request()->routeIs('settings.packages*') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 7V5a4 4 0 0 0-8 0v2"/></svg>
                    Master Paket
                </a>
                @endif
                @if($isAdmin || $role?->can_manage_areas)
                <a href="{{ route('settings.areas') }}" class="nav-item {{ request()->routeIs('settings.areas*') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    Master Area
                </a>
                @endif
                @if($isAdmin || $role?->can_manage_odp)
                <a href="{{ route('settings.odps') }}" class="nav-item {{ request()->routeIs('settings.odps*') ? 'active' : '' }}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="3"/><line x1="12" y1="8" x2="12" y2="16"/><circle cx="6" cy="19" r="3"/><circle cx="18" cy="19" r="3"/><line x1="12" y1="16" x2="6" y2="16"/><line x1="12" y1="16" x2="18" y2="16"/></svg>
                    Master ODP
                </a>
                @endif
            </div>
            @endif


        </nav>

        <div class="sidebar-footer">
            <a href="{{ route('app-gateway') }}" style="display:flex;align-items:center;gap:8px;padding:8px 16px;margin-bottom:8px;font-size:13px;color:var(--text-sidebar);text-decoration:none;border-radius:8px;transition:all .2s;border:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.03);" onmouseover="this.style.background='rgba(255,255,255,.08)'" onmouseout="this.style.background='rgba(255,255,255,.03)'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Pilih Modul
            </a>
            <div class="user-card">
                <div class="user-avatar">{{ strtoupper(substr($user->name ?? 'U', 0, 1)) }}</div>
                <div class="user-info">
                    <div class="user-name">{{ $user->name }}</div>
                    <div class="user-role">{{ $user->role->name ?? 'User' }}</div>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
        @if(isset($licenseWarning))
            <div class="license-banner {{ isset($licenseExpired) ? 'expired' : '' }}">
                ⚠️ {{ $licenseWarning }}
            </div>
        @endif

        <header class="header">
            <div class="header-left">
                <h2>@yield('title', 'Dashboard')</h2>
            </div>
            <div class="header-right">
                <button class="btn-theme-toggle" onclick="toggleTheme()" title="Toggle dark mode">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                    </svg>
                </button>
                <form action="{{ route('logout') }}" method="POST" style="display:inline">
                    @csrf
                    <button type="submit" class="btn-logout">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                        Logout
                    </button>
                </form>
            </div>
        </header>

        <main class="page-content">
            @yield('content')
        </main>
    </div>

    <script>
        // Theme toggle
        function toggleTheme() {
            const html = document.documentElement;
            const current = html.getAttribute('data-theme');
            const next = current === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', next);
            localStorage.setItem('theme', next);
        }

        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
    </script>
    @stack('scripts')
</body>
</html>
