@extends('layouts.app')
@section('title', 'Saldo')
@section('content')
<div style="margin-bottom:20px;"><h1 style="font-size:22px; font-weight:700;">💳 Laporan Saldo</h1><p style="color:var(--text-muted); font-size:14px;">Saldo keseluruhan per user</p></div>
<div class="card" style="padding:0; overflow:hidden;">
    <table class="data-table">
        <thead><tr><th>#</th><th>Nama</th><th style="text-align:right">Total Koleksi</th><th style="text-align:right">Total Setor</th><th style="text-align:right">Saldo (Belum Setor)</th></tr></thead>
        <tbody>
        @forelse($salesUsers as $i => $s)
        @php $saldo = ($s->total_collected ?? 0) - ($s->total_deposited ?? 0); @endphp
        <tr><td>{{ $i+1 }}</td><td><strong>{{ $s->name }}</strong><br><span style="font-size:11px;color:var(--text-muted)">{{ $s->role?->name ?? '' }}</span></td><td style="text-align:right;color:#86efac">{{ number_format($s->total_collected ?? 0) }}</td><td style="text-align:right;color:#4ade80">{{ number_format($s->total_deposited ?? 0) }}</td><td style="text-align:right;font-weight:700;color:{{ $saldo > 0 ? '#fcd34d' : '#4ade80' }}">{{ number_format($saldo) }}</td></tr>
        @empty
        <tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-muted);">Tidak ada data.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
@endsection
@push('styles')<style>.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}.data-table{width:100%;border-collapse:collapse;font-size:14px}.data-table th{text-align:left;padding:12px 16px;color:var(--text-muted);font-weight:600;font-size:12px;text-transform:uppercase;border-bottom:2px solid var(--border);background:var(--bg-body)}.data-table td{padding:10px 16px;border-bottom:1px solid var(--border)}.data-table tbody tr:hover{background:var(--accent-bg)}</style>@endpush
