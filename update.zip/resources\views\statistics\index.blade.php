@extends('layouts.app')

@section('title', 'Statistik Bisnis')

@push('styles')
<link rel="stylesheet" href="{{ asset('css/statistik.css') }}?v={{ time() }}">
@endpush

@push('scripts')
<script src="{{ asset('js/chart.umd.min.js') }}"></script>
@endpush

@section('content')

<div class="bill-main-card">
  <div class="bill-main-header">
    <div class="bill-main-title">
      <h2><i class="bi bi-graph-up-arrow" style="color:var(--shell-accent);margin-right:.35rem;"></i>Statistik Bisnis</h2>
    </div>
  </div>

  <!-- Filter -->
  <div class="stat-filter-bar" id="statFilterBar">
    <div class="stat-filter-group">
      <span class="stat-filter-label">Periode</span>
      <input type="month" id="statBulan" value="{{ $bulan ?? date('Y-m') }}">
    </div>
    <button type="button" class="stat-filter-btn" onclick="statReload()">
      <i class="bi bi-funnel"></i> Tampilkan
    </button>
    <button type="button" class="stat-filter-btn" id="btnToggleHide" onclick="toggleHideMonth()" style="background:linear-gradient(135deg,#ef4444,#dc2626);" title="Sembunyikan/tampilkan data bulan ini">
      <i class="bi bi-eye-slash"></i> <span id="btnToggleHideLabel">Sembunyikan</span>
    </button>
    <div class="stat-hidden-months-wrap" style="position:relative;">
      <button type="button" class="stat-filter-btn" onclick="toggleHiddenList()" style="background:linear-gradient(135deg,#f59e0b,#d97706);">
        <i class="bi bi-calendar-x"></i> Tersembunyi <span id="hiddenCountBadge" class="stat-hidden-badge" style="display:none;">0</span>
      </button>
      <div class="stat-hidden-dropdown" id="hiddenMonthsDropdown" style="display:none;">
        <div class="stat-hidden-dropdown-title"><i class="bi bi-eye-slash"></i> Bulan Tersembunyi</div>
        <div id="hiddenMonthsList" class="stat-hidden-list"><div style="color:#64748b;font-size:.78rem;padding:.5rem;">Tidak ada</div></div>
      </div>
    </div>
  </div>

  <!-- Tabs -->
  <div class="stat-tabs" id="statTabs">
    <button class="stat-tab active" data-tab="payment" onclick="statSwitchTab('payment',this)">
      <i class="bi bi-cash-coin"></i>
      <span class="tab-label-full">Pembayaran</span>
      <span class="tab-label-short">Bayar</span>
    </button>
    <button class="stat-tab" data-tab="growth" onclick="statSwitchTab('growth',this)">
      <i class="bi bi-person-plus"></i>
      <span class="tab-label-full">Pertumbuhan</span>
      <span class="tab-label-short">Growth</span>
    </button>
    <button class="stat-tab" data-tab="churn" onclick="statSwitchTab('churn',this)">
      <i class="bi bi-person-dash"></i>
      <span class="tab-label-full">Churn</span>
      <span class="tab-label-short">Churn</span>
    </button>
    <button class="stat-tab" data-tab="management" onclick="statSwitchTab('management',this)">
      <i class="bi bi-briefcase"></i>
      <span class="tab-label-full">Manajemen</span>
      <span class="tab-label-short">Mgmt</span>
    </button>
  </div>

  <!-- ═══════════════════════════════════════════════════════════ -->
  <!-- TAB 1: PEMBAYARAN                                         -->
  <!-- ═══════════════════════════════════════════════════════════ -->
  <div class="stat-panel active" id="panelPayment">
    <div class="stat-kpi-grid" id="kpiPayment">
      <div class="stat-kpi kpi-green"><div class="stat-kpi-icon"><i class="bi bi-calendar-day"></i></div><div class="stat-kpi-label">Hari Ini</div><div class="stat-kpi-value" id="kpPayToday">-</div><div class="stat-kpi-sub">{{ date('d M Y') }}</div></div>
      <div class="stat-kpi kpi-blue"><div class="stat-kpi-icon"><i class="bi bi-calendar-month"></i></div><div class="stat-kpi-label">Bulan Ini</div><div class="stat-kpi-value" id="kpPayMonth">-</div><div class="stat-kpi-sub" id="kpPayGrowth"></div></div>
      <div class="stat-kpi kpi-purple"><div class="stat-kpi-icon"><i class="bi bi-calendar-range"></i></div><div class="stat-kpi-label">Pendapatan Tahunan</div><div class="stat-kpi-value" id="kpPayYearly">-</div><div class="stat-kpi-sub" id="kpPayYearSub"></div></div>
      <div class="stat-kpi kpi-amber"><div class="stat-kpi-icon"><i class="bi bi-exclamation-triangle"></i></div><div class="stat-kpi-label">Belum Bayar</div><div class="stat-kpi-value" id="kpUnpaid">-</div><div class="stat-kpi-sub" id="kpUnpaidSub"></div></div>
      <div class="stat-kpi kpi-red"><div class="stat-kpi-icon"><i class="bi bi-clock-history"></i></div><div class="stat-kpi-label">Jatuh Tempo</div><div class="stat-kpi-value" id="kpOverdue">-</div><div class="stat-kpi-sub">Invoice expired</div></div>
      <div class="stat-kpi kpi-cyan"><div class="stat-kpi-icon"><i class="bi bi-check2-circle"></i></div><div class="stat-kpi-label">Success Rate</div><div class="stat-kpi-value" id="kpSuccessRate">-</div><div class="stat-kpi-sub" id="kpSuccessSub"></div></div>
      <div class="stat-kpi kpi-pink"><div class="stat-kpi-icon"><i class="bi bi-person-check"></i></div><div class="stat-kpi-label">ARPU</div><div class="stat-kpi-value" id="kpArpu">-</div><div class="stat-kpi-sub">Per pelanggan aktif</div></div>
      <div class="stat-kpi kpi-teal"><div class="stat-kpi-icon"><i class="bi bi-receipt"></i></div><div class="stat-kpi-label">Transaksi</div><div class="stat-kpi-value" id="kpTxn">-</div><div class="stat-kpi-sub">Bulan ini</div></div>
    </div>

    <div class="stat-chart-row">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-pie-chart"></i> Metode Pembayaran</div>
        <div class="stat-chart-wrap" style="max-height:280px;display:flex;align-items:center;justify-content:center;">
          <canvas id="chartPayMethods"></canvas>
        </div>
      </div>
      <div class="stat-insight-card" id="insightPayment">
        <div class="stat-insight-title"><i class="bi bi-lightbulb"></i> Insight Pembayaran</div>
        <ul class="stat-insight-list" id="insightPayList">
          <li>Memuat data...</li>
        </ul>
      </div>
    </div>

    <div class="stat-chart-row full">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-graph-up"></i> Pendapatan Harian (30 Hari Terakhir)</div>
        <div class="stat-chart-wrap"><canvas id="chartPayDaily"></canvas></div>
      </div>
    </div>

    <div class="stat-chart-row full">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-bar-chart"></i> Pembayaran Per Bulan (12 Bulan)</div>
        <div class="stat-chart-wrap"><canvas id="chartPayMonthly"></canvas></div>
      </div>
    </div>

    <div class="stat-chart-row full">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-grid-3x3"></i> Heatmap Pembayaran (Hari × Jam)</div>
        <div class="stat-heatmap-wrap" id="heatmapWrap"></div>
        <div class="stat-heatmap-legend">
          <span>Sedikit</span>
          <div class="stat-heatmap-legend-cell stat-hm-0"></div>
          <div class="stat-heatmap-legend-cell stat-hm-1"></div>
          <div class="stat-heatmap-legend-cell stat-hm-2"></div>
          <div class="stat-heatmap-legend-cell stat-hm-3"></div>
          <div class="stat-heatmap-legend-cell stat-hm-4"></div>
          <div class="stat-heatmap-legend-cell stat-hm-5"></div>
          <span>Banyak</span>
        </div>
      </div>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════════════ -->
  <!-- TAB 2: PERTUMBUHAN PELANGGAN                              -->
  <!-- ═══════════════════════════════════════════════════════════ -->
  <div class="stat-panel" id="panelGrowth">
    <div class="stat-kpi-grid" id="kpiGrowth">
      <div class="stat-kpi kpi-blue"><div class="stat-kpi-icon"><i class="bi bi-people"></i></div><div class="stat-kpi-label">Pelanggan Aktif</div><div class="stat-kpi-value" id="kgActive">-</div><div class="stat-kpi-sub">Total enabled</div></div>
      <div class="stat-kpi kpi-green"><div class="stat-kpi-icon"><i class="bi bi-person-plus-fill"></i></div><div class="stat-kpi-label">Pelanggan Baru</div><div class="stat-kpi-value" id="kgNew">-</div><div class="stat-kpi-sub" id="kgNewSub"></div></div>
      <div class="stat-kpi kpi-purple"><div class="stat-kpi-icon"><i class="bi bi-graph-up-arrow"></i></div><div class="stat-kpi-label">Growth Rate</div><div class="stat-kpi-value" id="kgRate">-</div><div class="stat-kpi-sub">Bulan ini</div></div>
      <div class="stat-kpi kpi-cyan"><div class="stat-kpi-icon"><i class="bi bi-ethernet"></i></div><div class="stat-kpi-label">PPPoE Aktif</div><div class="stat-kpi-value" id="kgPppoe">-</div><div class="stat-kpi-sub">Terhubung</div></div>
      <div class="stat-kpi kpi-amber"><div class="stat-kpi-icon"><i class="bi bi-pause-circle"></i></div><div class="stat-kpi-label">Cuti</div><div class="stat-kpi-value" id="kgCuti">-</div><div class="stat-kpi-sub">Pelanggan cuti</div></div>
      <div class="stat-kpi kpi-red"><div class="stat-kpi-icon"><i class="bi bi-slash-circle"></i></div><div class="stat-kpi-label">Isolir</div><div class="stat-kpi-value" id="kgSuspend">-</div><div class="stat-kpi-sub">Saat ini</div></div>
    </div>

    <div class="stat-chart-row full">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-graph-up"></i> Pertumbuhan Pelanggan (12 Bulan)</div>
        <div class="stat-chart-wrap"><canvas id="chartCustGrowth"></canvas></div>
      </div>
    </div>

    <div class="stat-chart-row full">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-geo-alt"></i> Pelanggan Per Wilayah</div>
        <div class="stat-chart-wrap" id="wrapCustArea"><canvas id="chartCustArea"></canvas></div>
      </div>
    </div>

    <div class="stat-chart-row full">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-layers"></i> Total Pelanggan Kumulatif</div>
        <div class="stat-chart-wrap"><canvas id="chartCustCumulative"></canvas></div>
      </div>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════════════ -->
  <!-- TAB 3: CHURN ANALYSIS                                     -->
  <!-- ═══════════════════════════════════════════════════════════ -->
  <div class="stat-panel" id="panelChurn">
    <div class="stat-kpi-grid" id="kpiChurn">
      <div class="stat-kpi kpi-red"><div class="stat-kpi-icon"><i class="bi bi-percent"></i></div><div class="stat-kpi-label">Churn Rate</div><div class="stat-kpi-value" id="kcRate">-</div><div class="stat-kpi-sub">Bulan ini</div></div>
      <div class="stat-kpi kpi-pink"><div class="stat-kpi-icon"><i class="bi bi-hourglass-split"></i></div><div class="stat-kpi-label">Suspend &gt;30 Hari</div><div class="stat-kpi-value" id="kcSuspLong">-</div><div class="stat-kpi-sub">Risiko churn tinggi</div></div>
      <div class="stat-kpi kpi-green"><div class="stat-kpi-icon"><i class="bi bi-arrow-repeat"></i></div><div class="stat-kpi-label">Recovery</div><div class="stat-kpi-value" id="kcRecovery">-</div><div class="stat-kpi-sub">Kembali aktif</div></div>
      <div class="stat-kpi kpi-blue"><div class="stat-kpi-icon"><i class="bi bi-calendar-check"></i></div><div class="stat-kpi-label">Avg. Umur Pelanggan</div><div class="stat-kpi-value" id="kcAvgLife">-</div><div class="stat-kpi-sub">Bulan berlangganan</div></div>
      <div class="stat-kpi kpi-cyan"><div class="stat-kpi-icon"><i class="bi bi-slash-circle"></i></div><div class="stat-kpi-label">Total Isolir</div><div class="stat-kpi-value" id="kcIsolir">-</div><div class="stat-kpi-sub">Saat ini</div></div>
      <div class="stat-kpi kpi-purple"><div class="stat-kpi-icon"><i class="bi bi-pause-circle"></i></div><div class="stat-kpi-label">Total Cuti</div><div class="stat-kpi-value" id="kcCuti">-</div><div class="stat-kpi-sub">Saat ini</div></div>
      <div class="stat-kpi kpi-teal"><div class="stat-kpi-icon"><i class="bi bi-shield-check"></i></div><div class="stat-kpi-label">Retention</div><div class="stat-kpi-value" id="kcRetention">-</div><div class="stat-kpi-sub">Tingkat retensi</div></div>
    </div>

    <div class="stat-chart-row full">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-graph-down"></i> Churn Trend Bulanan (12 Bulan)</div>
        <div class="stat-chart-wrap"><canvas id="chartChurnTrend"></canvas></div>
      </div>
    </div>

    <div class="stat-chart-row">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-pie-chart"></i> Status Pelanggan</div>
        <div class="stat-chart-wrap" style="max-height:280px;display:flex;align-items:center;justify-content:center;">
          <canvas id="chartChurnDonut"></canvas>
        </div>
      </div>
      <div class="stat-insight-card" id="insightChurn">
        <div class="stat-insight-title"><i class="bi bi-lightbulb"></i> Insight Churn</div>
        <ul class="stat-insight-list" id="insightChurnList">
          <li>Memuat data...</li>
        </ul>
      </div>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════════════ -->
  <!-- TAB 4: ANALISIS MANAJEMEN                                 -->
  <!-- ═══════════════════════════════════════════════════════════ -->
  <div class="stat-panel" id="panelManagement">
    <!-- Scorecards -->
    <div class="stat-scorecard-grid" id="mgmtScorecards" style="grid-template-columns: repeat(6, 1fr);">
      <div class="stat-scorecard">
        <div class="stat-scorecard-label">MRR (Potensi)</div>
        <div class="stat-scorecard-value" id="kmMrr">-</div>
        <div class="stat-scorecard-sub">Pendapatan berulang bulanan</div>
      </div>
      <div class="stat-scorecard">
        <div class="stat-scorecard-label">Pendapatan Kotor</div>
        <div class="stat-scorecard-value" id="kmKotor" style="color:#38bdf8;">-</div>
        <div class="stat-scorecard-sub">Total tagihan masuk bulan ini</div>
      </div>
      <div class="stat-scorecard">
        <div class="stat-scorecard-label">Potongan & Pengeluaran</div>
        <div class="stat-scorecard-value" id="kmPengeluaran" style="color:#f87171;">-</div>
        <div class="stat-scorecard-sub" id="kmPengeluaranSub">Fee + Beban Operasional</div>
      </div>
      <div class="stat-scorecard">
        <div class="stat-scorecard-label">Pendapatan Bersih (Net)</div>
        <div class="stat-scorecard-value" id="kmNetRev" style="color:#4ade80;">-</div>
        <div class="stat-scorecard-sub">Uang bersih terima perusahaan</div>
      </div>
      <div class="stat-scorecard">
        <div class="stat-scorecard-label">Setoran Deviden</div>
        <div class="stat-scorecard-value" id="kmDeviden" style="color:#d946ef;">-</div>
        <div class="stat-scorecard-sub">Distribusi keuntungan</div>
      </div>
      <div class="stat-scorecard">
        <div class="stat-scorecard-label">Kas Ditahan</div>
        <div class="stat-scorecard-value" id="kmKasDitahan" style="color:#14b8a6;">-</div>
        <div class="stat-scorecard-sub">Sisa kas (Net - Deviden)</div>
      </div>
    </div>
    
    <!-- Net Revenue Widget -->
    <div class="stat-netrev-widget" id="netRevWidget" style="display:none;">
      <div class="netrev-main">
        <h2>Pendapatan Bersih (Net)</h2>
        <div class="netrev-amount" id="nrWidgetAmount">-</div>
        <div class="netrev-subtitle">Setelah pemotongan fee & operasional</div>
        <div class="netrev-margin" id="nrWidgetMargin">Margin: -%</div>
      </div>
      <div class="netrev-breakdown">
        <div class="netrev-bd-item">
          <div class="netrev-bd-label"><i class="bi bi-wallet2"></i> Pendapatan Kotor</div>
          <div class="netrev-bd-val" id="nrWidgetKotor">-</div>
        </div>
        <div class="netrev-bd-item">
          <div class="netrev-bd-label sales"><i class="bi bi-person-badge"></i> Fee Sales/Reseller</div>
          <div class="netrev-bd-val minus" id="nrWidgetFeeSales">-</div>
        </div>
        <div class="netrev-bd-item">
          <div class="netrev-bd-label kolektor"><i class="bi bi-person-check"></i> Fee Kolektor</div>
          <div class="netrev-bd-val minus" id="nrWidgetFeeKolektor">-</div>
        </div>
        <div class="netrev-bd-item">
          <div class="netrev-bd-label" style="color:#f87171;"><i class="bi bi-receipt-cutoff"></i> Pajak (PPN + BHP USO Admin ISP)</div>
          <div class="netrev-bd-val minus" id="nrWidgetPpn">-</div>
        </div>
        <div class="netrev-bd-item">
          <div class="netrev-bd-label"><i class="bi bi-tools"></i> Operasional</div>
          <div class="netrev-bd-val minus" id="nrWidgetOps">-</div>
        </div>
      </div>
      <div class="netrev-chart">
        <canvas id="chartNetRevSpark"></canvas>
      </div>
    </div>

    <div class="stat-chart-row full" style="margin-bottom: 1.5rem;">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-bar-chart-steps"></i> Trend Pendapatan vs Pengeluaran & Cashflow (12 Bulan)</div>
        <div class="stat-chart-wrap"><canvas id="chartRevExpense"></canvas></div>
      </div>
    </div>

    <div class="stat-kpi-grid" id="kpiMgmt">
      <div class="stat-kpi kpi-green"><div class="stat-kpi-icon"><i class="bi bi-bullseye"></i></div><div class="stat-kpi-label">Collection Efficiency</div><div class="stat-kpi-value" id="kmCollEff">-</div><div class="stat-kpi-sub">Terkumpul vs MRR</div></div>
      <div class="stat-kpi kpi-blue"><div class="stat-kpi-icon"><i class="bi bi-clock"></i></div><div class="stat-kpi-label">Avg Days to Pay</div><div class="stat-kpi-value" id="kmAvgDays">-</div><div class="stat-kpi-sub">Rata-rata hari bayar</div></div>
      <div class="stat-kpi kpi-amber"><div class="stat-kpi-icon"><i class="bi bi-exclamation-diamond"></i></div><div class="stat-kpi-label">Outstanding</div><div class="stat-kpi-value" id="kmOutstanding">-</div><div class="stat-kpi-sub">Total piutang</div></div>
      <div class="stat-kpi kpi-purple"><div class="stat-kpi-icon"><i class="bi bi-heart-pulse"></i></div><div class="stat-kpi-label">Customer LTV</div><div class="stat-kpi-value" id="kmLtv">-</div><div class="stat-kpi-sub" id="kmLtvSub">ARPU × Avg Lifetime</div></div>
    </div>

    <!-- Collection Efficiency Gauge + Aging Analysis -->
    <div class="stat-chart-row">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-speedometer2"></i> Collection Efficiency</div>
        <div style="display:flex;align-items:center;justify-content:center;padding:1rem 0;">
          <div class="stat-gauge-ring" id="gaugeCollEff">
            <svg viewBox="0 0 120 120">
              <circle class="stat-gauge-bg" cx="60" cy="60" r="52"></circle>
              <circle class="stat-gauge-fg" cx="60" cy="60" r="52" stroke="#34d399" stroke-dasharray="326.73" stroke-dashoffset="326.73" id="gaugeFg"></circle>
            </svg>
            <div class="stat-gauge-text" id="gaugeText">0%</div>
          </div>
        </div>
        <div id="mgmtProgressBars">
          <div class="stat-progress-wrap">
            <div class="stat-progress-header"><span class="stat-progress-label">Terkumpul</span><span class="stat-progress-value" id="pbCollected">-</span></div>
            <div class="stat-progress-bar"><div class="stat-progress-fill fill-green" id="pbCollectedBar" style="width:0%"></div></div>
          </div>
          <div class="stat-progress-wrap">
            <div class="stat-progress-header"><span class="stat-progress-label">Pengeluaran</span><span class="stat-progress-value" id="pbPengeluaran">-</span></div>
            <div class="stat-progress-bar"><div class="stat-progress-fill fill-red" id="pbPengeluaranBar" style="width:0%"></div></div>
          </div>
        </div>
      </div>
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-table"></i> Aging Analysis Piutang</div>
        <div style="overflow-x:auto;">
          <table class="stat-aging-table" id="agingTable">
            <thead><tr><th>Umur Piutang</th><th>Pelanggan</th><th>Nominal</th></tr></thead>
            <tbody id="agingBody"><tr><td colspan="3" style="text-align:center;color:#64748b;">Memuat...</td></tr></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Revenue by Area & Package -->
    <div class="stat-chart-row">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-geo-alt-fill"></i> Revenue Per Area</div>
        <div id="rankAreaWrap">
          <ul class="stat-rank-list" id="rankAreaList"><li class="stat-rank-item"><span class="stat-rank-name" style="color:#64748b">Memuat...</span></li></ul>
        </div>
      </div>
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-box-seam"></i> Revenue Per Paket</div>
        <div id="rankPaketWrap">
          <ul class="stat-rank-list" id="rankPaketList"><li class="stat-rank-item"><span class="stat-rank-name" style="color:#64748b">Memuat...</span></li></ul>
        </div>
      </div>
    </div>

    <!-- Collection Trend -->
    <div class="stat-chart-row full">
      <div class="stat-chart-card">
        <div class="stat-chart-title"><i class="bi bi-graph-up"></i> Trend Collection Efficiency (12 Bulan)</div>
        <div class="stat-chart-wrap"><canvas id="chartCollTrend"></canvas></div>
      </div>
    </div>

    <!-- Management Insights -->
    <div class="stat-insight-grid">
      <div class="stat-insight-card" id="insightMgmt">
        <div class="stat-insight-title"><i class="bi bi-briefcase"></i> Insight Manajemen</div>
        <ul class="stat-insight-list" id="insightMgmtList">
          <li>Memuat data...</li>
        </ul>
      </div>
      <div class="stat-insight-card" id="insightAction">
        <div class="stat-insight-title"><i class="bi bi-lightning-charge"></i> Rekomendasi Aksi</div>
        <ul class="stat-insight-list" id="insightActionList">
          <li>Memuat data...</li>
        </ul>
      </div>
    </div>
  </div>
</div>

@push('scripts')
<script>
function initStatistik(){
  'use strict';

  // ── Globals ──────────────────────────────────────────────────
  var API = '{{ route('statistics.api') }}';
  var charts = {};
  var bulan = document.getElementById('statBulan').value || '{{ date("Y-m") }}';

  function rp(n) { return 'Rp ' + Number(n||0).toLocaleString('id-ID'); }
  function rpShort(n) {
    n = Number(n||0);
    if (n >= 1e9) return 'Rp ' + (n/1e9).toFixed(1) + 'M';
    if (n >= 1e6) return 'Rp ' + (n/1e6).toFixed(1) + 'jt';
    if (n >= 1e3) return 'Rp ' + (n/1e3).toFixed(0) + 'rb';
    return 'Rp ' + n.toLocaleString('id-ID');
  }
  function pct(n) { return Number(n||0).toFixed(1) + '%'; }
  function num(n) { return Number(n||0).toLocaleString('id-ID'); }
  function monthLabel(ym) {
    var m = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des'];
    var p = (ym||'').split('-');
    return m[parseInt(p[1]||1)-1] + ' ' + (p[0]||'');
  }
  function shortMonth(ym) {
    var m = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des'];
    var p = (ym||'').split('-');
    return m[parseInt(p[1]||1)-1];
  }

  function fetchAPI(action, cb) {
    fetch(API + '?action=' + action + '&bulan=' + encodeURIComponent(bulan), {credentials:'same-origin'})
      .then(function(r){return r.json()})
      .then(function(j){ if(j.status==='success') cb(j.data); else console.warn(action,j.message); })
      .catch(function(e){ console.error(action,e); });
  }

  // Chart.js dark theme defaults
  Chart.defaults.color = '#94a3b8';
  Chart.defaults.borderColor = 'rgba(148,163,184,.08)';
  Chart.defaults.font.family = "'Inter','Segoe UI',sans-serif";
  Chart.defaults.font.size = 11;
  Chart.defaults.plugins.legend.labels.boxWidth = 12;
  Chart.defaults.plugins.legend.labels.padding = 12;
  Chart.defaults.plugins.tooltip.backgroundColor = '#1e293b';
  Chart.defaults.plugins.tooltip.borderColor = 'var(--border)';
  Chart.defaults.plugins.tooltip.borderWidth = 1;
  Chart.defaults.plugins.tooltip.cornerRadius = 8;
  Chart.defaults.plugins.tooltip.padding = 10;
  Chart.defaults.elements.point.radius = 3;
  Chart.defaults.elements.point.hoverRadius = 5;
  
  function destroyChart(key) { if(charts[key]){charts[key].destroy();delete charts[key];} }

  // ── Tab Switching ────────────────────────────────────────────
  var loaded = {payment:false,growth:false,churn:false,management:false};
  window.statSwitchTab = function(tab, btn) {
    document.querySelectorAll('.stat-tab').forEach(function(t){t.classList.remove('active')});
    document.querySelectorAll('.stat-panel').forEach(function(p){p.classList.remove('active')});
    btn.classList.add('active');
    var panelId = 'panel' + tab.charAt(0).toUpperCase() + tab.slice(1);
    var panel = document.getElementById(panelId);
    if(panel) panel.classList.add('active');
    if(!loaded[tab]) { loadTab(tab); loaded[tab]=true; }
  };
  window.statReload = function() {
    bulan = document.getElementById('statBulan').value;
    loaded = {payment:false,growth:false,churn:false,management:false};
    var active = document.querySelector('.stat-tab.active');
    var tab = active ? active.dataset.tab : 'payment';
    loadTab(tab); loaded[tab]=true;
  };

  function loadTab(tab) {
    switch(tab) {
      case 'payment': loadPayment(); break;
      case 'growth': loadGrowth(); break;
      case 'churn': loadChurn(); break;
      case 'management': loadManagement(); break;
    }
  }

  // ═════════════════════════════════════════════════════════════
  // TAB 1: PAYMENT
  // ═════════════════════════════════════════════════════════════
  function loadPayment() {
    fetchAPI('payment_summary', function(d) {
      document.getElementById('kpPayToday').textContent = rpShort(d.pay_today);
      document.getElementById('kpPayMonth').textContent = rpShort(d.pay_month);
      document.getElementById('kpPayYearly').textContent = rpShort(d.pay_yearly);
      document.getElementById('kpUnpaid').textContent = num(d.unpaid_count);
      document.getElementById('kpUnpaidSub').textContent = rpShort(d.unpaid_amount) + ' tunggakan';
      document.getElementById('kpOverdue').textContent = num(d.overdue_count);
      document.getElementById('kpSuccessRate').textContent = pct(d.success_rate);
      document.getElementById('kpSuccessSub').textContent = d.paid_cust + '/' + d.active_cust + ' pelanggan';
      document.getElementById('kpArpu').textContent = rpShort(d.arpu);
      document.getElementById('kpTxn').textContent = num(d.txn_month);
      document.getElementById('kpPayYearSub').textContent = 'Tahun ' + bulan.split('-')[0];
      var g = d.growth;
      var gEl = document.getElementById('kpPayGrowth');
      gEl.innerHTML = (g >= 0 ? '<span class="trend-up"><i class="bi bi-arrow-up-short"></i>'+pct(g)+'</span>' : '<span class="trend-down"><i class="bi bi-arrow-down-short"></i>'+pct(Math.abs(g))+'</span>') + ' vs bulan lalu';

      // Generate insights
      var ins = [];
      if(g > 0) ins.push('Pendapatan bulan ini naik ' + pct(g) + ' dibanding bulan lalu');
      else if(g < 0) ins.push('Pendapatan bulan ini turun ' + pct(Math.abs(g)) + ' — perlu evaluasi');
      if(d.success_rate >= 90) ins.push('Collection rate sangat baik ('+pct(d.success_rate)+')');
      else if(d.success_rate >= 70) ins.push('Collection rate cukup ('+pct(d.success_rate)+'), masih bisa ditingkatkan');
      else ins.push('Collection rate rendah ('+pct(d.success_rate)+') — perlu follow-up intensif');
      if(d.unpaid_count > 0) ins.push(num(d.unpaid_count) + ' pelanggan dengan total tunggakan ' + rpShort(d.unpaid_amount));
      if(d.overdue_count > 0) ins.push(d.overdue_count + ' invoice sudah melewati jatuh tempo');
      ins.push('ARPU saat ini ' + rpShort(d.arpu) + ' per pelanggan aktif');
      var list = document.getElementById('insightPayList');
      list.innerHTML = ins.map(function(s){return '<li>'+s+'</li>'}).join('');
    });

    fetchAPI('payment_methods', function(d) {
      destroyChart('payMethods');
      var labels = d.map(function(r){return r.metode});
      var vals = d.map(function(r){return parseFloat(r.total)});
      var colors = ['#818cf8','#34d399','#fbbf24','#f472b6','#22d3ee','#fb923c','#a78bfa','#4ade80'];
      charts.payMethods = new Chart(document.getElementById('chartPayMethods'), {
        type:'pie',
        data:{labels:labels,datasets:[{data:vals,backgroundColor:colors.slice(0,labels.length),borderWidth:0,hoverOffset:8}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{padding:10}}}}
      });
    });

    fetchAPI('payment_daily', function(d) {
      destroyChart('payDaily');
      charts.payDaily = new Chart(document.getElementById('chartPayDaily'), {
        type:'line',
        data:{
          labels:d.map(function(r){var p=r.dt.split('-');return parseInt(p[2])+'/'+parseInt(p[1])}),
          datasets:[{
            label:'Pendapatan',
            data:d.map(function(r){return parseFloat(r.total)}),
            borderColor:'#818cf8',backgroundColor:'rgba(129,140,248,.12)',
            fill:false,tension:.4,borderWidth:3,pointBackgroundColor:'var(--bg-card)',pointBorderColor:'#818cf8',pointBorderWidth:2,pointRadius:3,pointHoverRadius:5,fill:false
          }]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{ticks:{callback:function(v){return rpShort(v)}},grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}
      });
    });

    fetchAPI('payment_monthly', function(d) {
      destroyChart('payMonthly');
      charts.payMonthly = new Chart(document.getElementById('chartPayMonthly'), {
        type:'bar',
        data:{
          labels:d.map(function(r){return shortMonth(r.bulan)}),
          datasets:[{
            label:'Pendapatan',
            data:d.map(function(r){return parseFloat(r.total)}),
            backgroundColor:'rgba(129,140,248,.7)',borderColor:'#818cf8',borderWidth:0,borderRadius:8,barPercentage:.6
          }]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{ticks:{callback:function(v){return rpShort(v)}},grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}
      });
    });

    fetchAPI('payment_heatmap', function(grid) {
      var days = ['Min','Sen','Sel','Rab','Kam','Jum','Sab'];
      var html = '<div class="stat-heatmap">';
      html += '<div class="stat-heatmap-label"></div>';
      for(var h=0;h<24;h++) html += '<div class="stat-heatmap-header">'+h+'</div>';
      var maxVal = 0;
      for(var di=1;di<=7;di++) for(var hi=0;hi<24;hi++) { var v=(grid[di]||{})[hi]||0; if(v>maxVal) maxVal=v; }
      for(var di=1;di<=7;di++){
        html += '<div class="stat-heatmap-label">'+days[di-1]+'</div>';
        for(var hi=0;hi<24;hi++){
          var v = (grid[di]||{})[hi]||0;
          var lv = maxVal>0 ? Math.ceil(v/maxVal*5) : 0;
          if(v===0) lv=0;
          html += '<div class="stat-heatmap-cell stat-hm-'+lv+'" data-tooltip="'+days[di-1]+' '+hi+':00 — '+v+' transaksi"></div>';
        }
      }
      html += '</div>';
      document.getElementById('heatmapWrap').innerHTML = html;
    });
  }

  // ═════════════════════════════════════════════════════════════
  // TAB 2: GROWTH
  // ═════════════════════════════════════════════════════════════
  function loadGrowth() {
    fetchAPI('customer_summary', function(d) {
      document.getElementById('kgActive').textContent = num(d.total_active);
      document.getElementById('kgNew').textContent = num(d.new_month);
      document.getElementById('kgNewSub').textContent = 'Bulan lalu: ' + num(d.new_last);
      document.getElementById('kgRate').textContent = (d.growth_rate >= 0 ? '+' : '') + pct(d.growth_rate);
      document.getElementById('kgRate').style.color = d.growth_rate >= 0 ? '#34d399' : '#f87171';
      document.getElementById('kgPppoe').textContent = num(d.pppoe);
      document.getElementById('kgCuti').textContent = num(d.cuti);
      document.getElementById('kgSuspend').textContent = num(d.suspend);
    });

    fetchAPI('customer_growth', function(d) {
      destroyChart('custGrowth');
      charts.custGrowth = new Chart(document.getElementById('chartCustGrowth'), {
        type:'line',
        data:{
          labels:d.map(function(r){return shortMonth(r.bulan)}),
          datasets:[
            {
              label:'Penambahan',
              data:d.map(function(r){return r.new}),
              borderColor:'#34d399', backgroundColor:'rgba(52,211,153,.1)',
              borderWidth:2, tension:0.3, fill:true, pointRadius:3, pointHoverRadius:5
            },
            {
              label:'Penurunan',
              data:d.map(function(r){return r.churn}),
              borderColor:'#f43f5e', backgroundColor:'rgba(244,63,94,.1)',
              borderWidth:2, tension:0.3, fill:true, pointRadius:3, pointHoverRadius:5
            }
          ]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'top',labels:{color:'var(--text-muted)',usePointStyle:true}}},scales:{y:{beginAtZero:true,grid:{color:'rgba(0,0,0,0.05)'},ticks:{color:'var(--text-secondary)'}},x:{grid:{display:false},ticks:{color:'var(--text-secondary)'}}}}
      });

      destroyChart('custCumulative');
      charts.custCumulative = new Chart(document.getElementById('chartCustCumulative'), {
        type:'line',
        data:{
          labels:d.map(function(r){return shortMonth(r.bulan)}),
          datasets:[{
            label:'Total Pelanggan',
            data:d.map(function(r){return r.total}),
            borderColor:'#818cf8',backgroundColor:'rgba(129,140,248,.1)',
            fill:false,tension:.4,borderWidth:3,pointBackgroundColor:'var(--bg-card)',pointBorderColor:'#818cf8',pointBorderWidth:2,pointRadius:3,pointHoverRadius:5,fill:false
          }]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}
      });
    });

    fetchAPI('customer_by_area', function(d) {
      destroyChart('custArea');
      var reqHeight = Math.max(300, d.length * 35 + 60);
      document.getElementById('wrapCustArea').style.height = reqHeight + 'px';
      
      var colors = ['#818cf8','#34d399','#fbbf24','#f472b6','#22d3ee','#fb923c','#a78bfa','#4ade80','#f87171','#38bdf8'];
      charts.custArea = new Chart(document.getElementById('chartCustArea'), {
        type:'bar',
        data:{
          labels:d.map(function(r){return r.area_name}),
          datasets:[{
            label:'Pelanggan',
            data:d.map(function(r){return parseInt(r.cnt)}),
            backgroundColor:d.map(function(_,i){return colors[i%colors.length]}),
            borderWidth:0,borderRadius:6,barPercentage:.7
          }]
        },
        options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{grid:{display:false},ticks:{color:'var(--text-muted)'}},x:{grid:{color:'rgba(0,0,0,0.05)'},ticks:{color:'var(--text-secondary)'}}}}
      });
    });
  }

  // ═════════════════════════════════════════════════════════════
  // TAB 3: CHURN
  // ═════════════════════════════════════════════════════════════
  function loadChurn() {
    fetchAPI('churn_summary', function(d) {
      document.getElementById('kcRate').textContent = pct(d.churn_rate);
      document.getElementById('kcRate').style.color = d.churn_rate > 5 ? '#f87171' : d.churn_rate > 2 ? '#fbbf24' : '#34d399';
      document.getElementById('kcSuspLong').textContent = num(d.suspend_long);
      document.getElementById('kcRecovery').textContent = num(d.recovery);
      document.getElementById('kcAvgLife').textContent = d.avg_lifetime + ' bln';
      document.getElementById('kcIsolir').textContent = num(d.isolir);
      document.getElementById('kcCuti').textContent = num(d.cuti);
      var retention = 100 - d.churn_rate;
      document.getElementById('kcRetention').textContent = pct(retention);
      document.getElementById('kcRetention').style.color = retention >= 95 ? '#34d399' : retention >= 90 ? '#fbbf24' : '#f87171';

      // Donut
      destroyChart('churnDonut');
      charts.churnDonut = new Chart(document.getElementById('chartChurnDonut'), {
        type:'pie',
        data:{
          labels:['Aktif','Isolir','Cuti/Berhenti'],
          datasets:[{
            data:[d.total - d.isolir - d.churned, d.isolir, d.churned],
            backgroundColor:['#34d399','#f87171','#fbbf24'],
            borderWidth:0,hoverOffset:8
          }]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{padding:10}}}}
      });

      // Insights
      var ins = [];
      if(d.churn_rate <= 2) ins.push('Churn rate sangat rendah ('+pct(d.churn_rate)+') — bisnis sehat');
      else if(d.churn_rate <= 5) ins.push('Churn rate moderat ('+pct(d.churn_rate)+') — monitor terus');
      else ins.push('Churn rate tinggi ('+pct(d.churn_rate)+') — PERLU PERHATIAN SEGERA');
      if(d.suspend_long > 0) ins.push(num(d.suspend_long)+' pelanggan suspend >30 hari — risiko churn sangat tinggi');
      if(d.recovery > 0) ins.push(num(d.recovery)+' pelanggan berhasil di-recovery bulan ini');
      ins.push('Rata-rata umur pelanggan: '+d.avg_lifetime+' bulan');
      ins.push('Retention rate: '+pct(retention));
      document.getElementById('insightChurnList').innerHTML = ins.map(function(s){return '<li>'+s+'</li>'}).join('');
    });

    fetchAPI('churn_trend', function(d) {
      destroyChart('churnTrend');
      charts.churnTrend = new Chart(document.getElementById('chartChurnTrend'), {
        type:'line',
        data:{
          labels:d.map(function(r){return shortMonth(r.bulan)}),
          datasets:[
            {label:'Churn Rate (%)',data:d.map(function(r){return r.rate}),borderColor:'#f87171',backgroundColor:'rgba(248,113,113,.1)',fill:false,tension:.4,borderWidth:3,yAxisID:'y',pointBackgroundColor:'var(--bg-card)',pointBorderColor:'#f87171',pointBorderWidth:2,pointRadius:3,pointHoverRadius:5,fill:false},
            {label:'Cuti / Keluar',data:d.map(function(r){return r.churned}),borderColor:'#fbbf24',backgroundColor:'transparent',tension:.4,borderWidth:2,borderDash:[5,5],yAxisID:'y1',pointBackgroundColor:'#fbbf24'}
          ]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'top'}},scales:{y:{type:'linear',position:'left',ticks:{callback:function(v){return v+'%'}},grid:{color:'rgba(0,0,0,0.05)'}},y1:{type:'linear',position:'right',grid:{drawOnChartArea:false}},x:{grid:{display:false}}}}
      });
    });
  }

  // ═════════════════════════════════════════════════════════════
  // TAB 4: MANAGEMENT
  // ═════════════════════════════════════════════════════════════
  function loadManagement() {
    
    fetchAPI('net_revenue_detail', function(d) {
      document.getElementById('netRevWidget').style.display = 'grid';
      document.getElementById('nrWidgetAmount').textContent = rpShort(d.summary.pendapatan_bersih);
      document.getElementById('nrWidgetMargin').innerHTML = '<i class="bi bi-graph-up-arrow"></i> Margin: ' + pct(d.summary.margin_keuntungan);
      document.getElementById('nrWidgetKotor').textContent = rpShort(d.summary.pendapatan_kotor);
      document.getElementById('nrWidgetFeeSales').textContent = '- ' + rpShort(d.summary.total_fee_sales);
      document.getElementById('nrWidgetFeeKolektor').textContent = '- ' + rpShort(d.summary.total_fee_kolektor);
      document.getElementById('nrWidgetPpn').textContent = '- ' + rpShort(d.summary.total_ppn);
      document.getElementById('nrWidgetOps').textContent = '- ' + rpShort(d.summary.total_pengeluaran_operasional);

      destroyChart('netRevSpark');
      var ctx = document.getElementById('chartNetRevSpark').getContext('2d');
      var gradient = ctx.createLinearGradient(0, 0, 0, 130);
      gradient.addColorStop(0, 'rgba(52, 211, 153, 0.4)');
      gradient.addColorStop(1, 'rgba(52, 211, 153, 0.0)');
      
      charts.netRevSpark = new Chart(ctx, {
        type: 'line',
        data: {
          labels: d.historical_trend.map(function(r){ return shortMonth(r.bulan); }),
          datasets: [{
            label: 'Net Revenue',
            data: d.historical_trend.map(function(r){ return parseFloat(r.bersih); }),
            borderColor: '#34d399',
            backgroundColor: gradient,
            borderWidth: 3,
            tension: 0.4,
            fill: true,
            pointBackgroundColor: '#1e293b',
            pointBorderColor: '#34d399',
            pointBorderWidth: 2,
            pointRadius: 3,
            pointHoverRadius: 5
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: function(ctx) { return rpShort(ctx.raw); } } } },
          scales: { x: { display: false }, y: { display: false, min: 0 } }
        }
      });
    });

    fetchAPI('revenue_expense_trend', function(d) {
      destroyChart('revExpense');
      charts.revExpense = new Chart(document.getElementById('chartRevExpense'), {
        type: 'bar',
        data: {
          labels: d.map(function(r){ return shortMonth(r.bulan); }),
          datasets: [
            {
              type: 'line',
              label: 'Kas Ditahan',
              data: d.map(function(r){ return parseFloat(r.kas_ditahan); }),
              borderColor: '#14b8a6',
              backgroundColor: '#14b8a6',
              borderWidth: 3,
              pointBackgroundColor: '#1e293b',
              pointBorderColor: '#14b8a6',
              pointBorderWidth: 2,
              pointRadius: 5,
              pointHoverRadius: 7,
              tension: 0.4,
              fill: false,
              yAxisID: 'y'
            },
            {
              type: 'line',
              label: 'Pendapatan Bersih (Net)',
              data: d.map(function(r){ return parseFloat(r.bersih); }),
              borderColor: '#4ade80',
              backgroundColor: '#1e293b',
              borderWidth: 3,
              pointBackgroundColor: '#1e293b',
              pointBorderColor: '#4ade80',
              pointBorderWidth: 2,
              pointRadius: 5,
              pointHoverRadius: 7,
              tension: 0.4,
              fill: false,
              yAxisID: 'y'
            },
            {
              type: 'bar',
              label: 'Pendapatan Kotor',
              data: d.map(function(r){ return parseFloat(r.kotor); }),
              backgroundColor: 'rgba(56, 189, 248, 0.8)',
              borderRadius: 6,
              yAxisID: 'y'
            },
            {
              type: 'bar',
              label: 'Potongan (Fee+PPN+BHP USO+Ops)',
              data: d.map(function(r){ return parseFloat(r.fee) + parseFloat(r.ppn) + parseFloat(r.pengeluaran); }),
              backgroundColor: 'rgba(248, 113, 113, 0.8)',
              borderRadius: 6,
              yAxisID: 'y'
            },
            {
              type: 'bar',
              label: 'Deviden',
              data: d.map(function(r){ return parseFloat(r.deviden); }),
              backgroundColor: 'rgba(217, 70, 239, 0.8)',
              borderRadius: 6,
              yAxisID: 'y'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'top', labels: { usePointStyle: true, boxWidth: 8 } },
            tooltip: {
              callbacks: {
                label: function(ctx) { return ctx.dataset.label + ': ' + rpShort(ctx.raw); }
              }
            }
          },
          scales: {
            y: {
              type: 'linear',
              position: 'left',
              ticks: { callback: function(v){ return rpShort(v); } },
              grid: { color: 'rgba(148,163,184,.06)' }
            },
            x: {
              grid: { display: false }
            }
          }
        }
      });
    });

    fetchAPI('management_summary', function(d) {
      document.getElementById('kmMrr').textContent = rpShort(d.mrr);
      if(document.getElementById('kmArr')) document.getElementById('kmArr').textContent = rpShort(d.arr);
      var nrColor = d.net_revenue >= 0 ? '#4ade80' : '#f87171';
      document.getElementById('kmKotor').textContent = rpShort(d.collected);
      document.getElementById('kmPengeluaran').textContent = rpShort((d.fee || 0) + (d.ppn || 0) + (d.pengeluaran || 0));
      document.getElementById('kmPengeluaranSub').textContent = rpShort(d.fee || 0) + ' Fee + ' + rpShort(d.ppn || 0) + ' PPN+BHP USO + ' + rpShort(d.pengeluaran || 0) + ' Ops';
      document.getElementById('kmNetRev').textContent = rpShort(d.net_revenue);
      document.getElementById('kmDeviden').textContent = rpShort(d.deviden);
      document.getElementById('kmKasDitahan').textContent = rpShort(d.kas_ditahan);
      document.getElementById('kmNetRev').style.color = nrColor;
      document.getElementById('kmCollEff').textContent = pct(d.collection_eff);
      document.getElementById('kmCollEff').style.color = d.collection_eff >= 90 ? '#34d399' : d.collection_eff >= 70 ? '#fbbf24' : '#f87171';
      document.getElementById('kmAvgDays').textContent = d.avg_days_to_pay + ' hari';
      document.getElementById('kmOutstanding').textContent = rpShort(d.total_outstanding);
      document.getElementById('kmLtv').textContent = rpShort(d.ltv);
      document.getElementById('kmLtvSub').textContent = rpShort(d.arpu) + ' × ' + d.avg_lifetime + ' bln';

      // Gauge
      var pctVal = Math.min(100, Math.max(0, d.collection_eff));
      var circumference = 2 * Math.PI * 52;
      var offset = circumference - (pctVal / 100 * circumference);
      var fg = document.getElementById('gaugeFg');
      fg.style.strokeDasharray = circumference;
      fg.style.strokeDashoffset = offset;
      fg.style.stroke = pctVal >= 90 ? '#34d399' : pctVal >= 70 ? '#fbbf24' : '#f87171';
      document.getElementById('gaugeText').textContent = pct(pctVal);

      // Progress bars
      var maxBar = Math.max(d.collected, d.pengeluaran, 1);
      document.getElementById('pbCollected').textContent = rpShort(d.collected);
      document.getElementById('pbCollectedBar').style.width = (d.collected/maxBar*100)+'%';
      document.getElementById('pbPengeluaran').textContent = rpShort(d.pengeluaran);
      document.getElementById('pbPengeluaranBar').style.width = (d.pengeluaran/maxBar*100)+'%';

      // Management Insights
      var ins = [];
      if(d.collection_eff >= 95) ins.push('Collection efficiency sangat baik ('+pct(d.collection_eff)+')');
      else if(d.collection_eff >= 80) ins.push('Collection efficiency baik ('+pct(d.collection_eff)+'), target >90%');
      else ins.push('Collection efficiency rendah ('+pct(d.collection_eff)+') — PERLU PERBAIKAN PROSES PENAGIHAN');
      ins.push('MRR saat ini '+rpShort(d.mrr)+', proyeksi ARR '+rpShort(d.arr));
      if(d.avg_days_to_pay <= 10) ins.push('Rata-rata pembayaran cepat ('+d.avg_days_to_pay+' hari)');
      else if(d.avg_days_to_pay <= 20) ins.push('Rata-rata pembayaran '+d.avg_days_to_pay+' hari — cukup baik');
      else ins.push('Rata-rata pembayaran lambat ('+d.avg_days_to_pay+' hari) — pertimbangkan reminder lebih awal');
      if(d.total_outstanding > d.mrr) ins.push('Total piutang ('+rpShort(d.total_outstanding)+') melebihi MRR — risiko cashflow');
      ins.push('Customer LTV: '+rpShort(d.ltv)+' (ARPU '+rpShort(d.arpu)+' × '+d.avg_lifetime+' bulan)');
      document.getElementById('insightMgmtList').innerHTML = ins.map(function(s){return '<li>'+s+'</li>'}).join('');

      // Action recommendations
      var actions = [];
      if(d.collection_eff < 80) actions.push('Tingkatkan follow-up tagihan — kirim reminder WA otomatis 3 hari sebelum jatuh tempo');
      if(d.total_outstanding > d.mrr * 0.5) actions.push('Lakukan penagihan intensif untuk piutang yang sudah >30 hari');
      if(d.avg_days_to_pay > 15) actions.push('Pertimbangkan insentif early payment (diskon untuk bayar sebelum tanggal 5)');
      if(d.net_revenue < 0) actions.push('Net revenue negatif — review dan kurangi pengeluaran operasional');
      if(d.pengeluaran > d.collected * 0.3) actions.push('Rasio pengeluaran >30% dari pendapatan — evaluasi efisiensi biaya');
      if(actions.length === 0) actions.push('Kondisi keuangan sehat — pertahankan performa saat ini');
      actions.push('Review paket harga secara berkala untuk mengoptimalkan ARPU');
      document.getElementById('insightActionList').innerHTML = actions.map(function(s){return '<li>'+s+'</li>'}).join('');
    });

    fetchAPI('aging_analysis', function(d) {
      var html = '';
      var totalAmt = 0, totalCnt = 0;
      d.forEach(function(r) {
        var cls = r.label.indexOf('>90') !== -1 ? 'aging-danger' : r.label.indexOf('61') !== -1 ? 'aging-warn' : r.label.indexOf('31') !== -1 ? 'aging-warn' : 'aging-ok';
        html += '<tr><td class="'+cls+'">'+r.label+'</td><td>'+num(r.count)+' pelanggan</td><td class="'+cls+'">'+rpShort(r.amount)+'</td></tr>';
        totalAmt += r.amount; totalCnt += r.count;
      });
      html += '<tr style="font-weight:700;border-top:2px solid var(--border);"><td>Total</td><td>'+num(totalCnt)+' pelanggan</td><td>'+rpShort(totalAmt)+'</td></tr>';
      document.getElementById('agingBody').innerHTML = html;
    });

    fetchAPI('revenue_by_area', function(d) {
      var html = '';
      d.forEach(function(r, i) {
        html += '<li class="stat-rank-item"><span class="stat-rank-num">'+(i+1)+'</span><span class="stat-rank-name">'+r.area_name+' <span style="color:#64748b;font-size:.68rem">('+r.cust_count+' plg)</span></span><span class="stat-rank-val">'+rpShort(r.revenue)+'</span></li>';
      });
      if(!d.length) html = '<li class="stat-rank-item"><span class="stat-rank-name" style="color:#64748b">Tidak ada data</span></li>';
      document.getElementById('rankAreaList').innerHTML = html;
    });

    fetchAPI('revenue_by_package', function(d) {
      var html = '';
      d.forEach(function(r, i) {
        html += '<li class="stat-rank-item"><span class="stat-rank-num">'+(i+1)+'</span><span class="stat-rank-name">'+r.paket_name+' <span style="color:#64748b;font-size:.68rem">('+rpShort(r.harga)+')</span></span><span class="stat-rank-val">'+rpShort(r.revenue)+'</span></li>';
      });
      if(!d.length) html = '<li class="stat-rank-item"><span class="stat-rank-name" style="color:#64748b">Tidak ada data</span></li>';
      document.getElementById('rankPaketList').innerHTML = html;
    });

    fetchAPI('collection_trend', function(d) {
      destroyChart('collTrend');
      charts.collTrend = new Chart(document.getElementById('chartCollTrend'), {
        type:'line',
        data:{
          labels:d.map(function(r){return shortMonth(r.bulan)}),
          datasets:[
            {label:'Efficiency (%)',data:d.map(function(r){return r.efficiency}),borderColor:'#34d399',backgroundColor:'rgba(52,211,153,.1)',fill:false,tension:.4,borderWidth:3,yAxisID:'y',pointBackgroundColor:'var(--bg-card)',pointBorderColor:'#34d399',pointBorderWidth:2,pointRadius:3,pointHoverRadius:5,fill:false},
            {label:'Terkumpul',data:d.map(function(r){return r.collected}),borderColor:'#818cf8',backgroundColor:'transparent',tension:.4,borderWidth:2,borderDash:[5,5],yAxisID:'y1',pointBackgroundColor:'#818cf8'},
            {label:'Expected (MRR)',data:d.map(function(r){return r.expected}),borderColor:'#64748b',backgroundColor:'transparent',tension:.4,borderWidth:1,borderDash:[3,3],yAxisID:'y1',pointRadius:0}
          ]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'top'}},scales:{y:{type:'linear',position:'left',ticks:{callback:function(v){return v+'%'}},grid:{color:'rgba(0,0,0,0.05)'},min:0},y1:{type:'linear',position:'right',ticks:{callback:function(v){return rpShort(v)}},grid:{drawOnChartArea:false}},x:{grid:{display:false}}}}
      });
    });
  }

  // ── Hidden Months Management ───────────────────────────────
  var hiddenMonths = [];

  function loadHiddenMonths() {
    fetch(API + '?action=list_hidden_months', {credentials:'same-origin'})
      .then(function(r){return r.json()})
      .then(function(j){
        if(j.status==='success') {
          hiddenMonths = j.data || [];
          renderHiddenMonths();
          updateHideButton();
        }
      }).catch(function(e){ console.error('loadHiddenMonths',e); });
  }

  function renderHiddenMonths() {
    var badge = document.getElementById('hiddenCountBadge');
    var list = document.getElementById('hiddenMonthsList');
    if(hiddenMonths.length === 0) {
      badge.style.display = 'none';
      list.innerHTML = '<div style="color:#64748b;font-size:.78rem;padding:.5rem;">Tidak ada bulan tersembunyi</div>';
      return;
    }
    badge.style.display = 'inline-block';
    badge.textContent = hiddenMonths.length;
    var html = '';
    hiddenMonths.forEach(function(p) {
      html += '<div class="stat-hidden-item">'
        + '<span class="stat-hidden-item-label"><i class="bi bi-calendar-x" style="color:#f87171;"></i> ' + monthLabel(p) + '</span>'
        + '<button class="stat-hidden-item-btn" onclick="unhideMonth(\'' + p + '\')" title="Tampilkan kembali"><i class="bi bi-eye"></i></button>'
        + '</div>';
    });
    list.innerHTML = html;
  }

  function updateHideButton() {
    var currentBulan = document.getElementById('statBulan').value;
    var isHidden = hiddenMonths.indexOf(currentBulan) !== -1;
    var label = document.getElementById('btnToggleHideLabel');
    var btn = document.getElementById('btnToggleHide');
    if(isHidden) {
      label.textContent = 'Tampilkan';
      btn.style.background = 'linear-gradient(135deg,#10b981,#059669)';
      btn.querySelector('i').className = 'bi bi-eye';
    } else {
      label.textContent = 'Sembunyikan';
      btn.style.background = 'linear-gradient(135deg,#ef4444,#dc2626)';
      btn.querySelector('i').className = 'bi bi-eye-slash';
    }
  }

  window.toggleHideMonth = function() {
    var periode = document.getElementById('statBulan').value;
    if(!periode) return;
    var isHidden = hiddenMonths.indexOf(periode) !== -1;
    var msg = isHidden
      ? 'Tampilkan kembali data statistik bulan ' + monthLabel(periode) + '?'
      : 'Sembunyikan data statistik bulan ' + monthLabel(periode) + '?\nData akan ditampilkan sebagai 0 di semua laporan.';
    if(!confirm(msg)) return;
    fetch(API + '?action=toggle_hide_month&periode=' + encodeURIComponent(periode), {credentials:'same-origin'})
      .then(function(r){return r.json()})
      .then(function(j){
        if(j.status==='success') {
          loadHiddenMonths();
          statReload();
        } else {
          alert(j.message || 'Gagal mengubah visibilitas.');
        }
      }).catch(function(e){ alert('Error: ' + e.message); });
  };

  window.unhideMonth = function(periode) {
    if(!confirm('Tampilkan kembali data bulan ' + monthLabel(periode) + '?')) return;
    fetch(API + '?action=toggle_hide_month&periode=' + encodeURIComponent(periode), {credentials:'same-origin'})
      .then(function(r){return r.json()})
      .then(function(j){
        if(j.status==='success') {
          loadHiddenMonths();
          statReload();
        }
      }).catch(function(e){ console.error(e); });
  };

  window.toggleHiddenList = function() {
    var dd = document.getElementById('hiddenMonthsDropdown');
    dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
  };

  // Close dropdown on outside click
  document.addEventListener('click', function(e) {
    var wrap = document.querySelector('.stat-hidden-months-wrap');
    if(wrap && !wrap.contains(e.target)) {
      document.getElementById('hiddenMonthsDropdown').style.display = 'none';
    }
  });

  // Listen for bulan change to update hide button state
  document.getElementById('statBulan').addEventListener('change', function() {
    updateHideButton();
  });

  // ── Initial Load ─────────────────────────────────────────────
  loadHiddenMonths();
  loadPayment();
  loaded.payment = true;

}

if (typeof Chart === 'undefined') {
  $.getScript("asset/js/chart.umd.min.js", function() {
    initStatistik();
  });
} else {
  initStatistik();
}
</script>
 
@endpush
@endsection
