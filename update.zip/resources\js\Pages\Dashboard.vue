<template>
    <AppLayout title="Dashboard & Pelanggan">
        <!-- Welcome Section -->
        <div class="mb-6 p-6 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-lg relative overflow-hidden">
            <div class="relative z-10">
                <h1 class="text-2xl font-bold mb-1">Selamat datang, {{ $page.props.auth.user.name }}! 👋</h1>
                <p class="text-indigo-100 opacity-90">{{ $page.props.tenant?.name }} &mdash; {{ new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) }}</p>
            </div>
            <div class="absolute -top-10 -right-10 w-48 h-48 bg-white opacity-10 rounded-full"></div>
        </div>

        <!-- KPI Stats -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card class="flex items-center p-4">
                <div class="p-3 rounded-lg bg-indigo-50 text-indigo-600 mr-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                <div>
                    <div class="text-2xl font-bold text-slate-800 dark:text-white">{{ formatNumber(stats.total_customers) }}</div>
                    <div class="text-sm text-slate-500 dark:text-slate-400">Total Pelanggan</div>
                    <div class="text-xs text-indigo-600 dark:text-indigo-400 mt-1">{{ stats.active_customers }} aktif</div>
                </div>
            </Card>

            <Card class="flex items-center p-4">
                <div class="p-3 rounded-lg bg-emerald-50 text-emerald-600 mr-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div>
                    <div class="text-2xl font-bold text-slate-800 dark:text-white">Rp {{ formatNumber(stats.revenue_this_month) }}</div>
                    <div class="text-sm text-slate-500 dark:text-slate-400">Pendapatan Bulan Ini</div>
                    <div class="text-xs text-emerald-600 dark:text-emerald-400 mt-1">{{ stats.payments_this_month }} pembayaran</div>
                </div>
            </Card>

            <Card class="flex items-center p-4">
                <div class="p-3 rounded-lg bg-red-50 text-red-600 mr-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path></svg>
                </div>
                <div>
                    <div class="text-2xl font-bold text-slate-800 dark:text-white">{{ formatNumber(stats.isolated) }}</div>
                    <div class="text-sm text-slate-500 dark:text-slate-400">Isolir Aktif</div>
                    <div class="text-xs text-red-600 dark:text-red-400 mt-1">Pelanggan terisolir</div>
                </div>
            </Card>

            <Card class="flex items-center p-4">
                <div class="p-3 rounded-lg bg-amber-50 text-amber-600 mr-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path></svg>
                </div>
                <div>
                    <div class="text-2xl font-bold text-slate-800 dark:text-white">{{ formatNumber(stats.new_this_month) }}</div>
                    <div class="text-sm text-slate-500 dark:text-slate-400">Pelanggan Baru</div>
                    <div class="text-xs text-amber-600 dark:text-amber-400 mt-1">Bulan ini</div>
                </div>
            </Card>
        </div>

        <!-- Filters & Data Table -->
        <Card title="Data Pelanggan" bodyClass="!p-0">
            <!-- Filter Actions -->
            <div class="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex flex-wrap gap-3 items-center">
                <Input v-model="filter.search" placeholder="Cari nama, username..." class="w-full md:w-48" />
                
                <select v-model="filter.area_id" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                    <option value="">Semua Area</option>
                    <option v-for="area in areas" :key="area.id" :value="area.id">{{ area.name }}</option>
                </select>

                <select v-model="filter.package_id" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                    <option value="">Semua Paket</option>
                    <option v-for="pkg in packages" :key="pkg.id" :value="pkg.id">{{ pkg.name }}</option>
                </select>

                <select v-model="filter.status" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                    <option value="">Status</option>
                    <option value="active">Aktif</option>
                    <option value="inactive">Non-Aktif</option>
                </select>

                <Button @click="applyFilters" variant="secondary">Filter</Button>
                <Button @click="resetFilters" variant="outline" v-if="hasFilters">Reset</Button>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama & Kontak</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Area</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Paket</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="customer in customers.data" :key="customer.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ customer.name }}</div>
                                <div class="text-sm text-slate-500">{{ customer.username }} | {{ customer.phone }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                                {{ customer.area?.name || '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                                {{ customer.package?.name || '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span v-if="customer.is_isolated" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Isolir</span>
                                <span v-else-if="customer.is_on_leave" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-amber-100 text-amber-800">Cuti</span>
                                <span v-else-if="customer.status === 'active'" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Aktif</span>
                                <span v-else class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-slate-100 text-slate-800">Non-Aktif</span>
                            </td>
                        </tr>
                        <tr v-if="customers.data.length === 0">
                            <td colspan="4" class="px-6 py-8 text-center text-slate-500">
                                Tidak ada data pelanggan ditemukan.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50" v-if="customers.links.length > 3">
                <div class="flex flex-wrap gap-1">
                    <template v-for="(link, p) in customers.links" :key="p">
                        <Link v-if="link.url" :href="link.url" :class="['px-3 py-1 rounded border text-sm', link.active ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-700 border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-600']" v-html="link.label"></Link>
                        <span v-else class="px-3 py-1 rounded border border-slate-300 dark:border-slate-600 bg-slate-100 dark:bg-slate-800 text-slate-400 text-sm cursor-not-allowed" v-html="link.label"></span>
                    </template>
                </div>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { reactive, computed } from 'vue';
import { router, Link } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';

const props = defineProps({
    stats: Object,
    capabilities: Object,
    customers: Object,
    areas: Array,
    packages: Array,
    filters: Object
});

const filter = reactive({
    search: new URLSearchParams(window.location.search).get('search') || '',
    area_id: new URLSearchParams(window.location.search).get('area_id') || '',
    package_id: new URLSearchParams(window.location.search).get('package_id') || '',
    status: new URLSearchParams(window.location.search).get('status') || '',
});

const hasFilters = computed(() => filter.search || filter.area_id || filter.package_id || filter.status);

const applyFilters = () => {
    let query = {};
    if (filter.search) query.search = filter.search;
    if (filter.area_id) query.area_id = filter.area_id;
    if (filter.package_id) query.package_id = filter.package_id;
    if (filter.status) query.status = filter.status;
    
    router.get(route('dashboard'), query, { preserveState: true });
};

const resetFilters = () => {
    filter.search = '';
    filter.area_id = '';
    filter.package_id = '';
    filter.status = '';
    router.get(route('dashboard'));
};

const formatNumber = (num) => {
    if (!num) return '0';
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
};
</script>
