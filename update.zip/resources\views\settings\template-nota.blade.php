@extends('layouts.app')
@section('title', 'Template Nota Digital')
@section('content')
<div style="margin-bottom:20px;"><h1 style="font-size:22px; font-weight:700;">🧾 Template Nota Digital</h1><p style="color:var(--text-muted); font-size:14px;">Konfigurasi format nota untuk WhatsApp blast</p></div>
@if(session('success'))<div class="alert-success">✅ {{ session('success') }}</div>@endif
<div class="card" style="padding:24px;">
    <p style="color:var(--text-muted); font-size:14px; margin-bottom:20px;">Template nota digital digunakan untuk format pesan WhatsApp saat mengirim tagihan ke pelanggan. Variabel yang tersedia: <code>{nama}</code>, <code>{paket}</code>, <code>{jumlah}</code>, <code>{periode}</code>.</p>
    <div style="padding:40px; text-align:center; background:var(--bg-body); border-radius:var(--radius); border:2px dashed var(--border);">
        <div style="font-size:48px; margin-bottom:16px;">📱</div>
        <h3 style="color:var(--text); margin-bottom:8px;">Segera Hadir</h3>
        <p style="color:var(--text-muted); font-size:14px;">Fitur konfigurasi template nota digital sedang dalam pengembangan.</p>
    </div>
</div>
@endsection
@push('styles')<style>.alert-success{padding:12px 16px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:10px;color:#22c55e;margin-bottom:16px;font-size:14px}.card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow-sm)}code{background:rgba(99,102,241,.15);padding:2px 6px;border-radius:4px;font-size:13px;color:#a5b4fc}</style>@endpush
