@extends('layouts.config')
@section('page-title')
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
Log Sistem
@endsection
@section('content')
<div class="cfg-card">
    <div class="cfg-card-title">📋 Log Aktivitas (200 terakhir)</div>
    <div style="max-height:70vh;overflow:auto">
        <table class="cfg-table">
            <thead><tr><th style="width:160px">Waktu</th><th>User</th><th>Aksi</th><th>Detail</th></tr></thead>
            <tbody>
                @forelse($logs as $log)
                <tr>
                    <td style="font-size:.75rem;color:var(--text-muted);white-space:nowrap">{{ \Carbon\Carbon::parse($log->created_at)->format('d M Y H:i:s') }}</td>
                    <td style="font-weight:500">{{ $log->user_name ?? $log->username ?? '-' }}</td>
                    <td><code>{{ $log->action ?? $log->event ?? '-' }}</code></td>
                    <td style="font-size:.78rem;color:var(--text-secondary);max-width:300px;overflow:hidden;text-overflow:ellipsis">{{ Str::limit($log->description ?? $log->details ?? '-', 100) }}</td>
                </tr>
                @empty
                <tr><td colspan="4" style="text-align:center;color:var(--text-muted)">Belum ada log.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
