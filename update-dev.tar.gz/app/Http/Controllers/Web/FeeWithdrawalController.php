<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FeeWithdrawal;
use App\Models\Payment;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class FeeWithdrawalController extends Controller
{
    public function index(Request $request)
    {
        $tenantId = session('tenant_id', $request->user()->tenant_id);
        $bulan = $request->input('bulan', date('Y-m'));

        // Withdrawals list
        $withdrawals = FeeWithdrawal::where('tenant_id', $tenantId)
            ->where('periode', $bulan)
            ->with(['user', 'processor'])
            ->orderByDesc('id')
            ->get();

        // Rekap Fee Sales & Kolektor bulan tersebut yang belum ditarik
        $start = Carbon::parse($bulan . '-01')->startOfMonth();
        $end = Carbon::parse($bulan . '-01')->endOfMonth();

        // Total fee yang sudah dicairkan per user di bulan tsb
        $withdrawnTotals = FeeWithdrawal::where('tenant_id', $tenantId)
            ->where('periode', $bulan)
            ->where('status', 'completed')
            ->groupBy('user_id')
            ->selectRaw('user_id, SUM(amount) as total')
            ->pluck('total', 'user_id');

        // Sales fee
        $salesFees = Payment::where('tenant_id', $tenantId)
            ->whereBetween('payment_date', [$start, $end])
            ->where('status', 'paid')
            ->whereNotNull('sales_id')
            ->groupBy('sales_id')
            ->selectRaw('sales_id as user_id, SUM(sales_fee_amount) as total_fee')
            ->get();

        // Collector fee
        $collectorFees = Payment::where('tenant_id', $tenantId)
            ->whereBetween('payment_date', [$start, $end])
            ->where('status', 'paid')
            ->whereNotNull('collected_by')
            ->groupBy('collected_by')
            ->selectRaw('collected_by as user_id, SUM(collector_fee_amount) as total_fee')
            ->get();

        // Gabungkan fee per user
        $userFees = [];
        foreach ($salesFees as $sf) {
            if (!isset($userFees[$sf->user_id])) {
                $userFees[$sf->user_id] = ['sales' => 0, 'collector' => 0, 'withdrawn' => 0];
            }
            $userFees[$sf->user_id]['sales'] += $sf->total_fee;
        }
        foreach ($collectorFees as $cf) {
            if (!isset($userFees[$cf->user_id])) {
                $userFees[$cf->user_id] = ['sales' => 0, 'collector' => 0, 'withdrawn' => 0];
            }
            $userFees[$cf->user_id]['collector'] += $cf->total_fee;
        }

        foreach ($userFees as $userId => &$fee) {
            $fee['withdrawn'] = $withdrawnTotals[$userId] ?? 0;
            $fee['total'] = $fee['sales'] + $fee['collector'];
            $fee['sisa'] = $fee['total'] - $fee['withdrawn'];
            $fee['user'] = User::find($userId);
        }

        return Inertia::render('Finance/FeeWithdrawals', compact('withdrawals', 'userFees', 'bulan'));
    }

    public function store(Request $request)
    {
        $tenantId = session('tenant_id', $request->user()->tenant_id);

        $request->validate([
            'user_id' => 'required|exists:users,id',
            'periode' => 'required',
            'amount' => 'required|numeric|min:1',
            'notes' => 'nullable|string'
        ]);

        FeeWithdrawal::create([
            'tenant_id' => $tenantId,
            'user_id' => $request->user_id,
            'periode' => $request->periode,
            'amount' => $request->amount,
            'status' => 'completed',
            'notes' => $request->notes,
            'processed_by' => $request->user()->id,
            'processed_at' => now(),
        ]);

        return back()->with('success', 'Pencairan fee berhasil dicatat.');
    }

    public function destroy(FeeWithdrawal $feeWithdrawal)
    {
        $feeWithdrawal->delete();
        return back()->with('success', 'Pencairan fee dibatalkan.');
    }
}
