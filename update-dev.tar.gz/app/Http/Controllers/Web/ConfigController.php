<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\Router;
use App\Models\RouterConfigBackup;
use App\Models\Server;
use App\Models\User;
use App\Services\MikroTik\RouterConfigService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;

class ConfigController extends Controller
{
    /** All can_* permission keys in our roles table */
    private array $permKeys = [
        // Dashboard
        'can_view_dashboard', 'can_view_dashboard_config', 'can_view_dashboard_map',
        // Customer
        'can_input_customer', 'can_edit_customer', 'can_delete_customer',
        'can_import_customer', 'can_export_customer', 'can_view_all_customers',
        // Visibility
        'view_by_area', 'view_by_sales', 'view_own_only',
        // Payment
        'can_process_payment', 'can_cancel_payment', 'can_view_payment_history',
        // Isolir & Cuti
        'can_manage_isolir', 'can_auto_isolir_config', 'can_cuti', 'can_manage_cuti',
        // Finance
        'can_view_reports', 'can_view_finance', 'can_manage_expenses',
        'can_manage_deposits', 'can_deduct_balance', 'can_delete_finance',
        'can_use_deposit',
        // Master Data
        'can_manage_packages', 'can_manage_areas', 'can_manage_odp',
        'can_manage_routers', 'can_manage_servers',
        // Admin
        'can_manage_users', 'can_manage_roles', 'can_view_audit_logs',
        'can_manage_config', 'can_backup_restore', 'can_edit_template',
        // Teknikal
        'can_access_mikrotik', 'can_access_radius', 'can_manage_pppoe',
        // Komunikasi & Map
        'can_send_wa_blast', 'can_view_map', 'can_view_monitor',
        // Module Access
        'can_access_billing', 'can_access_config', 'can_access_db', 'can_access_map',
    ];

    /** Redirect to first config page */
    public function index()
    {
        return redirect()->route('config.users');
    }

    // ==================== USERS ====================

    public function users()
    {
        $users = User::with('role')
            ->where(function ($q) {
                $q->where('is_system_admin', false)->orWhereNull('is_system_admin');
            })
            ->orderBy('name')
            ->get();
        $roles = Role::orderBy('name')->get();
        return Inertia::render('Settings/Users', compact('users', 'roles'));
    }

    public function storeUser(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:100',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
            'password' => 'required|string|min:6',
            'role_id' => 'required|exists:roles,id',
        ]);

        $data['uuid'] = (string) Str::uuid();
        $data['password'] = Hash::make($data['password']);
        $data['is_active'] = true;
        $data['tenant_id'] = session('tenant_id');

        User::create($data);
        return back()->with('success', "User {$data['name']} berhasil ditambahkan.");
    }

    public function updateUser(Request $request, User $targetUser)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:100',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
            'password' => 'nullable|string|min:6',
            'role_id' => 'required|exists:roles,id',
        ]);

        if (!empty($data['password'])) {
            $data['password'] = Hash::make($data['password']);
        } else {
            unset($data['password']);
        }

        $targetUser->update($data);
        return back()->with('success', "User {$targetUser->name} berhasil diperbarui.");
    }

    public function setDefaultSales(User $targetUser)
    {
        User::where('tenant_id', $targetUser->tenant_id)->update(['is_default_sales' => false]);
        $targetUser->update(['is_default_sales' => true]);
        return back()->with('success', "{$targetUser->name} berhasil diatur sebagai Penanggung Jawab Default.");
    }

    public function toggleUser(User $targetUser)
    {
        $targetUser->update(['is_active' => !$targetUser->is_active]);
        $status = $targetUser->is_active ? 'diaktifkan' : 'dinonaktifkan';
        return back()->with('success', "{$targetUser->name} berhasil {$status}.");
    }

    // ==================== ROLES ====================

    public function roles()
    {
        $roles = Role::withCount('users')
            ->orderBy('name')
            ->get();
        return Inertia::render('Settings/Router', compact('roles'));
    }

    public function storeRole(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
        ]);

        $data = [
            'tenant_id' => session('tenant_id'),
            'name' => $request->name,
            'description' => $request->description,
        ];

        foreach ($this->permKeys as $key) {
            $data[$key] = $request->boolean($key);
        }

        Role::create($data);
        return back()->with('success', 'Role berhasil ditambahkan.');
    }

    public function updateRole(Request $request, Role $role)
    {
        $data = [
            'name' => $request->input('name', $role->name),
            'description' => $request->input('description', $role->description),
        ];

        foreach ($this->permKeys as $key) {
            if ($request->has($key)) {
                $data[$key] = (bool) $request->input($key);
            }
        }

        $role->update($data);
        return response()->json(['status' => 'success', 'message' => 'Role berhasil diperbarui.']);
    }

    public function destroyRole(Role $role)
    {
        if ($role->users()->count() > 0) {
            return response()->json(['status' => 'error', 'message' => 'Role masih dipakai oleh ' . $role->users()->count() . ' user.'], 400);
        }

        $role->delete();
        return response()->json(['status' => 'success', 'message' => 'Role berhasil dihapus.']);
    }

    // ==================== SETTING NOTA ====================

    public function settingNota()
    {
        $configs = DB::table('configs')
            ->whereIn('key', ['nota_company_name', 'nota_company_address', 'nota_company_phone', 'nota_footer_text'])
            ->pluck('value', 'key');
        return Inertia::render('Settings/TemplateNota', compact('configs'));
    }

    public function updateSettingNota(Request $request)
    {
        $allowedKeys = [
            'nota_header', 'nota_title', 'nota_support_by', 'nota_footer',
            'nota_width_mm', 'nota_font_size', 'ppn_pct',
            'company_nama', 'company_alamat', 'company_telepon', 'company_nomer_cs',
            'company_terms', 'company_payment_info',
            'template_sebelum', 'template_sesudah',
            'receipt_tpl_sebelum', 'receipt_tpl_sesudah',
            'wa_gateway_url', 'wa_gateway_device_id', 'wa_gateway_auth_user',
            'wa_gateway_auth_pass', 'wa_gateway_timeout', 'wa_gateway_enabled',
        ];

        foreach ($allowedKeys as $key) {
            if ($request->has($key)) {
                DB::table('billing_configs')->updateOrInsert(
                    ['tenant_id' => session('tenant_id'), 'key' => $key],
                    ['value' => $request->input($key, '')]
                );
            }
        }

        return response()->json(['status' => 'success', 'message' => 'Pengaturan berhasil disimpan.']);
    }
    public function dbPusat()
    {
        $configs = DB::table('billing_configs')
            ->where('tenant_id', session('tenant_id'))
            ->whereIn('key', [
                'db_pusat_software', 'db_pusat_sync_method', 'db_pusat_auth_type', 
                'db_pusat_url', 'db_pusat_token', 'db_pusat_username', 'db_pusat_password', 'db_pusat_type'
            ])
            ->pluck('value', 'key');
        return Inertia::render('Settings/DbPusat', compact('configs'));
    }

    public function updateDbPusat(Request $request)
    {
        $allowedKeys = [
            'db_pusat_software', 'db_pusat_sync_method', 'db_pusat_auth_type', 
            'db_pusat_url', 'db_pusat_token', 'db_pusat_username', 'db_pusat_password', 'db_pusat_type'
        ];

        foreach ($allowedKeys as $key) {
            if ($request->has($key)) {
                DB::table('billing_configs')->updateOrInsert(
                    ['tenant_id' => session('tenant_id'), 'key' => $key],
                    ['value' => $request->input($key, '')]
                );
            }
        }

        // Jalankan Pull setelah konfig disimpan
        try {
            $service = new \App\Services\DbPusatService();
            $service->pullPackages();
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error("Failed to pull packages on config update: " . $e->getMessage());
        }

        return back()->with('success', 'Pengaturan DB Pusat berhasil disimpan & Data Profil ditarik.');
    }

    // ==================== WA GATEWAY ====================

    public function waGateway()
    {
        $configs = DB::table('configs')
            ->whereIn('key', ['wa_gateway_url', 'wa_api_key', 'wa_sender_number', 'wa_message_template_tagihan', 'wa_message_template_lunas'])
            ->pluck('value', 'key');
        return Inertia::render('Settings/WaGateway', compact('configs'));
    }

    // ==================== CONFIG ROUTER ====================

    public function router()
    {
        $routers = Router::orderBy('name')
            ->get()
            ->map(function ($r) {
                return [
                    'id' => $r->id,
                    'name' => $r->name,
                    'host' => $r->host,
                    'port' => $r->port,
                    'ftp_port' => $r->ftp_port ?? 21,
                    'username' => $r->username,
                    'is_active' => $r->is_active,
                    'use_ssl' => $r->use_ssl,
                    'auto_backup' => $r->auto_backup,
                    'use_radius' => $r->use_radius,
                    'radius_secret_masked' => $r->radius_secret
                        ? '***' . substr($r->getDecryptedRadiusSecret() ?? '', -4)
                        : null,
                    'description' => $r->description,
                ];
            });

        if (request()->wantsJson()) {
            return response()->json(['status' => 'success', 'data' => $routers]);
        }

        return Inertia::render('Settings/Router', compact('routers'));
    }

    public function storeRouter(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'host' => 'required|string|max:255',
            'username' => 'required|string|max:100',
            'password' => 'required|string',
            'port' => 'required|integer|min:1|max:65535',
            'ftp_port' => 'nullable|integer|min:1|max:65535',
            'auto_backup' => 'nullable|boolean',
            'use_radius' => 'nullable|boolean',
            'radius_secret' => 'nullable|string',
        ]);

        if ($request->boolean('use_radius') && empty($data['radius_secret'])) {
            return response()->json(['status' => 'error', 'message' => 'RADIUS Secret wajib diisi jika FreeRADIUS aktif.'], 422);
        }

        $data['tenant_id'] = session('tenant_id');
        $data['ftp_port'] = $data['ftp_port'] ?? 21;
        $data['auto_backup'] = $request->boolean('auto_backup');
        $data['use_radius'] = $request->boolean('use_radius');
        $data['is_active'] = true;

        Router::create($data);
        return response()->json(['status' => 'success', 'message' => 'Router berhasil ditambahkan.']);
    }

    public function updateRouter(Request $request, Router $router)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'host' => 'required|string|max:255',
            'username' => 'required|string|max:100',
            'password' => 'nullable|string',
            'port' => 'required|integer|min:1|max:65535',
            'ftp_port' => 'nullable|integer|min:1|max:65535',
            'auto_backup' => 'nullable|boolean',
            'use_radius' => 'nullable|boolean',
            'radius_secret' => 'nullable|string',
        ]);

        if ($request->boolean('use_radius') && empty($data['radius_secret'])) {
            return response()->json(['status' => 'error', 'message' => 'RADIUS Secret wajib diisi jika FreeRADIUS aktif.'], 422);
        }

        // Don't update password if not provided
        if (empty($data['password'])) {
            unset($data['password']);
        }

        $data['ftp_port'] = $data['ftp_port'] ?? 21;
        $data['auto_backup'] = $request->boolean('auto_backup');
        $data['use_radius'] = $request->boolean('use_radius');

        if (!$data['use_radius']) {
            $data['radius_secret'] = null;
        }

        $router->update($data);
        return response()->json(['status' => 'success', 'message' => 'Router berhasil diperbarui.']);
    }

    public function destroyRouter(Router $router)
    {
        if ($router->customers()->count() > 0) {
            return response()->json([
                'status' => 'error',
                'message' => 'Router masih dipakai oleh ' . $router->customers()->count() . ' pelanggan.'
            ], 400);
        }

        $router->delete();
        return response()->json(['status' => 'success', 'message' => 'Router berhasil dihapus.']);
    }

    public function toggleRouter(Router $router)
    {
        $router->update(['is_active' => !$router->is_active]);
        $status = $router->is_active ? 'diaktifkan' : 'dinonaktifkan';
        return response()->json(['status' => 'success', 'message' => "Router berhasil {$status}."]);
    }

    public function testRouter(Router $router)
    {
        try {
            $apiFile = app_path('Services/MikroTik/RouterosAPI.php');
            if (!file_exists($apiFile)) {
                return response()->json(['status' => 'error', 'message' => 'RouterOS API library tidak ditemukan.']);
            }
            require_once $apiFile;

            $host = $router->host;
            $port = $router->port;
            $username = $router->username;
            $password = $router->getDecryptedPassword();

            $API = new \RouterosAPI();
            $API->port = $port;
            $API->timeout = 10;
            $API->attempts = 1;

            if (!$API->connect($host, $username, $password)) {
                return response()->json([
                    'status' => 'error',
                    'message' => "Gagal terhubung ke \"{$router->name}\" ({$host}:{$port}). Cek host, port, username, atau password.",
                ]);
            }

            // Fetch identity
            $identity = '(unknown)';
            try {
                $res = $API->comm('/system/identity/print');
                if (is_array($res) && isset($res[0]['name'])) {
                    $identity = $res[0]['name'];
                }
            } catch (\Throwable $e) {
                // Identity fetch failed, not critical
            }

            $API->disconnect();

            return response()->json([
                'status' => 'success',
                'message' => "Koneksi ke \"{$router->name}\" ({$host}:{$port}) berhasil. Identity: {$identity}",
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Error: {$e->getMessage()}",
            ]);
        }
    }

    public function getRouterConfig(Router $router)
    {
        try {
            $apiFile = app_path('Services/MikroTik/RouterosAPI.php');
            require_once $apiFile;

            $host = $router->host;
            $port = $router->port;
            $ftpPort = $router->ftp_port ?? 21;
            $username = $router->username;
            $password = $router->getDecryptedPassword();

            $configLines = [];
            $debug = [];

            // ─── Strategy 1: FTP export (export to file → download via FTP) ───
            try {
                $fname = 'laravel_cfg_' . time();
                $remoteRsc = $fname . '.rsc';

                // Step 1: Tell router to export to file via API
                $API = new \RouterosAPI();
                $API->port = $port;
                $API->timeout = 15;
                $API->attempts = 1;

                if ($API->connect($host, $username, $password)) {
                    try {
                        $API->comm('/export', ['file' => $fname, 'show-sensitive' => '']);
                        usleep(2000000); // 2s wait for file write
                    } finally {
                        $API->disconnect();
                    }

                    // Step 2: Download via FTP
                    $content = null;

                    // Try ftp_connect first
                    $ftp = @ftp_connect($host, $ftpPort, 10);
                    if ($ftp && @ftp_login($ftp, $username, $password)) {
                        @ftp_set_option($ftp, FTP_TIMEOUT_SEC, 20);

                        foreach ([true, false] as $pasv) {
                            @ftp_pasv($ftp, $pasv);
                            $tmp = tempnam(sys_get_temp_dir(), 'mtk_');
                            $paths = [$remoteRsc, './' . $remoteRsc, 'flash/' . $remoteRsc];
                            foreach ($paths as $p) {
                                if (@ftp_get($ftp, $tmp, $p, FTP_ASCII)) {
                                    $content = @file_get_contents($tmp);
                                    @unlink($tmp);
                                    break 2;
                                }
                            }
                            @unlink($tmp);
                        }

                        // Try listing if direct paths failed
                        if ($content === null || $content === false) {
                            $list = @ftp_nlist($ftp, '.') ?: @ftp_nlist($ftp, '');
                            if (is_array($list)) {
                                foreach ($list as $f) {
                                    if (basename($f) === $remoteRsc || stripos(basename($f), $fname) !== false) {
                                        $tmp = tempnam(sys_get_temp_dir(), 'mtk_');
                                        if (@ftp_get($ftp, $tmp, $f, FTP_ASCII)) {
                                            $content = @file_get_contents($tmp);
                                        }
                                        @unlink($tmp);
                                        break;
                                    }
                                }
                            }
                        }

                        // Clean up file from router
                        @ftp_delete($ftp, $remoteRsc);
                        @ftp_close($ftp);
                    }

                    // Try stream wrapper if ftp_connect failed
                    if (($content === null || $content === false) && $ftpPort) {
                        $encUser = rawurlencode($username);
                        $encPass = rawurlencode($password);
                        $streamUrl = "ftp://{$encUser}:{$encPass}@{$host}:{$ftpPort}/{$remoteRsc}";
                        $ctx = stream_context_create(['ftp' => ['request_fulluri' => true]]);
                        $content = @file_get_contents($streamUrl, false, $ctx);
                    }

                    if ($content !== null && $content !== false && strlen(trim($content)) > 10) {
                        // Filter: only keep /ip pool, /ppp profile, /ppp secret sections
                        $allLines = explode("\n", $content);
                        $allowedSections = ['/ip pool', '/ppp profile', '/ppp secret'];
                        $inSection = false;
                        foreach ($allLines as $line) {
                            $trimmed = rtrim($line);
                            // Detect section header (starts with / at beginning of line)
                            if ($trimmed !== '' && $trimmed[0] === '/') {
                                $inSection = false;
                                foreach ($allowedSections as $sec) {
                                    if (str_starts_with($trimmed, $sec)) {
                                        $inSection = true;
                                        $configLines[] = $trimmed;
                                        break;
                                    }
                                }
                            } elseif ($inSection && $trimmed !== '') {
                                $configLines[] = $trimmed;
                            } elseif ($inSection && $trimmed === '' && !empty($configLines)) {
                                // Blank line within section, keep it
                            }
                        }
                        $debug[] = 'FTP OK lines=' . count($configLines);
                    } else {
                        $debug[] = 'FTP download empty/failed';
                    }

                    // Clean up file from router via API
                    if (!empty($configLines)) {
                        try {
                            $API2 = new \RouterosAPI();
                            $API2->port = $port;
                            $API2->timeout = 5;
                            $API2->attempts = 1;
                            if ($API2->connect($host, $username, $password)) {
                                @$API2->comm('/file/remove', ['=numbers' => $remoteRsc]);
                                $API2->disconnect();
                            }
                        } catch (\Throwable $e) {}
                    }
                } else {
                    $debug[] = 'API connect failed';
                }
            } catch (\Throwable $e) {
                $debug[] = 'FTP error: ' . $e->getMessage();
            }

            // ─── Strategy 2: API /print → format as export ───
            if (empty($configLines)) {
                try {
                    $API3 = new \RouterosAPI();
                    $API3->port = $port;
                    $API3->timeout = 30;
                    $API3->attempts = 1;

                    if ($API3->connect($host, $username, $password)) {
                        $sections = [
                            [
                                'label' => '/ip pool',
                                'cmd' => '/ip/pool/print',
                                'proplist' => '',
                                'skip' => ['.id', '.nextid', 'dynamic'],
                            ],
                            [
                                'label' => '/ppp profile',
                                'cmd' => '/ppp/profile/print',
                                'proplist' => '',
                                'skip' => ['.id', '.nextid', 'dynamic', 'default'],
                            ],
                            [
                                'label' => '/ppp secret',
                                'cmd' => '/ppp/secret/print',
                                'proplist' => 'name,password,profile,service,local-address,remote-address,comment,disabled',
                                'skip' => ['.id', '.nextid', 'dynamic'],
                            ],
                        ];

                        foreach ($sections as $sec) {
                            try {
                                $args = [];
                                if (!empty($sec['proplist'])) {
                                    $args['.proplist'] = $sec['proplist'];
                                }
                                $res = $API3->comm($sec['cmd'], $args);

                                if (is_array($res) && !empty($res) && !isset($res['!trap'])) {
                                    $configLines[] = $sec['label'];
                                    foreach ($res as $entry) {
                                        if (!is_array($entry)) continue;
                                        $parts = [];
                                        foreach ($entry as $k => $v) {
                                            if (in_array($k, $sec['skip'])) continue;
                                            if ($v === '' || $v === 'false') continue;
                                            // Quote values containing spaces or special chars
                                            if (str_contains($v, ' ') || str_contains($v, '=') || str_contains($v, '"') || str_contains($v, ',')) {
                                                $parts[] = "{$k}=\"{$v}\"";
                                            } else {
                                                $parts[] = "{$k}={$v}";
                                            }
                                        }
                                        if (!empty($parts)) {
                                            $configLines[] = 'add ' . implode(' ', $parts);
                                        }
                                    }
                                    $configLines[] = '';
                                }
                            } catch (\Throwable $e) {
                                $debug[] = "Section {$sec['label']} error: " . $e->getMessage();
                            }
                        }
                        $debug[] = 'Print lines=' . count($configLines);
                        $API3->disconnect();
                    }
                } catch (\Throwable $e) {
                    $debug[] = 'Print error: ' . $e->getMessage();
                }
            }

            if (!empty($configLines)) {
                return response()->json(['status' => 'success', 'config' => implode("\n", $configLines)]);
            }

            return response()->json([
                'status' => 'error',
                'message' => "Export gagal. Debug: " . implode(' | ', $debug),
            ]);
        } catch (\Throwable $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function backupRouter(Router $router)
    {
        try {
            $apiFile = app_path('Services/MikroTik/RouterosAPI.php');
            require_once $apiFile;

            $host = $router->host;
            $port = $router->port;
            $ftpPort = $router->ftp_port ?? 21;
            $username = $router->username;
            $password = $router->getDecryptedPassword();

            $config = null;

            // ─── FTP full export ───
            $fname = 'backup_' . $router->id . '_' . time();
            $remoteRsc = $fname . '.rsc';

            $API = new \RouterosAPI();
            $API->port = $port;
            $API->timeout = 15;
            $API->attempts = 1;

            if ($API->connect($host, $username, $password)) {
                try {
                    $API->comm('/export', ['file' => $fname, 'show-sensitive' => '']);
                    usleep(3000000); // 3s wait
                } finally {
                    $API->disconnect();
                }

                // Download via FTP
                $content = null;
                $ftp = @ftp_connect($host, $ftpPort, 10);
                if ($ftp && @ftp_login($ftp, $username, $password)) {
                    @ftp_set_option($ftp, FTP_TIMEOUT_SEC, 30);
                    foreach ([true, false] as $pasv) {
                        @ftp_pasv($ftp, $pasv);
                        $tmp = tempnam(sys_get_temp_dir(), 'mtk_');
                        foreach ([$remoteRsc, './' . $remoteRsc, 'flash/' . $remoteRsc] as $p) {
                            if (@ftp_get($ftp, $tmp, $p, FTP_ASCII)) {
                                $content = @file_get_contents($tmp);
                                @unlink($tmp);
                                break 2;
                            }
                        }
                        @unlink($tmp);
                    }
                    @ftp_delete($ftp, $remoteRsc);
                    @ftp_close($ftp);
                }

                // Stream wrapper fallback
                if (($content === null || $content === false) && $ftpPort) {
                    $encUser = rawurlencode($username);
                    $encPass = rawurlencode($password);
                    $content = @file_get_contents("ftp://{$encUser}:{$encPass}@{$host}:{$ftpPort}/{$remoteRsc}");
                }

                if ($content && strlen(trim($content)) > 10) {
                    $config = $content;
                }

                // Cleanup file on router
                try {
                    $API2 = new \RouterosAPI();
                    $API2->port = $port;
                    $API2->timeout = 5;
                    $API2->attempts = 1;
                    if ($API2->connect($host, $username, $password)) {
                        @$API2->comm('/file/remove', ['=numbers' => $remoteRsc]);
                        $API2->disconnect();
                    }
                } catch (\Throwable $e) {}
            }

            // ─── Fallback: API /print ───
            if (!$config) {
                $API3 = new \RouterosAPI();
                $API3->port = $port;
                $API3->timeout = 30;
                $API3->attempts = 1;
                if ($API3->connect($host, $username, $password)) {
                    $lines = [];
                    $sections = [
                        ['/ip pool', '/ip/pool/print', ''],
                        ['/ppp profile', '/ppp/profile/print', ''],
                        ['/ppp secret', '/ppp/secret/print', 'name,password,profile,service,local-address,remote-address,comment,disabled'],
                    ];
                    $skip = ['.id', '.nextid', 'dynamic'];
                    foreach ($sections as [$label, $cmd, $proplist]) {
                        try {
                            $args = $proplist ? ['.proplist' => $proplist] : [];
                            $res = $API3->comm($cmd, $args);
                            if (is_array($res) && !empty($res) && !isset($res['!trap'])) {
                                $lines[] = $label;
                                foreach ($res as $entry) {
                                    if (!is_array($entry)) continue;
                                    $parts = [];
                                    foreach ($entry as $k => $v) {
                                        if (in_array($k, $skip) || $v === '' || $v === 'false') continue;
                                        $parts[] = str_contains($v, ' ') || str_contains($v, ',') ? "{$k}=\"{$v}\"" : "{$k}={$v}";
                                    }
                                    if ($parts) $lines[] = 'add ' . implode(' ', $parts);
                                }
                                $lines[] = '';
                            }
                        } catch (\Throwable $e) {}
                    }
                    $API3->disconnect();
                    if (!empty($lines)) $config = implode("\n", $lines);
                }
            }

            if (!$config) {
                return response()->json(['status' => 'error', 'message' => 'Gagal mengambil config dari router.']);
            }

            // Get router identity
            $identity = '';
            try {
                $APIid = new \RouterosAPI();
                $APIid->port = $port;
                $APIid->timeout = 5;
                $APIid->attempts = 1;
                if ($APIid->connect($host, $username, $password)) {
                    $res = $APIid->comm('/system/identity/print');
                    if (is_array($res) && isset($res[0]['name'])) {
                        $identity = $res[0]['name'];
                    }
                    $APIid->disconnect();
                }
            } catch (\Throwable $e) {}

            // Save backup
            $configName = $router->name . '-' . ($identity ?: 'unknown') . ' (' . now()->format('H:i/d-m-Y') . ')';
            $backup = RouterConfigBackup::create([
                'router_id' => $router->id,
                'config_name' => $configName,
                'config_text' => $config,
            ]);

            $router->update(['last_backup_at' => now()]);

            // ─── Rotation: max 3, hapus yang lama ───
            $all = RouterConfigBackup::where('router_id', $router->id)
                ->orderByDesc('created_at')
                ->get();
            if ($all->count() > 3) {
                $toDelete = $all->slice(3);
                RouterConfigBackup::whereIn('id', $toDelete->pluck('id'))->delete();
            }

            return response()->json([
                'status' => 'success',
                'message' => "Backup \"{$configName}\" berhasil disimpan.",
                'id' => $backup->id,
                'config_name' => $backup->config_name,
            ]);
        } catch (\Throwable $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function downloadBackup(Router $router, RouterConfigBackup $backup)
    {
        if ($backup->router_id !== $router->id) {
            abort(404);
        }

        $filename = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $backup->config_name) . '.rsc';
        return response($backup->config_text, 200, [
            'Content-Type' => 'text/plain',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ]);
    }

    public function listRouterBackups(Router $router)
    {
        $backups = RouterConfigBackup::where('router_id', $router->id)
            ->orderByDesc('created_at')
            ->get(['id', 'router_id', 'config_name', 'created_at']);

        return response()->json(['status' => 'success', 'data' => $backups]);
    }

    public function restoreRouterBackup(Router $router, RouterConfigBackup $backup)
    {
        if ($backup->router_id !== $router->id) {
            return response()->json(['status' => 'error', 'message' => 'Backup tidak cocok dengan router.'], 400);
        }

        return response()->json([
            'status' => 'success',
            'config' => $backup->config_text,
            'config_name' => $backup->config_name,
        ]);
    }

    // ==================== CONFIG SERVER GENIACS ====================

    public function server()
    {
        $servers = Server::where('type', 'geniacs')
            ->orderBy('name')
            ->get()
            ->map(function ($s) {
                return [
                    'id' => $s->id,
                    'name' => $s->name,
                    'host' => $s->host,
                    'port' => $s->port,
                    'username' => $s->username,
                    'is_active' => $s->is_active,
                ];
            });

        if (request()->wantsJson()) {
            return response()->json(['status' => 'success', 'data' => $servers]);
        }

        return Inertia::render('Settings/Server', compact('servers'));
    }

    public function storeServer(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'host' => 'required|string|max:255',
            'port' => 'required|integer|min:1|max:65535',
            'username' => 'nullable|string|max:100',
            'password' => 'nullable|string',
        ]);

        $data['tenant_id'] = session('tenant_id');
        $data['type'] = 'geniacs';
        $data['is_active'] = true;
        // Set required fields for server table that may have NOT NULL constraints
        $data['db_name'] = $data['db_name'] ?? 'geniacs';
        $data['db_username'] = $data['db_username'] ?? '';
        $data['db_password'] = $data['db_password'] ?? 'none';

        Server::create($data);
        return response()->json(['status' => 'success', 'message' => 'Server berhasil ditambahkan.']);
    }

    public function updateServer(Request $request, Server $server)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'host' => 'required|string|max:255',
            'port' => 'required|integer|min:1|max:65535',
            'username' => 'nullable|string|max:100',
            'password' => 'nullable|string',
        ]);

        // Don't update password if not provided
        if (empty($data['password'])) {
            unset($data['password']);
        }

        $server->update($data);
        return response()->json(['status' => 'success', 'message' => 'Server berhasil diperbarui.']);
    }

    public function destroyServer(Server $server)
    {
        $server->delete();
        return response()->json(['status' => 'success', 'message' => 'Server berhasil dihapus.']);
    }

    public function toggleServer(Server $server)
    {
        $server->update(['is_active' => !$server->is_active]);
        $status = $server->is_active ? 'diaktifkan' : 'dinonaktifkan';
        return response()->json(['status' => 'success', 'message' => "Server berhasil {$status}."]);
    }

    public function testServer(Server $server)
    {
        try {
            $host = $server->host;
            $port = $server->port;
            $timeout = 5;

            $connection = @fsockopen($host, $port, $errno, $errstr, $timeout);
            if ($connection) {
                fclose($connection);
                return response()->json([
                    'status' => 'success',
                    'message' => "Koneksi ke \"{$server->name}\" ({$host}:{$port}) berhasil.",
                ]);
            }

            return response()->json([
                'status' => 'error',
                'message' => "Gagal terhubung ke \"{$server->name}\" ({$host}:{$port}): {$errstr}",
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'status' => 'error',
                'message' => "Error: {$e->getMessage()}",
            ]);
        }
    }

    // ==================== BACKUP ====================

    public function backup()
    {
        return Inertia::render('Settings/Backup');
    }

    // ==================== LOG SISTEM ====================

    public function logSistem()
    {
        $logs = DB::table('audit_logs')
            ->where('tenant_id', session('tenant_id'))
            ->orderByDesc('created_at')
            ->limit(200)
            ->get();
        return Inertia::render('Settings/LogSistem', compact('logs'));
    }

    public function radiusServer()
    {
        $servers = Server::whereIn('type', ['freeradius', 'daloradius_api', 'radiusdesk_api'])
            ->orderBy('name')
            ->get()
            ->map(function ($s) {
                return [
                    'id' => $s->id,
                    'name' => $s->name,
                    'type' => $s->type,
                    'host' => $s->host,
                    'port' => $s->port,
                    'db_name' => $s->db_name,
                    'username' => $s->username,
                    'api_endpoint' => $s->api_endpoint,
                    'has_api_token' => !empty($s->api_token),
                    'is_active' => $s->is_active,
                    'routers_count' => Router::where('radius_server_id', $s->id)->count(),
                ];
            });

        if (request()->wantsJson()) {
            return response()->json(['status' => 'success', 'data' => $servers]);
        }
        return Inertia::render('Settings/RadiusServer');
    }

    public function storeRadiusServer(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'type' => 'required|in:freeradius,daloradius_api,radiusdesk_api',
            'host' => 'nullable|string|max:255',
            'port' => 'nullable|integer|min:1|max:65535',
            'db_name' => 'nullable|string|max:100',
            'username' => 'nullable|string|max:100',
            'db_password' => 'nullable|string',
            'api_endpoint' => 'nullable|string|max:255',
            'api_token' => 'nullable|string',
        ]);

        $data['tenant_id'] = session('tenant_id');
        $data['is_active'] = true;
        
        if ($data['type'] === 'freeradius') {
            $data['db_username'] = $data['username'] ?? '';
            $data['password'] = $data['db_password'] ?? 'none';
        } else {
            // Provide defaults for API so it doesn't violate NOT NULL constraints
            $data['host'] = $data['api_endpoint'] ?? 'api';
            $data['db_username'] = 'api_user';
            $data['password'] = 'none';
        }

        Server::create($data);
        return response()->json(['status' => 'success', 'message' => 'Server RADIUS berhasil ditambahkan.']);
    }

    public function updateRadiusServer(Request $request, Server $server)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'type' => 'required|in:freeradius,daloradius_api,radiusdesk_api',
            'host' => 'nullable|string|max:255',
            'port' => 'nullable|integer|min:1|max:65535',
            'db_name' => 'nullable|string|max:100',
            'username' => 'nullable|string|max:100',
            'db_password' => 'nullable|string',
            'api_endpoint' => 'nullable|string|max:255',
            'api_token' => 'nullable|string',
        ]);

        if (empty($data['db_password'])) unset($data['db_password']);
        if (empty($data['api_token'])) unset($data['api_token']);

        if ($data['type'] === 'freeradius') {
            $data['db_username'] = $data['username'] ?? '';
            if (isset($data['db_password'])) $data['password'] = $data['db_password'];
        } else {
            $data['host'] = $data['api_endpoint'] ?? 'api';
        }

        $server->update($data);
        return response()->json(['status' => 'success', 'message' => 'Server RADIUS berhasil diperbarui.']);
    }

    public function destroyRadiusServer(Server $server)
    {
        // Cek apakah ada router yang masih menggunakan server ini
        $routerCount = Router::where('radius_server_id', $server->id)->count();
        if ($routerCount > 0) {
            return response()->json([
                'status' => 'error',
                'message' => "Tidak bisa hapus — masih digunakan oleh {$routerCount} router.",
            ]);
        }

        $server->delete();
        return response()->json(['status' => 'success', 'message' => 'Server RADIUS berhasil dihapus.']);
    }

    public function toggleRadiusServer(Server $server)
    {
        $server->update(['is_active' => !$server->is_active]);
        $status = $server->is_active ? 'diaktifkan' : 'dinonaktifkan';
        return response()->json(['status' => 'success', 'message' => "Server RADIUS berhasil {$status}."]);
    }

    public function testRadiusServer(Server $server)
    {
        $radiusService = app(\App\Services\RadiusService::class);
        $result = $radiusService->testConnection($server);
        return response()->json($result);
    }
}
