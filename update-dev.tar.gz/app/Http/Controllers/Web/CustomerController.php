<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Area;
use App\Models\Package;
use App\Models\Router;
use App\Models\Server;
use App\Models\Odp;
use App\Models\User;
use App\Events\CustomerCreated;
use App\Models\CustomerCoordinate;
use App\Services\RadiusApiService;
use App\Services\RadiusService;
use App\Services\MikroTik\MikroTikService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class CustomerController extends Controller
{
    public function index(Request $request)
    {
        $query = Customer::with(['package', 'area'])->latest();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('username', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        $customers = $query->paginate(15)->withQueryString();

        return Inertia::render('Customers/Index', compact('customers'));
    }

    public function create(): Response
    {
        $areas = Area::orderBy('name')->get();
        $packages = Package::orderBy('name')->get();
        $routers = Router::where('is_active', true)->get();
        $servers = Server::where('is_active', true)->get();
        $odps = Odp::orderBy('name')->get();
        $users = User::where('is_active', true)->orderBy('name')->get();
        $defaultSalesId = User::where('is_active', true)->where('is_default_sales', true)->value('id');

        return Inertia::render('Customers/Create', compact('areas', 'packages', 'routers', 'servers', 'odps', 'users', 'defaultSalesId'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'username' => 'nullable|string|max:100',
            'password_pppoe' => 'nullable|string',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string',
            'package_id' => 'required|exists:packages,id',
            'area_id' => 'required|exists:areas,id',
            'router_id' => 'nullable|exists:routers,id',
            'server_id' => 'nullable|exists:servers,id',
            'odp_id' => 'nullable|exists:odps,id',
            'sales_id' => 'required|exists:users,id',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'jenis_bayar' => 'required|in:prabayar,pascabayar',
            'status' => 'required|in:active,inactive',
            'max_tunggakan' => 'required|integer|min:0|max:12',
            'diskon' => 'nullable|numeric|min:0',
            'tambahan_layanan' => 'nullable|numeric|min:0',
        ]);

        $validated['tenant_id'] = auth()->user()->tenant_id;
        $validated['auto_isolir'] = $request->boolean('auto_isolir');
        $validated['pakai_ppn'] = $request->boolean('pakai_ppn');
        $validated['auto_wa_tagihan'] = $request->boolean('auto_wa_tagihan');
        $validated['sync_db_pusat'] = $request->boolean('sync_db_pusat');

        $customer = Customer::create(collect($validated)->except(['latitude', 'longitude'])->toArray());

        if ($request->filled('latitude') || $request->filled('longitude')) {
            CustomerCoordinate::create([
                'customer_id' => $customer->id,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
            ]);
        }

        if ($request->boolean('create_pppoe')) {
            event(new CustomerCreated($customer, true));
        }

        if ($customer->sync_db_pusat) {
            app(RadiusApiService::class)->pushCustomer($customer);
        }

        return redirect()->route('customers.index')->with('success', 'Pelanggan berhasil ditambahkan.');
    }

    public function edit(Customer $customer)
    {
        $areas = Area::orderBy('name')->get();
        $packages = Package::orderBy('name')->get();
        $routers = Router::where('is_active', true)->get();
        $servers = Server::where('is_active', true)->get();
        $odps = Odp::orderBy('name')->get();
        $users = User::where('is_active', true)->orderBy('name')->get();
        $customer->load('coordinate');

        return Inertia::render('Customers/Edit', compact('customer', 'areas', 'packages', 'routers', 'servers', 'odps', 'users'));
    }

    public function update(Request $request, Customer $customer)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'username' => 'nullable|string|max:100',
            'password_pppoe' => 'nullable|string',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string',
            'package_id' => 'required|exists:packages,id',
            'area_id' => 'required|exists:areas,id',
            'router_id' => 'nullable|exists:routers,id',
            'server_id' => 'nullable|exists:servers,id',
            'odp_id' => 'nullable|exists:odps,id',
            'sales_id' => 'required|exists:users,id',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'jenis_bayar' => 'required|in:prabayar,pascabayar',
            'status' => 'required|in:active,inactive',
            'max_tunggakan' => 'required|integer|min:0|max:12',
        ]);

        $validated['auto_isolir'] = $request->boolean('auto_isolir');
        $validated['pakai_ppn'] = $request->boolean('pakai_ppn');
        $validated['auto_wa_tagihan'] = $request->boolean('auto_wa_tagihan');
        $validated['sync_db_pusat'] = $request->boolean('sync_db_pusat');

        $customer->update(collect($validated)->except(['latitude', 'longitude'])->toArray());

        if ($request->filled('latitude') || $request->filled('longitude')) {
            CustomerCoordinate::updateOrCreate(
                ['customer_id' => $customer->id],
                [
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude,
                ]
            );
        }

        if ($customer->sync_db_pusat) {
            app(RadiusApiService::class)->pushCustomer($customer);
        }

        return redirect()->route('customers.index')->with('success', 'Data pelanggan berhasil diperbarui.');
    }

    public function destroy(Customer $customer)
    {
        if ($customer->sync_db_pusat) {
            app(RadiusApiService::class)->deleteCustomer($customer);
        }
        $customer->delete();
        return redirect()->route('customers.index')->with('success', 'Pelanggan berhasil dihapus.');
    }

    public function show($id)
    {
        $customer = Customer::with(['package', 'area', 'router', 'server', 'odp', 'sales', 'coordinate'])->find($id);
        if (!$customer) {
            return redirect()->route('customers.index')->with('error', 'Customer not found');
        }

        return Inertia::render('Customers/Show', compact('customer'));
    }

    public function searchPppoeUsers()
    {
        $users = [];

        // 1. Fetch from FreeRADIUS
        $radiusServer = Server::where('type', 'freeradius')->where('is_active', true)->first();
        if ($radiusServer) {
            $radiusService = app(RadiusService::class);
            $radiusUsers = $radiusService->listUsers();
            foreach ($radiusUsers as $ru) {
                $users[] = [
                    'source' => 'FreeRADIUS DB',
                    'source_type' => 'radius',
                    'source_id' => $radiusServer->id,
                    'username' => $ru->username,
                    'password' => $ru->password,
                ];
            }
        }

        // 2. Fetch from active MikroTik Routers
        $mikrotikService = app(MikroTikService::class);
        $routers = Router::where('is_active', true)->get();
        foreach ($routers as $router) {
            $secrets = $mikrotikService->getPppoeSecrets($router);
            foreach ($secrets as $sec) {
                $users[] = [
                    'source' => 'MikroTik (' . $router->name . ')',
                    'source_type' => 'router',
                    'source_id' => $router->id,
                    'username' => $sec['name'] ?? '',
                    'password' => $sec['password'] ?? '',
                ];
            }
        }

        return response()->json(['status' => 'success', 'data' => $users]);
    }
}
