<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Expense;
use Carbon\Carbon;
use Inertia\Inertia;

class ExpenseController extends Controller
{
    protected $categories = [
        'Operasional', 'Marketing', 'Alat/Material', 'Pajak', 'Deviden', 'Lainnya'
    ];

    public function index(Request $request)
    {
        $tenantId = session('tenant_id', $request->user()->tenant_id);
        $bulan = $request->input('bulan', date('Y-m'));
        
        $start = Carbon::parse($bulan . '-01')->startOfMonth();
        $end = Carbon::parse($bulan . '-01')->endOfMonth();

        $query = Expense::where('tenant_id', $tenantId)
            ->whereBetween('expense_date', [$start, $end]);

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        $expenses = $query->orderByDesc('expense_date')->orderByDesc('id')->paginate(20);
        $total = $query->sum('amount');
        
        $categories = $this->categories;

        return Inertia::render('Finance/Expenses', compact('expenses', 'total', 'bulan', 'categories'));
    }

    public function store(Request $request)
    {
        $tenantId = session('tenant_id', $request->user()->tenant_id);

        $request->validate([
            'expense_date' => 'required|date',
            'category' => 'required|string',
            'description' => 'required|string',
            'amount' => 'required|numeric|min:0',
        ]);

        Expense::create([
            'tenant_id' => $tenantId,
            'created_by' => $request->user()->id,
            'expense_date' => $request->expense_date,
            'category' => $request->category,
            'description' => $request->description,
            'amount' => $request->amount,
            'status' => 'active'
        ]);

        return back()->with('success', 'Pengeluaran berhasil ditambahkan.');
    }

    public function destroy(Expense $expense)
    {
        $expense->delete();
        return back()->with('success', 'Pengeluaran berhasil dihapus.');
    }
}
