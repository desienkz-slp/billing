<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Payment;
use App\Models\Package;
use App\Services\PermissionService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class ReportController extends Controller
{
    public function __construct(private PermissionService $permissionService) {}

    public function statistics(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;

        // Monthly revenue (12 months)
        $revenueMonthly = Payment::where('status', 'paid')
            ->where('payment_date', '>=', now()->subMonths(12)->startOfMonth())
            ->selectRaw("to_char(payment_date, 'YYYY-MM') as period, COUNT(*) as count, SUM(paid_amount) as total")
            ->groupByRaw("to_char(payment_date, 'YYYY-MM')")
            ->orderBy('period')
            ->get();

        // Customer growth
        $customerGrowth = Customer::where('registration_date', '>=', now()->subMonths(6)->startOfMonth())
            ->selectRaw("to_char(registration_date, 'YYYY-MM') as period, COUNT(*) as count")
            ->groupByRaw("to_char(registration_date, 'YYYY-MM')")
            ->orderBy('period')
            ->get();

        // Package distribution
        $packageDist = Customer::where('status', 'active')
            ->selectRaw('package_id, COUNT(*) as count')
            ->groupBy('package_id')
            ->with('package')
            ->get();

        // Payment method stats
        $methodStats = Payment::where('status', 'paid')
            ->whereYear('payment_date', now()->year)
            ->selectRaw('payment_method, COUNT(*) as count, SUM(paid_amount) as total')
            ->groupBy('payment_method')
            ->get();

        return Inertia::render('Reports/Statistics', compact(
            'capabilities', 'revenueMonthly', 'customerGrowth', 'packageDist', 'methodStats'
        ));
    }

    public function finance(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $year = $request->get('year', now()->year);

        // Monthly P&L
        $monthlyData = [];
        for ($m = 1; $m <= 12; $m++) {
            $revenue = Payment::where('status', 'paid')
                ->whereMonth('payment_date', $m)->whereYear('payment_date', $year)
                ->sum('paid_amount');
            $ppn = Payment::where('status', 'paid')
                ->whereMonth('payment_date', $m)->whereYear('payment_date', $year)
                ->sum('ppn_amount');
            $pengeluaran = \App\Models\Expense::where('status', 'active')
                ->whereMonth('expense_date', $m)->whereYear('expense_date', $year)
                ->sum('amount');

            $monthlyData[] = [
                'month' => \Carbon\Carbon::create($year, $m)->locale('id')->isoFormat('MMM'),
                'pendapatan' => $revenue,
                'ppn' => $ppn,
                'pengeluaran' => $pengeluaran,
            ];
        }

        $yearTotal = [
            'pendapatan' => collect($monthlyData)->sum('pendapatan'),
            'ppn' => collect($monthlyData)->sum('ppn'),
            'pengeluaran' => collect($monthlyData)->sum('pengeluaran'),
        ];

        return Inertia::render('Reports/Finance', compact('capabilities', 'monthlyData', 'yearTotal', 'year'));
    }

    public function detailPendapatan(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $month = $request->get('month', now()->format('Y-m'));

        $payments = Payment::with(['customer.package', 'customer.area', 'collector'])
            ->where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])
            ->orderByDesc('payment_date')->orderByDesc('id')
            ->get();

        $totals = [
            'amount' => collect($payments)->sum('paid_amount'),
            'count' => count($payments),
        ];

        $areas = Area::orderBy('name')->get();

        return Inertia::render('Reports/DetailPendapatan', compact('capabilities', 'payments', 'totals', 'month', 'areas'));
    }

    public function pengeluaran(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $month = $request->get('month', now()->format('Y-m'));

        $expenses = \App\Models\Expense::with('creator')
            ->whereRaw("to_char(expense_date, 'YYYY-MM') = ?", [$month])
            ->where('status', 'active')
            ->orderByDesc('id')->get();

        $total = $expenses->sum('amount');
        $categories = ['Operasional', 'Marketing', 'Alat/Material', 'Pajak', 'Deviden', 'Lainnya'];

        return Inertia::render('Reports/Pengeluaran', compact('capabilities', 'expenses', 'total', 'month', 'categories'));
    }

    public function storePengeluaran(Request $request)
    {
        $data = $request->validate([
            'description' => 'required|string|max:255',
            'category' => 'required|string|max:100',
            'amount' => 'required|integer|min:1',
        ]);
        $data['tenant_id'] = $request->user()->tenant_id;
        $data['created_by'] = $request->user()->id;
        $data['expense_date'] = now()->toDateString();
        $data['status'] = 'active';
        \App\Models\Expense::create($data);
        return back()->with('success', 'Pengeluaran berhasil ditambahkan.');
    }

    // ===== PPN =====
    public function ppn(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $payments = Payment::with(['customer'])
            ->where('status', 'paid')
            ->where('ppn_amount', '>', 0)
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])
            ->orderByDesc('payment_date')->get();

        $totalPpn = $payments->sum('ppn_amount');
        return Inertia::render('Reports/Ppn', compact('capabilities', 'payments', 'totalPpn', 'month'));
    }

    // ===== Total =====
    public function total(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $pendapatan = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])->sum('paid_amount');
        $ppn = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])->sum('ppn_amount');
        $txnCount = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])->count();
        $pengeluaran = \App\Models\Expense::where('status', 'active')
            ->whereRaw("to_char(expense_date, 'YYYY-MM') = ?", [$month])->sum('amount');
        $setoran = \App\Models\Deposit::where('status', 'active')
            ->whereRaw("to_char(deposit_date, 'YYYY-MM') = ?", [$month])->sum('amount');

        return Inertia::render('Reports/Total', compact('capabilities', 'pendapatan', 'ppn', 'txnCount', 'pengeluaran', 'setoran', 'month'));
    }

    // ===== Arus Kas =====
    public function cashflow(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $pemasukan = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])
            ->selectRaw("payment_date as tanggal, SUM(paid_amount) as total")
            ->groupBy('payment_date')->orderBy('payment_date')->get();

        $pengeluaranHarian = \App\Models\Expense::where('status', 'active')
            ->whereRaw("to_char(expense_date, 'YYYY-MM') = ?", [$month])
            ->selectRaw("expense_date as tanggal, SUM(amount) as total")
            ->groupBy('expense_date')->orderBy('expense_date')->get();

        $totalMasuk = $pemasukan->sum('total');
        $totalKeluar = $pengeluaranHarian->sum('total');

        return Inertia::render('Reports/Cashflow', compact('capabilities', 'pemasukan', 'pengeluaranHarian', 'totalMasuk', 'totalKeluar', 'month'));
    }

    // ===== BATCH C: Fee =====
    public function fee(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $collectors = Payment::where('status', 'paid')
            ->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month])
            ->whereNotNull('collected_by')
            ->selectRaw("collected_by, COUNT(*) as count, SUM(paid_amount) as total")
            ->groupBy('collected_by')
            ->with('collector')
            ->orderByDesc('total')->get();

        return Inertia::render('Reports/Fee', compact('capabilities', 'collectors', 'month'));
    }

    // ===== Setoran =====
    public function setoran(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $deposits = \App\Models\Deposit::with(['sales', 'receiver'])
            ->where('status', 'active')
            ->whereRaw("to_char(deposit_date, 'YYYY-MM') = ?", [$month])
            ->orderByDesc('id')->get();

        $total = $deposits->sum('amount');
        $salesUsers = \App\Models\User::where('is_active', true)->orderBy('name')->get();

        return Inertia::render('Reports/Setoran', compact('capabilities', 'deposits', 'total', 'month', 'salesUsers'));
    }

    public function storeSetoran(Request $request)
    {
        $data = $request->validate([
            'sales_id' => 'required|exists:users,id',
            'amount' => 'required|integer|min:1',
            'method' => 'required|string|max:30',
            'notes' => 'nullable|string|max:255',
        ]);
        $data['tenant_id'] = $request->user()->tenant_id;
        $data['received_by'] = $request->user()->id;
        $data['deposit_date'] = now()->toDateString();
        $data['status'] = 'active';
        \App\Models\Deposit::create($data);
        return back()->with('success', 'Setoran berhasil dicatat.');
    }

    // ===== Mitra =====
    public function mitra(Request $request)
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;
        $month = $request->get('month', now()->format('Y-m'));

        $salesData = \App\Models\User::where('is_active', true)
            ->withCount(['collectedPayments as collected_count' => function($q) use ($month) {
                $q->where('status', 'paid')->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month]);
            }])
            ->withSum(['collectedPayments as collected_total' => function($q) use ($month) {
                $q->where('status', 'paid')->whereRaw("to_char(payment_date, 'YYYY-MM') = ?", [$month]);
            }], 'paid_amount')
            ->withSum(['deposits as deposit_total' => function($q) use ($month) {
                $q->where('status', 'active')->whereRaw("to_char(deposit_date, 'YYYY-MM') = ?", [$month]);
            }], 'amount')
            ->orderByDesc('collected_total')
            ->get()
            ->filter(fn($u) => $u->collected_count > 0)
            ->values();

        return Inertia::render('Reports/Mitra', compact('capabilities', 'salesData', 'month'));
    }

    // ===== Saldo =====
    public function saldo(Request $request): Response
    {
        $user = $request->user()->load('role', 'tenant');
        $capabilities = $this->permissionService->getUserCapabilities($user);
        $tenant = $user->tenant;

        $salesUsers = \App\Models\User::where('is_active', true)
            ->withSum(['collectedPayments as total_collected' => fn($q) => $q->where('status', 'paid')], 'paid_amount')
            ->withSum(['deposits as total_deposited' => fn($q) => $q->where('status', 'active')], 'amount')
            ->orderByDesc('total_collected')
            ->get()
            ->filter(fn($u) => $u->total_collected > 0)
            ->values();

        return Inertia::render('Reports/Saldo', compact('capabilities', 'salesUsers'));
    }
}
