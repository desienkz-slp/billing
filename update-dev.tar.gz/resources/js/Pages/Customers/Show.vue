<template>
    <AppLayout :title="`Detail Pelanggan - ${customer.name}`">
        <div class="mb-6 flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Detail Pelanggan</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Informasi lengkap pelanggan dan riwayat tagihan.</p>
            </div>
            <div class="space-x-2">
                <Link :href="route('customers.edit', customer.id)" class="inline-flex justify-center rounded-lg border border-transparent shadow-sm px-4 py-2 bg-indigo-600 text-sm font-medium text-white hover:bg-indigo-700">
                    <i class="bi bi-pencil-square mr-2"></i> Edit Pelanggan
                </Link>
                <Link :href="route('customers.index')" class="inline-flex justify-center rounded-lg border border-slate-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-600 dark:text-white dark:hover:bg-slate-700">
                    <i class="bi bi-arrow-left mr-2"></i> Kembali
                </Link>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Kolom Kiri: Detail Pelanggan -->
            <div class="lg:col-span-1 space-y-6">
                <Card title="Informasi Personal">
                    <div class="space-y-4">
                        <div>
                            <div class="text-sm text-slate-500 dark:text-slate-400">Nama Lengkap</div>
                            <div class="font-medium text-slate-900 dark:text-white">{{ customer.name }}</div>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500 dark:text-slate-400">Username / ID</div>
                            <div class="font-medium text-slate-900 dark:text-white">{{ customer.username || '-' }}</div>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500 dark:text-slate-400">Status Layanan</div>
                            <div class="mt-1">
                                <span v-if="customer.status === 'active'" class="px-2 py-1 rounded bg-green-100 text-green-800 text-xs font-semibold">Aktif</span>
                                <span v-else class="px-2 py-1 rounded bg-red-100 text-red-800 text-xs font-semibold">Nonaktif</span>
                                
                                <span v-if="customer.is_isolated" class="ml-2 px-2 py-1 rounded bg-red-100 text-red-800 text-xs font-semibold">Terisolir</span>
                            </div>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500 dark:text-slate-400">No HP / WhatsApp</div>
                            <div class="font-medium text-slate-900 dark:text-white">{{ customer.phone || '-' }}</div>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500 dark:text-slate-400">Alamat Pemasangan</div>
                            <div class="font-medium text-slate-900 dark:text-white">{{ customer.address || '-' }}</div>
                        </div>
                    </div>
                </Card>

                <Card title="Layanan & Teknis">
                    <div class="space-y-4">
                        <div>
                            <div class="text-sm text-slate-500 dark:text-slate-400">Paket Internet</div>
                            <div class="font-medium text-slate-900 dark:text-white">{{ customer.package?.name || '-' }}</div>
                            <div class="text-xs text-slate-500">Rp {{ formatRupiah(customer.package?.price) }} / bulan</div>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <div class="text-sm text-slate-500 dark:text-slate-400">Area</div>
                                <div class="font-medium text-slate-900 dark:text-white">{{ customer.area?.name || '-' }}</div>
                            </div>
                            <div>
                                <div class="text-sm text-slate-500 dark:text-slate-400">ODP</div>
                                <div class="font-medium text-slate-900 dark:text-white">{{ customer.odp?.name || '-' }}</div>
                            </div>
                        </div>
                        <div>
                            <div class="text-sm text-slate-500 dark:text-slate-400">Router / NAS</div>
                            <div class="font-medium text-slate-900 dark:text-white">{{ customer.router?.name || '-' }}</div>
                        </div>
                    </div>
                </Card>
            </div>

            <!-- Kolom Kanan: Tagihan & Pembayaran -->
            <div class="lg:col-span-2 space-y-6">
                <Card>
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-lg font-bold text-slate-800 dark:text-white">Riwayat Tagihan & Pembayaran</h2>
                        <Button @click="loadPaymentMonths" variant="secondary" size="sm">
                            <i class="bi bi-arrow-clockwise" :class="{'animate-spin': loadingPayments}"></i> Refresh
                        </Button>
                    </div>

                    <div v-if="loadingPayments" class="text-center py-8">
                        <div class="animate-spin inline-block w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full mb-4"></div>
                        <p class="text-slate-500">Memuat data tagihan...</p>
                    </div>
                    
                    <div v-else>
                        <div v-if="Object.keys(paidMonths).length === 0" class="text-center py-8 text-slate-500">
                            Belum ada catatan tagihan.
                        </div>
                        
                        <div v-else class="space-y-4">
                            <div v-for="(payment, monthKey) in paidMonths" :key="monthKey" 
                                class="flex items-center justify-between p-4 rounded-lg border"
                                :class="payment ? 'border-green-200 bg-green-50 dark:bg-green-900/10 dark:border-green-800' : 'border-red-200 bg-red-50 dark:bg-red-900/10 dark:border-red-800'">
                                
                                <div>
                                    <div class="font-bold text-slate-800 dark:text-white">{{ formatMonthYear(monthKey) }}</div>
                                    <div v-if="payment" class="text-sm text-green-600 dark:text-green-400 mt-1">
                                        <i class="bi bi-check-circle-fill"></i> Lunas pada {{ payment.tgl_bayar }}
                                    </div>
                                    <div v-else class="text-sm text-red-600 dark:text-red-400 mt-1">
                                        <i class="bi bi-exclamation-circle-fill"></i> Belum Dibayar
                                    </div>
                                </div>
                                
                                <div>
                                    <button v-if="!payment" @click="openPaymentModal(monthKey)" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded shadow-sm transition-colors">
                                        Bayar Sekarang
                                    </button>
                                    <div v-else class="text-right">
                                        <div class="font-bold text-slate-800 dark:text-white">Rp {{ formatRupiah(payment.amount) }}</div>
                                        <div class="text-xs text-slate-500">{{ payment.metode }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>
        </div>

        <!-- Payment Modal -->
        <Modal :show="showPaymentModal" @close="showPaymentModal = false">
            <div class="p-6">
                <h2 class="text-lg font-bold text-slate-800 dark:text-white mb-4">Proses Pembayaran</h2>
                
                <div class="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-lg mb-4">
                    <div class="text-sm text-slate-600 dark:text-slate-400">Pembayaran Tagihan Bulan</div>
                    <div class="text-xl font-bold text-indigo-700 dark:text-indigo-400">{{ formatMonthYear(paymentForm.bulan_bayar[0]) }}</div>
                    
                    <div class="mt-3 flex justify-between border-t border-indigo-100 dark:border-indigo-800 pt-3">
                        <span class="text-sm text-slate-600 dark:text-slate-400">Tagihan Pelanggan:</span>
                        <span class="font-bold text-slate-800 dark:text-white">Rp {{ formatRupiah(customerDetails?.harga || customer.package?.price || 0) }}</span>
                    </div>
                </div>

                <form @submit.prevent="submitPayment" class="space-y-4">
                    <Input label="Tanggal Bayar" type="date" v-model="paymentForm.tgl_bayar" required />
                    
                    <div>
                        <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Metode Pembayaran</label>
                        <select v-model="paymentForm.metode" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                            <option value="Tunai">Tunai / Cash</option>
                            <option value="Transfer Bank">Transfer Bank</option>
                            <option value="E-Wallet">E-Wallet (OVO/Dana/Gopay)</option>
                        </select>
                    </div>

                    <Input label="Keterangan (Opsional)" v-model="paymentForm.keterangan" placeholder="Contoh: Titip ke teknisi..." />

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="showPaymentModal = false">Batal</Button>
                        <Button type="submit" :disabled="processingPayment">
                            <i v-if="processingPayment" class="bi bi-hourglass-split animate-spin mr-1"></i>
                            {{ processingPayment ? 'Memproses...' : 'Konfirmasi Pembayaran' }}
                        </Button>
                    </div>
                </form>
            </div>
        </Modal>

    </AppLayout>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { Link } from '@inertiajs/vue3';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    customer: Object
});

const paidMonths = ref({});
const customerDetails = ref(null);
const loadingPayments = ref(false);
const showPaymentModal = ref(false);
const processingPayment = ref(false);

const paymentForm = ref({
    customer_id: props.customer.id,
    bulan_bayar: [],
    tgl_bayar: new Date().toISOString().split('T')[0],
    metode: 'Tunai',
    keterangan: '',
});

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const formatMonthYear = (monthStr) => {
    if (!monthStr) return '';
    const [year, month] = monthStr.split('-');
    const date = new Date(year, parseInt(month) - 1, 1);
    return new Intl.DateTimeFormat('id-ID', { month: 'long', year: 'numeric' }).format(date);
};

const loadPaymentMonths = async () => {
    loadingPayments.value = true;
    try {
        const res = await axios.get(route('api.payments.months', props.customer.id));
        if (res.data.status === 'success') {
            paidMonths.value = res.data.paid_months;
            customerDetails.value = res.data.customer;
        }
    } catch (err) {
        console.error('Failed to fetch payments', err);
        alert('Gagal memuat data tagihan.');
    } finally {
        loadingPayments.value = false;
    }
};

const openPaymentModal = (monthKey) => {
    paymentForm.value.bulan_bayar = [monthKey];
    paymentForm.value.tgl_bayar = new Date().toISOString().split('T')[0];
    paymentForm.value.keterangan = '';
    showPaymentModal.value = true;
};

const submitPayment = async () => {
    processingPayment.value = true;
    try {
        const res = await axios.post(route('api.payments.single'), paymentForm.value);
        if (res.data.status === 'success') {
            showPaymentModal.value = false;
            // Reload payment history
            await loadPaymentMonths();
            // Show alert
            alert('Pembayaran berhasil diproses!');
        } else {
            alert(res.data.message || 'Gagal memproses pembayaran');
        }
    } catch (err) {
        console.error('Payment error', err);
        alert(err.response?.data?.message || 'Terjadi kesalahan sistem saat memproses pembayaran.');
    } finally {
        processingPayment.value = false;
    }
};

onMounted(() => {
    loadPaymentMonths();
});
</script>
