<template>
    <AppLayout title="Peta Pemetaan Pelanggan">
        <div class="relative h-[calc(100vh-120px)] -mx-4 -mt-4 sm:-mx-6 lg:-mx-8 overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm z-0">
            <!-- Map Container -->
            <div id="map" class="absolute inset-0 z-0"></div>

            <!-- Floating Sidebar / Controls -->
            <div class="absolute top-4 left-4 z-10 w-80 max-h-[calc(100%-32px)] flex flex-col gap-4 pointer-events-none">
                <!-- Main Control Panel -->
                <div class="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-700 p-4 rounded-xl shadow-lg pointer-events-auto flex-shrink-0">
                    <h2 class="text-lg font-bold text-slate-800 dark:text-white mb-4">Pemetaan (GIS)</h2>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-xs font-medium text-slate-500 uppercase mb-1">Area</label>
                            <select v-model="filters.area_id" @change="fetchData" class="block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">Semua Area</option>
                                <option v-for="area in areas" :key="area.id" :value="area.id">{{ area.name }}</option>
                            </select>
                        </div>

                        <!-- Layer Toggles -->
                        <div>
                            <label class="block text-xs font-medium text-slate-500 uppercase mb-2">Tampilkan Layer</label>
                            <div class="space-y-2">
                                <label class="flex items-center">
                                    <input type="checkbox" v-model="layers.customers" @change="updateLayers" class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-700">
                                    <span class="ml-2 text-sm text-slate-700 dark:text-slate-300">Pelanggan (<span class="text-indigo-500 font-medium">{{ totalCustomers }}</span>)</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="checkbox" v-model="layers.odps" @change="updateLayers" class="rounded border-slate-300 text-green-600 focus:ring-green-500 dark:border-slate-600 dark:bg-slate-700">
                                    <span class="ml-2 text-sm text-slate-700 dark:text-slate-300">ODP / Kotak (<span class="text-green-500 font-medium">{{ totalOdps }}</span>)</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="checkbox" v-model="layers.odcs" @change="updateLayers" class="rounded border-slate-300 text-amber-600 focus:ring-amber-500 dark:border-slate-600 dark:bg-slate-700">
                                    <span class="ml-2 text-sm text-slate-700 dark:text-slate-300">ODC / Pusat (<span class="text-amber-500 font-medium">{{ totalOdcs }}</span>)</span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Customer Filter Panel (only if customer layer is on) -->
                <div v-if="layers.customers" class="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-700 p-4 rounded-xl shadow-lg pointer-events-auto overflow-y-auto">
                    <h3 class="text-sm font-bold text-slate-800 dark:text-white mb-3">Filter Pelanggan</h3>
                    <div class="space-y-3">
                        <div>
                            <label class="block text-xs text-slate-500 mb-1">Status</label>
                            <select v-model="filters.status" @change="fetchData" class="block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-xs dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">Semua Status</option>
                                <option value="active">Aktif Normal</option>
                                <option value="isolated">Terisolir</option>
                                <option value="inactive">Nonaktif / Berhenti</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs text-slate-500 mb-1">Paket Layanan</label>
                            <select v-model="filters.package_id" @change="fetchData" class="block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-xs dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">Semua Paket</option>
                                <option v-for="pkg in packages" :key="pkg.id" :value="pkg.id">{{ pkg.name }}</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Loading Indicator -->
                <div v-if="loading" class="bg-indigo-600 text-white p-3 rounded-lg shadow-lg pointer-events-auto text-sm flex items-center justify-center">
                    <i class="bi bi-arrow-repeat animate-spin mr-2"></i> Memuat data peta...
                </div>
            </div>

            <!-- Legend -->
            <div class="absolute bottom-4 right-4 z-10 pointer-events-auto">
                <div class="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-700 p-3 rounded-xl shadow-lg text-xs space-y-2">
                    <div class="font-bold text-slate-700 dark:text-white mb-1 border-b pb-1 dark:border-slate-700">Legenda</div>
                    <div class="flex items-center"><span class="w-3 h-3 rounded-full bg-indigo-500 mr-2"></span> Pelanggan Aktif</div>
                    <div class="flex items-center"><span class="w-3 h-3 rounded-full bg-red-500 mr-2"></span> Pelanggan Terisolir</div>
                    <div class="flex items-center"><span class="w-3 h-3 rounded-full bg-slate-500 mr-2"></span> Pelanggan Nonaktif</div>
                    <div class="flex items-center"><span class="w-3 h-3 rounded bg-green-500 mr-2"></span> ODP (Distribusi)</div>
                    <div class="flex items-center"><span class="w-3 h-3 rounded bg-amber-500 mr-2"></span> ODC (Pusat)</div>
                </div>
            </div>
        </div>
    </AppLayout>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import AppLayout from '@/Layouts/AppLayout.vue';
import axios from 'axios';
import 'leaflet/dist/leaflet.css';
import 'leaflet.markercluster/dist/MarkerCluster.css';
import 'leaflet.markercluster/dist/MarkerCluster.Default.css';
import L from 'leaflet';
import 'leaflet.markercluster';

const props = defineProps({
    areas: Array,
    packages: Array,
    totalCustomers: Number,
    totalOdps: Number,
    totalOdcs: Number,
});

const map = ref(null);
const loading = ref(false);

const filters = ref({
    area_id: '',
    status: '',
    package_id: '',
});

const layers = ref({
    customers: true,
    odps: true,
    odcs: true,
});

// Map layer groups
let customerClusterGroup = null;
let odpLayerGroup = null;
let odcLayerGroup = null;

onMounted(() => {
    initMap();
    fetchData();
});

onUnmounted(() => {
    if (map.value) {
        map.value.remove();
    }
});

const initMap = () => {
    map.value = L.map('map', {
        center: [-8.0954, 112.1609], // Default center
        zoom: 13,
        zoomControl: false // We will move it
    });

    L.control.zoom({
        position: 'bottomright'
    }).addTo(map.value);

    // Google Maps Tile Layers
    const googleStreets = L.tileLayer('https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
        maxZoom: 20,
        subdomains: ['mt0','mt1','mt2','mt3'],
        attribution: '&copy; Google Maps',
    });
    
    const googleSatellite = L.tileLayer('https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
        maxZoom: 20,
        subdomains: ['mt0','mt1','mt2','mt3'],
        attribution: '&copy; Google Maps',
    });

    googleStreets.addTo(map.value); // Default layer

    L.control.layers({
        'Google Streets': googleStreets,
        'Google Satellite': googleSatellite,
    }, {}, {position: 'topright'}).addTo(map.value);

    // Initialize layer groups
    customerClusterGroup = L.markerClusterGroup({
        maxClusterRadius: 50,
        spiderfyOnMaxZoom: true,
        showCoverageOnHover: false,
        zoomToBoundsOnClick: true
    });
    
    odpLayerGroup = L.layerGroup();
    odcLayerGroup = L.layerGroup();

    map.value.addLayer(customerClusterGroup);
    map.value.addLayer(odpLayerGroup);
    map.value.addLayer(odcLayerGroup);
};

const fetchData = async () => {
    loading.value = true;
    try {
        const [custRes, odpRes, odcRes] = await Promise.all([
            axios.get(route('map.api.customers'), { params: filters.value }),
            axios.get(route('map.api.odps'), { params: filters.value }),
            axios.get(route('map.api.odcs'), { params: filters.value }),
        ]);

        renderCustomers(custRes.data.data);
        renderOdps(odpRes.data.data);
        renderOdcs(odcRes.data.data);
        updateLayers();
    } catch (error) {
        console.error("Error fetching map data:", error);
    } finally {
        loading.value = false;
    }
};

const getCustomerIcon = (status) => {
    let color = '#6366f1'; // Indigo for active
    if (status === 'isolated') color = '#ef4444'; // Red
    if (status === 'inactive') color = '#64748b'; // Slate

    return L.divIcon({
        className: 'custom-div-icon',
        html: `<div style="background-color: ${color}; width: 14px; height: 14px; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 4px rgba(0,0,0,0.4);"></div>`,
        iconSize: [14, 14],
        iconAnchor: [7, 7]
    });
};

const renderCustomers = (customers) => {
    customerClusterGroup.clearLayers();
    
    customers.forEach(c => {
        if (!c.lat || !c.lng) return;
        
        const marker = L.marker([c.lat, c.lng], {
            icon: getCustomerIcon(c.status)
        });

        const statusBadge = c.status === 'active' ? '<span class="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 text-xs font-medium">Aktif</span>' :
                           c.status === 'isolated' ? '<span class="px-2 py-0.5 rounded bg-red-100 text-red-800 text-xs font-medium">Terisolir</span>' :
                           '<span class="px-2 py-0.5 rounded bg-slate-100 text-slate-800 text-xs font-medium">Nonaktif</span>';

        const popupContent = `
            <div class="p-1 min-w-[200px]">
                <div class="font-bold text-sm mb-1">${c.name}</div>
                <div class="text-xs text-slate-500 mb-2">${c.username} | ${c.phone}</div>
                ${statusBadge}
                <hr class="my-2 border-slate-200" />
                <div class="text-xs grid grid-cols-2 gap-1">
                    <div class="text-slate-500">Area:</div><div>${c.area || '-'}</div>
                    <div class="text-slate-500">Paket:</div><div>${c.package || '-'}</div>
                    <div class="text-slate-500">ODP:</div><div>${c.odp || '-'}</div>
                </div>
            </div>
        `;
        
        marker.bindPopup(popupContent);
        customerClusterGroup.addLayer(marker);
    });
};

const getOdpIcon = () => {
    return L.divIcon({
        className: 'custom-div-icon',
        html: `<div style="background-color: #22c55e; width: 16px; height: 16px; border: 2px solid white; border-radius: 3px; box-shadow: 0 0 4px rgba(0,0,0,0.4);"></div>`,
        iconSize: [16, 16],
        iconAnchor: [8, 8]
    });
};

const renderOdps = (odps) => {
    odpLayerGroup.clearLayers();
    
    odps.forEach(o => {
        if (!o.lat || !o.lng) return;
        
        const marker = L.marker([o.lat, o.lng], { icon: getOdpIcon() });

        const popupContent = `
            <div class="p-1">
                <div class="font-bold text-sm mb-1 text-green-700">ODP: ${o.name}</div>
                <div class="text-xs text-slate-500 mb-2">Area: ${o.area || '-'}</div>
                <div class="text-xs space-y-1">
                    <div>Kapasitas: ${o.capacity} Port</div>
                    <div>Terpakai: <span class="font-medium">${o.used}</span> Port</div>
                    <div>Tersedia: <span class="font-medium text-green-600">${o.available}</span> Port</div>
                </div>
            </div>
        `;
        
        marker.bindPopup(popupContent);
        odpLayerGroup.addLayer(marker);
    });
};

const getOdcIcon = () => {
    return L.divIcon({
        className: 'custom-div-icon',
        html: `<div style="background-color: #f59e0b; width: 20px; height: 20px; border: 2px solid white; border-radius: 4px; box-shadow: 0 0 4px rgba(0,0,0,0.4);"></div>`,
        iconSize: [20, 20],
        iconAnchor: [10, 10]
    });
};

const renderOdcs = (odcs) => {
    odcLayerGroup.clearLayers();
    
    odcs.forEach(o => {
        if (!o.lat || !o.lng) return;
        
        const marker = L.marker([o.lat, o.lng], { icon: getOdcIcon() });

        const popupContent = `
            <div class="p-1">
                <div class="font-bold text-sm mb-1 text-amber-700">ODC: ${o.name}</div>
                <div class="text-xs text-slate-500 mb-2">Area: ${o.area || '-'}</div>
                <div class="text-xs space-y-1">
                    <div>Total ODP: ${o.odp_count}</div>
                    <div>Kapasitas: ${o.capacity}</div>
                </div>
            </div>
        `;
        
        marker.bindPopup(popupContent);
        odcLayerGroup.addLayer(marker);
    });
};

const updateLayers = () => {
    if (!map.value) return;

    if (layers.value.customers) {
        if (!map.value.hasLayer(customerClusterGroup)) map.value.addLayer(customerClusterGroup);
    } else {
        if (map.value.hasLayer(customerClusterGroup)) map.value.removeLayer(customerClusterGroup);
    }

    if (layers.value.odps) {
        if (!map.value.hasLayer(odpLayerGroup)) map.value.addLayer(odpLayerGroup);
    } else {
        if (map.value.hasLayer(odpLayerGroup)) map.value.removeLayer(odpLayerGroup);
    }

    if (layers.value.odcs) {
        if (!map.value.hasLayer(odcLayerGroup)) map.value.addLayer(odcLayerGroup);
    } else {
        if (map.value.hasLayer(odcLayerGroup)) map.value.removeLayer(odcLayerGroup);
    }
};
</script>

<style>
/* Leaflet overrides for dark mode support and modern look */
.leaflet-container {
    font-family: inherit;
    z-index: 0;
}
.leaflet-popup-content-wrapper {
    border-radius: 0.5rem;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
}
.leaflet-popup-content {
    margin: 12px;
}
.dark .leaflet-popup-content-wrapper {
    background-color: #1e293b;
    color: #f8fafc;
}
.dark .leaflet-popup-tip {
    background-color: #1e293b;
}

/* Marker cluster customization */
.marker-cluster-small, .marker-cluster-medium, .marker-cluster-large {
    background-color: rgba(99, 102, 241, 0.4) !important;
}
.marker-cluster-small div, .marker-cluster-medium div, .marker-cluster-large div {
    background-color: rgba(79, 70, 229, 0.9) !important;
    color: white !important;
    font-weight: bold;
    font-family: inherit;
}
</style>
