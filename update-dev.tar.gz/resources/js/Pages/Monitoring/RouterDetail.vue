<template>
    <AppLayout :title="'Router: ' + router.name">
        <!-- Header Section -->
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="flex items-center">
                <Link :href="route('monitoring.index')" class="mr-4 text-slate-400 hover:text-indigo-600 transition-colors">
                    <i class="bi bi-arrow-left-circle text-2xl"></i>
                </Link>
                <div>
                    <h1 class="text-2xl font-bold text-slate-800 dark:text-white flex items-center">
                        {{ router.name }}
                        <span v-if="isConnected" class="ml-3 px-2 py-1 text-[10px] font-bold tracking-wider rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 uppercase">
                            Connected
                        </span>
                        <span v-else class="ml-3 px-2 py-1 text-[10px] font-bold tracking-wider rounded-full bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 uppercase">
                            Offline
                        </span>
                    </h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-mono">{{ router.ip_address }} | ID: {{ identity || '-' }}</p>
                </div>
            </div>
            
            <div class="flex space-x-2">
                <Button variant="secondary" @click="syncData" :disabled="syncing || !isConnected">
                    <i class="bi bi-arrow-repeat mr-2" :class="{'animate-spin': syncing}"></i> 
                    {{ syncing ? 'Menyinkronkan...' : 'Sync Database' }}
                </Button>
            </div>
        </div>

        <!-- Resources Panel -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6" v-if="isConnected">
            <Card class="bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800/50 !p-4">
                <div class="text-xs font-medium text-blue-800 dark:text-blue-300 mb-1">CPU Load</div>
                <div class="text-2xl font-bold text-blue-900 dark:text-white flex items-end">
                    {{ resources['cpu-load'] || 0 }}<span class="text-sm ml-1 font-normal">%</span>
                </div>
                <div class="w-full bg-blue-200 dark:bg-blue-900/50 rounded-full h-1.5 mt-2">
                    <div class="bg-blue-500 h-1.5 rounded-full" :style="{ width: (resources['cpu-load'] || 0) + '%' }"></div>
                </div>
            </Card>
            <Card class="bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800/50 !p-4">
                <div class="text-xs font-medium text-emerald-800 dark:text-emerald-300 mb-1">Active Connections</div>
                <div class="text-2xl font-bold text-emerald-900 dark:text-white flex items-end">
                    {{ activeDetails.length }}<span class="text-sm ml-1 font-normal">Users</span>
                </div>
            </Card>
            <Card class="bg-purple-50 dark:bg-purple-900/20 border-purple-100 dark:border-purple-800/50 !p-4">
                <div class="text-xs font-medium text-purple-800 dark:text-purple-300 mb-1">Free Memory</div>
                <div class="text-xl font-bold text-purple-900 dark:text-white truncate" :title="formatBytes(resources['free-memory'])">
                    {{ formatBytes(resources['free-memory']) }}
                </div>
            </Card>
            <Card class="bg-amber-50 dark:bg-amber-900/20 border-amber-100 dark:border-amber-800/50 !p-4">
                <div class="text-xs font-medium text-amber-800 dark:text-amber-300 mb-1">Uptime</div>
                <div class="text-sm font-bold text-amber-900 dark:text-white mt-1">
                    {{ resources['uptime'] || '-' }}
                </div>
            </Card>
        </div>
        
        <div v-else class="mb-6 p-4 bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400 border border-red-200 dark:border-red-800 rounded-lg flex items-center">
            <i class="bi bi-exclamation-triangle-fill text-xl mr-3"></i>
            <div>
                <strong>Gagal terhubung ke router MikroTik.</strong> Pastikan IP, port API, username, dan password sudah benar serta router dalam keadaan menyala.
            </div>
        </div>

        <!-- Tab Navigation -->
        <div class="mb-6 border-b border-slate-200 dark:border-slate-700">
            <nav class="-mb-px flex space-x-6 overflow-x-auto">
                <button @click="activeTab = 'secrets'" 
                    class="whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm transition-colors"
                    :class="activeTab === 'secrets' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:text-slate-400 dark:hover:text-slate-300'">
                    <i class="bi bi-people mr-2"></i> PPPoE Secrets ({{ enrichedSecrets.length }})
                </button>
                <button @click="activeTab = 'active'" 
                    class="whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm transition-colors"
                    :class="activeTab === 'active' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:text-slate-400 dark:hover:text-slate-300'">
                    <i class="bi bi-activity mr-2"></i> Active Connections ({{ activeDetails.length }})
                </button>
                <button @click="activeTab = 'profiles'" 
                    class="whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm transition-colors"
                    :class="activeTab === 'profiles' ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:text-slate-400 dark:hover:text-slate-300'">
                    <i class="bi bi-shield-check mr-2"></i> PPPoE Profiles ({{ profiles.length }})
                </button>
            </nav>
        </div>

        <!-- Tab Contents -->
        <div class="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
            
            <!-- SECRETS TAB -->
            <div v-show="activeTab === 'secrets'">
                <div class="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
                    <div class="relative w-full max-w-md">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="bi bi-search text-slate-400"></i>
                        </div>
                        <input type="text" v-model="searchSecret" placeholder="Cari username secret..." 
                            class="block w-full pl-10 rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead class="bg-slate-50 dark:bg-slate-800/50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Username (Secret)</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Password</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Profile</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Pelanggan Lokal</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                            <tr v-for="secret in filteredSecrets" :key="secret.name" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span v-if="secret.disabled" class="px-2 py-1 text-xs rounded-full bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400" title="Isolir / Disabled"><i class="bi bi-x-circle mr-1"></i> Isolir</span>
                                    <span v-else-if="secret.is_online" class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"><i class="bi bi-circle-fill text-[8px] mr-1"></i> Online</span>
                                    <span v-else class="px-2 py-1 text-xs rounded-full bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300"><i class="bi bi-moon mr-1"></i> Offline</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap font-medium text-slate-900 dark:text-white">
                                    {{ secret.name }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono">
                                    <span class="blur-sm hover:blur-none transition-all cursor-pointer" title="Hover to view">{{ secret.password }}</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 text-xs rounded bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-900/20 dark:text-indigo-300 dark:border-indigo-800">{{ secret.profile }}</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                    <Link v-if="secret.customer_id" :href="route('customers.show', secret.customer_id)" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 font-medium">
                                        {{ secret.customer_name }}
                                    </Link>
                                    <span v-else class="text-amber-600 dark:text-amber-500 italic text-xs"><i class="bi bi-exclamation-triangle"></i> Belum dilink</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <button v-if="secret.customer_id && !secret.disabled" @click="toggleIsolir(secret, 'isolir')" class="text-red-600 hover:text-red-900 dark:text-red-400 ml-3">Isolir</button>
                                    <button v-if="secret.customer_id && secret.disabled" @click="toggleIsolir(secret, 'unisolir')" class="text-emerald-600 hover:text-emerald-900 dark:text-emerald-400 ml-3">Buka Isolir</button>
                                </td>
                            </tr>
                            <tr v-if="filteredSecrets.length === 0">
                                <td colspan="6" class="px-6 py-8 text-center text-slate-500">Tidak ada secret yang ditemukan.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- ACTIVE CONNECTIONS TAB -->
            <div v-show="activeTab === 'active'">
                <div class="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
                    <div class="relative w-full max-w-md">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="bi bi-search text-slate-400"></i>
                        </div>
                        <input type="text" v-model="searchActive" placeholder="Cari user online..." 
                            class="block w-full pl-10 rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead class="bg-slate-50 dark:bg-slate-800/50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Username</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">IP Address</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">MAC Address (Caller ID)</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Uptime</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                            <tr v-for="active in filteredActive" :key="active.name" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="font-medium text-slate-900 dark:text-white flex items-center">
                                        <i class="bi bi-circle-fill text-[8px] text-green-500 mr-2 shadow-sm shadow-green-500/50"></i>
                                        {{ active.name }}
                                    </div>
                                    <div class="text-xs text-slate-500 mt-1" v-if="active.customer_name">{{ active.customer_name }}</div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-700 dark:text-slate-300 font-mono">
                                    {{ active.address }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono uppercase">
                                    {{ active.caller_id || '-' }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-700 dark:text-slate-300">
                                    <i class="bi bi-clock-history mr-1 text-slate-400"></i> {{ active.uptime }}
                                </td>
                            </tr>
                            <tr v-if="filteredActive.length === 0">
                                <td colspan="4" class="px-6 py-8 text-center text-slate-500">Tidak ada user yang online atau cocok dengan pencarian.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- PROFILES TAB -->
            <div v-show="activeTab === 'profiles'">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                        <thead class="bg-slate-50 dark:bg-slate-800/50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama Profile</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Rate Limit (Rx/Tx)</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Local Address</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Remote Address (Pool)</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                            <tr v-for="profile in profiles" :key="profile.name" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                <td class="px-6 py-4 whitespace-nowrap font-medium text-slate-900 dark:text-white">
                                    {{ profile.name }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-mono font-bold text-indigo-600 dark:text-indigo-400">
                                    {{ profile['rate-limit'] || 'Unlimited' }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono">
                                    {{ profile['local-address'] || '-' }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono">
                                    {{ profile['remote-address'] || '-' }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </AppLayout>
</template>

<script setup>
import { ref, computed } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';

const props = defineProps({
    router: Object,
    enrichedSecrets: Array,
    activeDetails: Array,
    profiles: Array,
    resources: Object,
    identity: String,
});

const isConnected = computed(() => {
    return props.resources && Object.keys(props.resources).length > 0;
});

const activeTab = ref('secrets');
const searchSecret = ref('');
const searchActive = ref('');
const syncing = ref(false);

const filteredSecrets = computed(() => {
    if (!searchSecret.value) return props.enrichedSecrets;
    const query = searchSecret.value.toLowerCase();
    return props.enrichedSecrets.filter(s => 
        s.name.toLowerCase().includes(query) || 
        (s.customer_name && s.customer_name.toLowerCase().includes(query))
    );
});

const filteredActive = computed(() => {
    if (!searchActive.value) return props.activeDetails;
    const query = searchActive.value.toLowerCase();
    return props.activeDetails.filter(a => 
        a.name.toLowerCase().includes(query) || 
        (a.customer_name && a.customer_name.toLowerCase().includes(query)) ||
        (a.address && a.address.includes(query))
    );
});

const formatBytes = (bytes) => {
    if (!bytes) return '-';
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const syncData = async () => {
    if (confirm('Sinkronisasi akan memperbarui database lokal dengan profil dan secret terbaru dari MikroTik. Lanjutkan?')) {
        syncing.value = true;
        try {
            const response = await axios.post(route('monitoring.sync', props.router.id));
            alert(response.data.message);
            router.reload({ only: ['enrichedSecrets', 'profiles'] });
        } catch (error) {
            alert('Gagal sinkronisasi data dari router.');
            console.error(error);
        } finally {
            syncing.value = false;
        }
    }
};

const toggleIsolir = async (secret, action) => {
    const actionText = action === 'isolir' ? 'mengisolir (disable)' : 'membuka isolir (enable)';
    if (confirm(`Anda yakin ingin ${actionText} secret PPPoE ${secret.name}?`)) {
        try {
            const endpoint = action === 'isolir' 
                ? route('monitoring.isolir', { router: props.router.id, customer: secret.customer_id })
                : route('monitoring.unisolir', { router: props.router.id, customer: secret.customer_id });
            
            const response = await axios.post(endpoint);
            
            if (response.data.status === 'success') {
                router.reload({ only: ['enrichedSecrets'] });
            } else {
                alert(response.data.message);
            }
        } catch (error) {
            alert(`Terjadi kesalahan saat mencoba ${action} via API.`);
            console.error(error);
        }
    }
};
</script>
