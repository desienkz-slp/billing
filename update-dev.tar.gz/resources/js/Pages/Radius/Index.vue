<template>
    <AppLayout title="Manajemen RADIUS / PPPoE">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Manajemen RADIUS / PPPoE</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Kelola Secret, Profile, dan Autentikasi pelanggan ke router secara langsung.</p>
            </div>
            
            <Link :href="route('settings.routers.index')">
                <Button variant="secondary">
                    <i class="bi bi-hdd-network mr-2"></i> Pengaturan Router
                </Button>
            </Link>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Link v-for="router in routers" :key="router.id" :href="route('radius.secrets', router.id)" class="group block">
                <Card class="h-full transition-all duration-200 border-2 border-transparent hover:border-blue-500 hover:shadow-lg dark:hover:border-blue-400 group-hover:-translate-y-1">
                    <div class="flex items-start justify-between mb-4">
                        <div class="flex items-center">
                            <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4 shadow-sm"
                                :class="router.is_active ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'">
                                <i class="bi bi-shield-lock text-2xl"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">{{ router.name }}</h3>
                                <div class="text-sm text-slate-500 font-mono">{{ router.ip_address }}</div>
                            </div>
                        </div>
                        <div class="flex flex-col items-end">
                            <span v-if="router.is_active" class="px-2 py-1 text-[10px] font-bold tracking-wider rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 uppercase">
                                Active
                            </span>
                            <span v-else class="px-2 py-1 text-[10px] font-bold tracking-wider rounded-full bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-400 uppercase">
                                Disabled
                            </span>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-3 gap-2 mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
                        <div>
                            <div class="text-xl font-bold text-slate-800 dark:text-slate-200">{{ router.pppoe_secrets_count || 0 }}</div>
                            <div class="text-[10px] uppercase font-bold tracking-wide text-slate-500 mt-1">Secrets</div>
                        </div>
                        <div class="border-l border-r border-slate-100 dark:border-slate-700">
                            <div class="text-xl font-bold text-slate-800 dark:text-slate-200">{{ router.pppoe_profiles_count || 0 }}</div>
                            <div class="text-[10px] uppercase font-bold tracking-wide text-slate-500 mt-1">Profiles</div>
                        </div>
                        <div>
                            <div class="text-xl font-bold text-slate-800 dark:text-slate-200">{{ router.customers_count || 0 }}</div>
                            <div class="text-[10px] uppercase font-bold tracking-wide text-slate-500 mt-1">Linked</div>
                        </div>
                    </div>

                    <div class="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-center text-sm font-medium text-blue-600 dark:text-blue-400 group-hover:text-blue-700 dark:group-hover:text-blue-300">
                        Kelola PPPoE &rarr;
                    </div>
                </Card>
            </Link>

            <div v-if="routers.length === 0" class="col-span-full">
                <Card class="flex flex-col items-center justify-center p-12 text-center border-dashed">
                    <div class="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
                        <i class="bi bi-shield-lock text-3xl text-slate-400"></i>
                    </div>
                    <h3 class="text-lg font-medium text-slate-900 dark:text-white mb-2">Belum Ada Router</h3>
                    <p class="text-slate-500 mb-6 max-w-md">Tambahkan router MikroTik terlebih dahulu untuk mengelola PPPoE dan RADIUS server.</p>
                    <Link :href="route('settings.routers.index')">
                        <Button>
                            <i class="bi bi-plus-lg mr-2"></i> Tambah Router
                        </Button>
                    </Link>
                </Card>
            </div>
        </div>
    </AppLayout>
</template>

<script setup>
import { Link } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';

defineProps({
    routers: Array
});
</script>
