<template>
    <AppLayout :title="'PPPoE Secrets: ' + router.name">
        <!-- Header Section -->
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="flex items-center">
                <Link :href="route('radius.index')" class="mr-4 text-slate-400 hover:text-blue-600 transition-colors">
                    <i class="bi bi-arrow-left-circle text-2xl"></i>
                </Link>
                <div>
                    <h1 class="text-2xl font-bold text-slate-800 dark:text-white flex items-center">
                        {{ router.name }} (PPPoE & RADIUS)
                    </h1>
                    <p class="text-sm text-slate-500 dark:text-slate-400 font-mono">{{ router.ip_address }} | Area: {{ router.location || '-' }}</p>
                </div>
            </div>
            
            <div class="flex space-x-2">
                <Button variant="secondary" @click="syncData" :disabled="syncing">
                    <i class="bi bi-arrow-repeat mr-2" :class="{'animate-spin': syncing}"></i> 
                    {{ syncing ? 'Menyinkronkan...' : 'Tarik Data Router' }}
                </Button>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card class="bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800/50 flex items-center justify-between">
                <div>
                    <div class="text-sm font-medium text-blue-800 dark:text-blue-300 mb-1">Total PPPoE Secrets</div>
                    <div class="text-2xl font-bold text-blue-900 dark:text-white">{{ enrichedSecrets.length }}</div>
                </div>
                <div class="text-blue-200 dark:text-blue-800/50">
                    <i class="bi bi-people text-4xl"></i>
                </div>
            </Card>
            <Card class="bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800/50 flex items-center justify-between">
                <div>
                    <div class="text-sm font-medium text-emerald-800 dark:text-emerald-300 mb-1">Online Active</div>
                    <div class="text-2xl font-bold text-emerald-900 dark:text-white">{{ active.length }}</div>
                </div>
                <div class="text-emerald-200 dark:text-emerald-800/50">
                    <i class="bi bi-wifi text-4xl"></i>
                </div>
            </Card>
            <Card class="bg-amber-50 dark:bg-amber-900/20 border-amber-100 dark:border-amber-800/50 flex items-center justify-between">
                <div>
                    <div class="text-sm font-medium text-amber-800 dark:text-amber-300 mb-1">Total Profiles</div>
                    <div class="text-2xl font-bold text-amber-900 dark:text-white">{{ profiles.length }}</div>
                </div>
                <div class="text-amber-200 dark:text-amber-800/50">
                    <i class="bi bi-shield-check text-4xl"></i>
                </div>
            </Card>
        </div>

        <Card title="Daftar PPPoE Secrets" bodyClass="!p-0">
            <div class="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div class="relative w-full max-w-md">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="bi bi-search text-slate-400"></i>
                    </div>
                    <input type="text" v-model="search" placeholder="Cari username secret atau pelanggan..." 
                        class="block w-full pl-10 rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                </div>
                
                <div class="flex items-center space-x-2 text-sm text-slate-500">
                    <span class="flex items-center"><i class="bi bi-circle-fill text-[8px] text-green-500 mr-1"></i> Online</span>
                    <span class="flex items-center ml-3"><i class="bi bi-moon text-slate-400 mr-1"></i> Offline</span>
                    <span class="flex items-center ml-3"><i class="bi bi-x-circle text-red-500 mr-1"></i> Terisolir</span>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Secret / Username</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Password</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Profile Limit</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi & Isolir</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="secret in filteredSecrets" :key="secret.name" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span v-if="secret.disabled" class="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400" title="Isolir / Disabled"><i class="bi bi-x-circle mr-1"></i> Isolir Router</span>
                                <span v-else-if="secret.is_online" class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"><i class="bi bi-circle-fill text-[8px] mr-1"></i> Online</span>
                                <span v-else class="px-2 py-1 text-xs font-medium rounded-full bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300"><i class="bi bi-moon mr-1"></i> Offline</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white text-base">{{ secret.name }}</div>
                                <div v-if="secret.customer_id">
                                    <Link :href="route('customers.show', secret.customer_id)" class="text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400">
                                        <i class="bi bi-person mr-1"></i>{{ secret.customer_name }}
                                        <span v-if="secret.customer_isolated" class="ml-1 text-red-500">(Bill: Isolir)</span>
                                    </Link>
                                </div>
                                <div v-else class="text-xs text-amber-600 dark:text-amber-500 italic mt-1">
                                    <i class="bi bi-exclamation-triangle mr-1"></i> Unlinked
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono">
                                <div class="group relative inline-block cursor-pointer">
                                    <span class="blur-[4px] group-hover:blur-none transition-all duration-300">{{ secret.password }}</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-medium rounded bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-900/20 dark:text-indigo-300 dark:border-indigo-800">{{ secret.profile }}</span>
                                <div class="text-[10px] text-slate-400 mt-1 uppercase">{{ secret.service }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div v-if="secret.customer_id" class="flex items-center space-x-2">
                                    <button v-if="!secret.disabled" @click="toggleIsolir(secret, 'isolir')" class="px-3 py-1.5 bg-red-50 text-red-600 border border-red-200 rounded hover:bg-red-100 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800 transition-colors flex items-center">
                                        <i class="bi bi-power mr-1"></i> Force Isolir
                                    </button>
                                    <button v-else @click="toggleIsolir(secret, 'unisolir')" class="px-3 py-1.5 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded hover:bg-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800 transition-colors flex items-center">
                                        <i class="bi bi-unlock mr-1"></i> Buka Isolir
                                    </button>
                                </div>
                                <div v-else class="text-slate-400 text-xs italic">Tautkan ke pelanggan di menu Edit Customer.</div>
                            </td>
                        </tr>
                        <tr v-if="filteredSecrets.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">Tidak ada PPPoE secret yang ditemukan.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="p-4 bg-blue-50 dark:bg-blue-900/10 border-t border-blue-200 dark:border-blue-800/30 text-xs text-blue-800 dark:text-blue-400">
                <i class="bi bi-info-circle mr-1"></i> Fitur "Force Isolir" akan mematikan (disable) secret secara langsung di router MikroTik dan mencatat aktivitasnya di sistem billing. Aksi ini langsung memutuskan koneksi internet pelanggan terkait.
            </div>
        </Card>

    </AppLayout>
</template>

<script setup>
import { ref, computed } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';

const props = defineProps({
    router: Object,
    enrichedSecrets: Array,
    active: Array,
    profiles: Array,
});

const search = ref('');
const syncing = ref(false);

const filteredSecrets = computed(() => {
    if (!search.value) return props.enrichedSecrets;
    const query = search.value.toLowerCase();
    return props.enrichedSecrets.filter(s => 
        s.name.toLowerCase().includes(query) || 
        (s.customer_name && s.customer_name.toLowerCase().includes(query))
    );
});

const syncData = async () => {
    if (confirm('Sinkronisasi akan mem-pull secret terbaru dari MikroTik ke sistem ini. Lanjutkan?')) {
        syncing.value = true;
        try {
            const response = await axios.post(route('radius.sync', props.router.id));
            alert(response.data.message);
            router.reload({ only: ['enrichedSecrets', 'profiles'] });
        } catch (error) {
            alert('Gagal sinkronisasi data dari router. Pastikan API MikroTik nyala.');
            console.error(error);
        } finally {
            syncing.value = false;
        }
    }
};

const toggleIsolir = async (secret, action) => {
    const actionText = action === 'isolir' ? 'mematikan (DISABLE)' : 'menghidupkan (ENABLE)';
    if (confirm(`Peringatan: Anda akan ${actionText} koneksi PPPoE ${secret.name} secara HARD level di Router. Lanjutkan?`)) {
        try {
            const endpoint = action === 'isolir' 
                ? route('radius.isolir', { router: props.router.id, customer: secret.customer_id })
                : route('radius.unisolir', { router: props.router.id, customer: secret.customer_id });
            
            const response = await axios.post(endpoint);
            
            if (response.data.status === 'success') {
                router.reload({ only: ['enrichedSecrets'] });
            } else {
                alert(response.data.message);
            }
        } catch (error) {
            alert(`Terjadi kesalahan saat mengeksekusi Isolir/Unisolir.`);
            console.error(error);
        }
    }
};
</script>
