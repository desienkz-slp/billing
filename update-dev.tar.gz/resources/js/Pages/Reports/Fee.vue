<template>
    <AppLayout title="Laporan Fee Kolektor">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Laporan Kinerja Kolektor</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Total tagihan yang ditagih oleh masing-masing kolektor/sales.</p>
            </div>
            
            <div class="flex items-center space-x-2">
                <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Bulan:</label>
                <input type="month" v-model="filterMonth" @change="applyFilter" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            <Card class="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-800 flex items-center">
                <div class="p-3 bg-indigo-100 dark:bg-indigo-900 rounded-lg mr-4">
                    <i class="bi bi-people text-2xl text-indigo-600 dark:text-indigo-400"></i>
                </div>
                <div>
                    <div class="text-sm font-medium text-indigo-800 dark:text-indigo-300">Total Kolektor Aktif</div>
                    <div class="text-2xl font-bold text-indigo-900 dark:text-white">{{ collectors.length }} <span class="text-sm font-normal">Orang</span></div>
                </div>
            </Card>
            <Card class="bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800 flex items-center">
                <div class="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg mr-4">
                    <i class="bi bi-receipt text-2xl text-blue-600 dark:text-blue-400"></i>
                </div>
                <div>
                    <div class="text-sm font-medium text-blue-800 dark:text-blue-300">Total Transaksi Tertagih</div>
                    <div class="text-2xl font-bold text-blue-900 dark:text-white">{{ totalTransaksi }} <span class="text-sm font-normal">Trx</span></div>
                </div>
            </Card>
            <Card class="bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800 flex items-center">
                <div class="p-3 bg-emerald-100 dark:bg-emerald-900 rounded-lg mr-4">
                    <i class="bi bi-cash-stack text-2xl text-emerald-600 dark:text-emerald-400"></i>
                </div>
                <div>
                    <div class="text-sm font-medium text-emerald-800 dark:text-emerald-300">Total Dana Tertagih</div>
                    <div class="text-2xl font-bold text-emerald-900 dark:text-white">Rp {{ formatRupiah(totalDana) }}</div>
                </div>
            </Card>
        </div>

        <Card title="Rincian Kinerja Kolektor" bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Peringkat</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama Kolektor / Sales</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Jumlah Transaksi</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Total Dana Tertagih (Rp)</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="(col, index) in collectors" :key="col.collected_by" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                <span v-if="index === 0" class="text-yellow-500 text-xl" title="Top 1"><i class="bi bi-trophy-fill"></i></span>
                                <span v-else-if="index === 1" class="text-slate-400 text-xl" title="Top 2"><i class="bi bi-trophy-fill"></i></span>
                                <span v-else-if="index === 2" class="text-amber-700 text-xl" title="Top 3"><i class="bi bi-trophy-fill"></i></span>
                                <span v-else class="px-2">{{ index + 1 }}</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ col.collector?.name || 'Unknown' }}</div>
                                <div class="text-xs text-slate-500">{{ col.collector?.email || '-' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-center font-medium text-slate-900 dark:text-slate-300">
                                {{ col.count }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-emerald-600 dark:text-emerald-400">
                                Rp {{ formatRupiah(col.total) }}
                            </td>
                        </tr>
                        <tr v-if="collectors.length === 0">
                            <td colspan="4" class="px-6 py-8 text-center text-slate-500">Tidak ada data penagihan oleh kolektor pada bulan ini.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { ref, computed } from 'vue';
import { router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';

const props = defineProps({
    collectors: Array,
    month: String,
    capabilities: Array
});

const filterMonth = ref(props.month);

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const totalTransaksi = computed(() => {
    return props.collectors.reduce((sum, item) => sum + item.count, 0);
});

const totalDana = computed(() => {
    return props.collectors.reduce((sum, item) => sum + parseFloat(item.total), 0);
});

const applyFilter = () => {
    router.get(route('reports.fee'), { month: filterMonth.value }, { preserveState: true });
};
</script>
