<template>
    <AppLayout title="Saldo Kas di Tangan">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Saldo Kas di Tangan Mitra</h1>
            <p class="text-sm text-slate-500 dark:text-slate-400">Total akumulasi uang penagihan yang masih dipegang oleh masing-masing sales / teknisi (belum disetor ke kasir pusat).</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            <Card class="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-800 lg:col-span-2">
                <div class="flex justify-between items-center h-full">
                    <div>
                        <div class="text-sm font-medium text-indigo-800 dark:text-indigo-300 mb-1">Total Dana Beredar (Belum Disetor)</div>
                        <div class="text-3xl font-bold text-red-600 dark:text-red-400">Rp {{ formatRupiah(totalBeredar) }}</div>
                    </div>
                    <div class="text-indigo-200 dark:text-indigo-800/50">
                        <i class="bi bi-wallet2 text-6xl"></i>
                    </div>
                </div>
            </Card>
        </div>

        <Card title="Rincian Saldo per Mitra" bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Mitra / Sales</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-blue-600">Total Akumulasi Tagihan (Rp)</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-green-600">Total Akumulasi Setoran (Rp)</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-red-600">Sisa Saldo Kas (Rp)</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="user in salesUsers" :key="user.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ user.name }}</div>
                                <div class="text-xs text-slate-500">{{ user.email }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-blue-600 dark:text-blue-400">
                                {{ formatRupiah(user.total_collected || 0) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-green-600 dark:text-green-400">
                                {{ formatRupiah(user.total_deposited || 0) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-red-600 dark:text-red-400 text-lg">
                                {{ formatRupiah((user.total_collected || 0) - (user.total_deposited || 0)) }}
                            </td>
                        </tr>
                        <tr v-if="salesUsers.length === 0">
                            <td colspan="4" class="px-6 py-8 text-center text-slate-500">Tidak ada mitra dengan riwayat penagihan yang tercatat.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { computed } from 'vue';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';

const props = defineProps({
    salesUsers: Array,
    capabilities: Array
});

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const totalBeredar = computed(() => {
    return props.salesUsers.reduce((sum, user) => {
        return sum + ((user.total_collected || 0) - (user.total_deposited || 0));
    }, 0);
});
</script>
