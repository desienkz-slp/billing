<template>
    <AppLayout title="Setoran Dana">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Setoran Dana / Kasir</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Pencatatan uang tunai atau transfer dari mitra/sales ke kasir pusat.</p>
            </div>
            
            <div class="flex items-center space-x-2">
                <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Bulan:</label>
                <input type="month" v-model="filterMonth" @change="applyFilter" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            <Card class="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-800 lg:col-span-2">
                <div class="flex justify-between items-center h-full">
                    <div>
                        <div class="text-sm font-medium text-indigo-800 dark:text-indigo-300 mb-1">Total Setoran Diterima (Bulan Ini)</div>
                        <div class="text-3xl font-bold text-indigo-900 dark:text-white">Rp {{ formatRupiah(total) }}</div>
                    </div>
                    <div class="text-indigo-200 dark:text-indigo-800/50">
                        <i class="bi bi-box-arrow-in-down text-6xl"></i>
                    </div>
                </div>
            </Card>
            
            <Card class="flex flex-col justify-center items-center text-center">
                <Button @click="showModal = true" class="w-full h-full py-4 text-lg">
                    <i class="bi bi-plus-circle mr-2"></i> Terima Setoran Baru
                </Button>
            </Card>
        </div>

        <Card title="Riwayat Setoran" bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tanggal & Waktu</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Disetor Oleh (Mitra)</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Diterima Oleh (Kasir)</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Metode</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Catatan</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Nominal (Rp)</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="deposit in deposits" :key="deposit.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-900 dark:text-slate-300">
                                {{ new Date(deposit.created_at).toLocaleString('id-ID') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ deposit.sales?.name || 'Unknown' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                {{ deposit.receiver?.name || 'System' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300">
                                    {{ deposit.method }}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-500">
                                {{ deposit.notes || '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-indigo-600 dark:text-indigo-400">
                                Rp {{ formatRupiah(deposit.amount) }}
                            </td>
                        </tr>
                        <tr v-if="deposits.length === 0">
                            <td colspan="6" class="px-6 py-8 text-center text-slate-500">Belum ada riwayat setoran di bulan ini.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>

        <!-- Form Modal -->
        <Modal :show="showModal" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-medium text-slate-900 dark:text-white mb-4">
                    Catat Penerimaan Setoran
                </h2>
                
                <form @submit.prevent="submitForm">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Mitra / Sales (Penyetor)</label>
                            <select v-model="form.sales_id" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="" disabled>-- Pilih Penyetor --</option>
                                <option v-for="user in salesUsers" :key="user.id" :value="user.id">{{ user.name }}</option>
                            </select>
                            <div v-if="form.errors.sales_id" class="text-sm text-red-600 mt-1">{{ form.errors.sales_id }}</div>
                        </div>

                        <Input label="Nominal Setoran (Rp)" type="number" min="1" v-model="form.amount" :error="form.errors.amount" required />
                        
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Metode Setor</label>
                            <select v-model="form.method" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="Tunai">Uang Tunai</option>
                                <option value="Transfer Bank">Transfer Bank</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>

                        <Input label="Catatan Tambahan (Opsional)" v-model="form.notes" :error="form.errors.notes" placeholder="Contoh: Titip ke teknisi..." />
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="closeModal">Batal</Button>
                        <Button type="submit" :disabled="form.processing">Simpan Setoran</Button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { useForm, router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    deposits: Array,
    total: Number,
    month: String,
    salesUsers: Array,
    capabilities: Array
});

const filterMonth = ref(props.month);
const showModal = ref(false);

const form = useForm({
    sales_id: '',
    amount: '',
    method: 'Tunai',
    notes: '',
});

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const applyFilter = () => {
    router.get(route('reports.setoran'), { month: filterMonth.value }, { preserveState: true });
};

const closeModal = () => {
    showModal.value = false;
    form.reset();
    form.clearErrors();
};

const submitForm = () => {
    form.post(route('reports.setoran.store'), {
        onSuccess: () => closeModal()
    });
};
</script>
