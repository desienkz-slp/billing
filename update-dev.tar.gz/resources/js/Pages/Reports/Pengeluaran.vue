<template>
    <AppLayout title="Laporan Pengeluaran">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Laporan Pengeluaran Operasional</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Rincian catatan pengeluaran perusahaan per bulan.</p>
            </div>
            
            <div class="flex items-center space-x-2">
                <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Bulan:</label>
                <input type="month" v-model="filterMonth" @change="applyFilter" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
            </div>
        </div>

        <Card class="bg-red-50 dark:bg-red-900/20 border-red-100 dark:border-red-800 flex items-center justify-between mb-6">
            <div>
                <div class="text-sm font-medium text-red-800 dark:text-red-300 mb-1">Total Pengeluaran (Bulan Ini)</div>
                <div class="text-2xl font-bold text-red-900 dark:text-white">Rp {{ formatRupiah(total) }}</div>
            </div>
            <div class="text-red-200 dark:text-red-800/50">
                <i class="bi bi-cart-x text-5xl"></i>
            </div>
        </Card>

        <Card bodyClass="!p-0">
            <div class="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
                <div class="text-sm font-medium text-slate-700 dark:text-slate-300">Rincian Transaksi Keluar</div>
                <Button @click="printReport" variant="secondary" size="sm">
                    <i class="bi bi-printer mr-1"></i> Cetak / PDF
                </Button>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tanggal</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Kategori</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Keterangan</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Dicatat Oleh</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Nominal (Rp)</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="(expense, index) in expenses" :key="expense.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                {{ index + 1 }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-900 dark:text-slate-300">
                                {{ formatDate(expense.expense_date) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300">
                                    {{ expense.category }}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-900 dark:text-slate-300">
                                {{ expense.description }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                {{ expense.creator?.name || 'System' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-red-600 dark:text-red-400">
                                Rp {{ formatRupiah(expense.amount) }}
                            </td>
                        </tr>
                        <tr v-if="expenses.length === 0">
                            <td colspan="6" class="px-6 py-8 text-center text-slate-500">Tidak ada pengeluaran pada bulan ini.</td>
                        </tr>
                    </tbody>
                    <tfoot v-if="expenses.length > 0" class="bg-slate-50 dark:bg-slate-800/50 border-t-2 border-slate-200 dark:border-slate-700">
                        <tr>
                            <td colspan="5" class="px-6 py-4 whitespace-nowrap text-sm font-bold text-slate-900 dark:text-white text-right uppercase">
                                Total Pengeluaran
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-red-600 dark:text-red-400">
                                Rp {{ formatRupiah(total) }}
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';

const props = defineProps({
    expenses: Array,
    total: Number,
    month: String,
    categories: Array,
    capabilities: Array
});

const filterMonth = ref(props.month);

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const formatDate = (dateString) => {
    if (!dateString) return '-';
    const d = new Date(dateString);
    return new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }).format(d);
};

const applyFilter = () => {
    router.get(route('reports.pengeluaran'), { month: filterMonth.value }, { preserveState: true });
};

const printReport = () => {
    window.print();
};
</script>
