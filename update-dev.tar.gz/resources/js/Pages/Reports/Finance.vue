<template>
    <AppLayout title="Laba Rugi">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Laba Rugi (Profit & Loss)</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Ringkasan pendapatan bulanan dan pengeluaran operasional.</p>
            </div>
            
            <div class="flex items-center space-x-2">
                <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Tahun:</label>
                <select v-model="filterYear" @change="applyFilter" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                    <option v-for="y in availableYears" :key="y" :value="y">{{ y }}</option>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card class="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-800">
                <div class="text-sm font-medium text-indigo-800 dark:text-indigo-300 mb-1">Total Pendapatan {{ year }}</div>
                <div class="text-2xl font-bold text-indigo-900 dark:text-white">Rp {{ formatRupiah(yearTotal.pendapatan) }}</div>
            </Card>
            <Card class="bg-red-50 dark:bg-red-900/20 border-red-100 dark:border-red-800">
                <div class="text-sm font-medium text-red-800 dark:text-red-300 mb-1">Total Pengeluaran {{ year }}</div>
                <div class="text-2xl font-bold text-red-900 dark:text-white">Rp {{ formatRupiah(yearTotal.pengeluaran) }}</div>
            </Card>
            <Card class="bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800">
                <div class="text-sm font-medium text-emerald-800 dark:text-emerald-300 mb-1">Laba Bersih {{ year }}</div>
                <div class="text-2xl font-bold text-emerald-900 dark:text-white">Rp {{ formatRupiah(yearTotal.pendapatan - yearTotal.pengeluaran - yearTotal.ppn) }}</div>
                <div class="text-xs mt-1 text-emerald-700 dark:text-emerald-400">*Setelah dipotong PPN</div>
            </Card>
        </div>

        <Card title="Rincian Bulanan" bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Bulan</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-green-600">Pendapatan</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-orange-600">Potongan PPN</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-red-600">Pengeluaran</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-indigo-600">Laba Bersih</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="(data, index) in monthlyData" :key="index" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">
                                {{ data.month }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right font-medium text-green-600 dark:text-green-400">
                                Rp {{ formatRupiah(data.pendapatan) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-orange-600 dark:text-orange-400">
                                Rp {{ formatRupiah(data.ppn) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-red-600 dark:text-red-400">
                                Rp {{ formatRupiah(data.pengeluaran) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-indigo-600 dark:text-indigo-400">
                                Rp {{ formatRupiah(data.pendapatan - data.ppn - data.pengeluaran) }}
                            </td>
                        </tr>
                    </tbody>
                    <tfoot class="bg-slate-100 dark:bg-slate-800">
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-slate-900 dark:text-white uppercase">Total</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-green-600 dark:text-green-400">Rp {{ formatRupiah(yearTotal.pendapatan) }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-orange-600 dark:text-orange-400">Rp {{ formatRupiah(yearTotal.ppn) }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-red-600 dark:text-red-400">Rp {{ formatRupiah(yearTotal.pengeluaran) }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-indigo-600 dark:text-indigo-400">Rp {{ formatRupiah(yearTotal.pendapatan - yearTotal.ppn - yearTotal.pengeluaran) }}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { ref, computed } from 'vue';
import { router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';

const props = defineProps({
    monthlyData: Array,
    yearTotal: Object,
    year: [String, Number],
    capabilities: Array
});

const filterYear = ref(props.year);

// Generate list of years (e.g. from 2023 to current year + 1)
const availableYears = computed(() => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let y = currentYear - 3; y <= currentYear + 1; y++) {
        years.push(y);
    }
    return years.reverse();
});

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const applyFilter = () => {
    router.get(route('reports.finance'), { year: filterYear.value }, { preserveState: true });
};
</script>
