<template>
    <AppLayout title="Ringkasan Total Keuangan">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Ringkasan Total (Bulanan)</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Ikhtisar pendapatan, pengeluaran, PPN, dan setoran bulanan.</p>
            </div>
            
            <div class="flex items-center space-x-2">
                <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Bulan:</label>
                <input type="month" v-model="filterMonth" @change="applyFilter" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <Card class="bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-blue-100 dark:bg-blue-900 rounded-lg p-3">
                        <i class="bi bi-wallet2 text-blue-600 dark:text-blue-400 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <div class="text-sm font-medium text-blue-800 dark:text-blue-300">Pendapatan Kotor</div>
                        <div class="text-xl font-bold text-blue-900 dark:text-white">Rp {{ formatRupiah(pendapatan) }}</div>
                        <div class="text-xs text-blue-600 dark:text-blue-400 mt-1">{{ txnCount }} Transaksi</div>
                    </div>
                </div>
            </Card>

            <Card class="bg-orange-50 dark:bg-orange-900/20 border-orange-100 dark:border-orange-800">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-orange-100 dark:bg-orange-900 rounded-lg p-3">
                        <i class="bi bi-percent text-orange-600 dark:text-orange-400 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <div class="text-sm font-medium text-orange-800 dark:text-orange-300">Total PPN Dipungut</div>
                        <div class="text-xl font-bold text-orange-900 dark:text-white">Rp {{ formatRupiah(ppn) }}</div>
                    </div>
                </div>
            </Card>

            <Card class="bg-red-50 dark:bg-red-900/20 border-red-100 dark:border-red-800">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-red-100 dark:bg-red-900 rounded-lg p-3">
                        <i class="bi bi-cart-x text-red-600 dark:text-red-400 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <div class="text-sm font-medium text-red-800 dark:text-red-300">Pengeluaran</div>
                        <div class="text-xl font-bold text-red-900 dark:text-white">Rp {{ formatRupiah(pengeluaran) }}</div>
                    </div>
                </div>
            </Card>

            <Card class="bg-purple-50 dark:bg-purple-900/20 border-purple-100 dark:border-purple-800">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-purple-100 dark:bg-purple-900 rounded-lg p-3">
                        <i class="bi bi-box-arrow-in-down text-purple-600 dark:text-purple-400 text-xl"></i>
                    </div>
                    <div class="ml-4">
                        <div class="text-sm font-medium text-purple-800 dark:text-purple-300">Setoran Diterima</div>
                        <div class="text-xl font-bold text-purple-900 dark:text-white">Rp {{ formatRupiah(setoran) }}</div>
                    </div>
                </div>
            </Card>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card title="Kalkulasi Laba Bersih Bulan Ini">
                <div class="space-y-4">
                    <div class="flex justify-between items-center py-2 border-b dark:border-slate-700">
                        <span class="text-slate-600 dark:text-slate-400">Total Pendapatan (Kotor)</span>
                        <span class="font-medium text-slate-900 dark:text-white">Rp {{ formatRupiah(pendapatan) }}</span>
                    </div>
                    <div class="flex justify-between items-center py-2 border-b dark:border-slate-700">
                        <span class="text-slate-600 dark:text-slate-400">Dikurangi PPN ({{ formatRupiah(ppn) }})</span>
                        <span class="font-medium text-slate-900 dark:text-white">- Rp {{ formatRupiah(ppn) }}</span>
                    </div>
                    <div class="flex justify-between items-center py-2 border-b dark:border-slate-700">
                        <span class="text-slate-600 dark:text-slate-400">Dikurangi Pengeluaran ({{ formatRupiah(pengeluaran) }})</span>
                        <span class="font-medium text-slate-900 dark:text-white">- Rp {{ formatRupiah(pengeluaran) }}</span>
                    </div>
                    <div class="flex justify-between items-center py-3 bg-indigo-50 dark:bg-indigo-900/20 px-4 rounded-lg border border-indigo-100 dark:border-indigo-800">
                        <span class="font-bold text-indigo-900 dark:text-indigo-100">Estimasi Laba Bersih</span>
                        <span class="text-xl font-bold text-indigo-700 dark:text-indigo-400">Rp {{ formatRupiah(pendapatan - ppn - pengeluaran) }}</span>
                    </div>
                </div>
            </Card>

            <Card title="Status Uang Fisik / Setoran">
                <div class="space-y-4">
                    <p class="text-sm text-slate-500 dark:text-slate-400">
                        Halaman ini menunjukkan apakah dana yang masuk sudah disetorkan (jika ditagih oleh kolektor/mitra).
                    </p>
                    <div class="flex justify-between items-center py-2 border-b dark:border-slate-700">
                        <span class="text-slate-600 dark:text-slate-400">Total Pendapatan</span>
                        <span class="font-medium text-slate-900 dark:text-white">Rp {{ formatRupiah(pendapatan) }}</span>
                    </div>
                    <div class="flex justify-between items-center py-2 border-b dark:border-slate-700">
                        <span class="text-slate-600 dark:text-slate-400">Telah Disetorkan</span>
                        <span class="font-medium text-green-600 dark:text-green-400">Rp {{ formatRupiah(setoran) }}</span>
                    </div>
                    <div class="flex justify-between items-center py-3 bg-amber-50 dark:bg-amber-900/20 px-4 rounded-lg border border-amber-100 dark:border-amber-800">
                        <span class="font-bold text-amber-900 dark:text-amber-100">Uang Belum Disetor / Beredar</span>
                        <span class="text-xl font-bold text-amber-700 dark:text-amber-400">Rp {{ formatRupiah(pendapatan - setoran) }}</span>
                    </div>
                    <div class="text-xs text-slate-500 italic mt-2">
                        *Termasuk transaksi transfer bank yang mungkin belum dicatat sebagai setoran tunai.
                    </div>
                </div>
            </Card>
        </div>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';

const props = defineProps({
    pendapatan: Number,
    ppn: Number,
    txnCount: Number,
    pengeluaran: Number,
    setoran: Number,
    month: String,
    capabilities: Array
});

const filterMonth = ref(props.month);

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const applyFilter = () => {
    router.get(route('reports.total'), { month: filterMonth.value }, { preserveState: true });
};
</script>
