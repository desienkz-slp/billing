<template>
    <AppLayout title="Detail Pendapatan">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Detail Pendapatan Transaksi</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Rincian seluruh transaksi pembayaran yang berhasil (Paid) pada bulan terpilih.</p>
            </div>
            
            <div class="flex items-center space-x-2">
                <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Bulan:</label>
                <input type="month" v-model="filterMonth" @change="applyFilter" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card class="bg-indigo-50 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-800 flex items-center justify-between">
                <div>
                    <div class="text-sm font-medium text-indigo-800 dark:text-indigo-300 mb-1">Total Pendapatan (Bulan Ini)</div>
                    <div class="text-2xl font-bold text-indigo-900 dark:text-white">Rp {{ formatRupiah(totals.amount) }}</div>
                </div>
                <div class="text-indigo-200 dark:text-indigo-800/50">
                    <i class="bi bi-wallet2 text-5xl"></i>
                </div>
            </Card>
            <Card class="bg-blue-50 dark:bg-blue-900/20 border-blue-100 dark:border-blue-800 flex items-center justify-between">
                <div>
                    <div class="text-sm font-medium text-blue-800 dark:text-blue-300 mb-1">Jumlah Transaksi (Paid)</div>
                    <div class="text-2xl font-bold text-blue-900 dark:text-white">{{ formatRupiah(totals.count) }} Trx</div>
                </div>
                <div class="text-blue-200 dark:text-blue-800/50">
                    <i class="bi bi-receipt text-5xl"></i>
                </div>
            </Card>
        </div>

        <Card bodyClass="!p-0">
            <div class="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
                <div class="text-sm font-medium text-slate-700 dark:text-slate-300">Daftar Transaksi Berhasil</div>
                <Button @click="printReport" variant="secondary" size="sm">
                    <i class="bi bi-printer mr-1"></i> Cetak / PDF
                </Button>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tgl Pembayaran</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ID / Pelanggan</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Area</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Metode & Penerima</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Nominal Bayar</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="(payment, index) in payments" :key="payment.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                {{ index + 1 }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-900 dark:text-slate-300">
                                {{ formatDate(payment.payment_date) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-slate-900 dark:text-white">{{ payment.customer?.name || 'Unknown' }}</div>
                                <div class="text-xs text-slate-500">{{ payment.customer?.username || '-' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                {{ payment.customer?.area?.name || '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300">
                                    {{ payment.payment_method }}
                                </span>
                                <div class="text-xs text-slate-500 mt-1">Oleh: {{ payment.collector?.name || 'System' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-indigo-600 dark:text-indigo-400">
                                Rp {{ formatRupiah(payment.paid_amount) }}
                            </td>
                        </tr>
                        <tr v-if="payments.length === 0">
                            <td colspan="6" class="px-6 py-8 text-center text-slate-500">Tidak ada data transaksi pada bulan ini.</td>
                        </tr>
                    </tbody>
                    <tfoot v-if="payments.length > 0" class="bg-slate-50 dark:bg-slate-800/50 border-t-2 border-slate-200 dark:border-slate-700">
                        <tr>
                            <td colspan="5" class="px-6 py-4 whitespace-nowrap text-sm font-bold text-slate-900 dark:text-white text-right uppercase">
                                Total Pendapatan
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-indigo-700 dark:text-indigo-400">
                                Rp {{ formatRupiah(totals.amount) }}
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';

const props = defineProps({
    payments: Array,
    totals: Object,
    month: String,
    areas: Array,
    capabilities: Array
});

const filterMonth = ref(props.month);

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const formatDate = (dateString) => {
    if (!dateString) return '-';
    const d = new Date(dateString);
    return new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(d);
};

const applyFilter = () => {
    router.get(route('reports.detail-pendapatan'), { month: filterMonth.value }, { preserveState: true });
};

const printReport = () => {
    window.print();
};
</script>
