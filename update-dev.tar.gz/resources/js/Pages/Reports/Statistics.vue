<template>
    <AppLayout title="Statistik & Analisa">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Statistik & Analisa</h1>
            <p class="text-sm text-slate-500 dark:text-slate-400">Tinjauan visual performa bisnis, pertumbuhan pelanggan, dan tren pendapatan.</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <!-- Tren Pendapatan 12 Bulan -->
            <Card title="Tren Pendapatan (12 Bulan Terakhir)">
                <div class="h-64 flex items-end justify-between space-x-2 pt-4">
                    <div v-for="item in revenueMonthly" :key="item.period" class="relative flex flex-col items-center w-full group">
                        <div class="w-full bg-indigo-500 hover:bg-indigo-600 rounded-t transition-all duration-300"
                             :style="{ height: getRevenueHeight(item.total) + '%' }">
                            <div class="opacity-0 group-hover:opacity-100 absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded whitespace-nowrap z-10 transition-opacity">
                                Rp {{ formatRupiah(item.total) }}<br>{{ item.count }} trx
                            </div>
                        </div>
                        <div class="text-[10px] text-slate-500 mt-2 transform -rotate-45 origin-top-left translate-y-2 whitespace-nowrap">
                            {{ formatMonthShort(item.period) }}
                        </div>
                    </div>
                    <div v-if="revenueMonthly.length === 0" class="w-full h-full flex items-center justify-center text-slate-400 text-sm">
                        Belum ada data pendapatan
                    </div>
                </div>
            </Card>

            <!-- Pertumbuhan Pelanggan 6 Bulan -->
            <Card title="Pertumbuhan Pelanggan Baru (6 Bulan)">
                <div class="h-64 flex items-end justify-between space-x-4 pt-4">
                    <div v-for="item in customerGrowth" :key="item.period" class="relative flex flex-col items-center w-full group">
                        <div class="w-full bg-emerald-500 hover:bg-emerald-600 rounded-t transition-all duration-300"
                             :style="{ height: getCustomerHeight(item.count) + '%' }">
                            <div class="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded whitespace-nowrap z-10 transition-opacity">
                                {{ item.count }} Pelanggan
                            </div>
                        </div>
                        <div class="text-[10px] text-slate-500 mt-2 transform -rotate-45 origin-top-left translate-y-2 whitespace-nowrap">
                            {{ formatMonthShort(item.period) }}
                        </div>
                    </div>
                    <div v-if="customerGrowth.length === 0" class="w-full h-full flex items-center justify-center text-slate-400 text-sm">
                        Belum ada data pelanggan baru
                    </div>
                </div>
            </Card>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <!-- Distribusi Paket -->
            <Card title="Distribusi Paket Layanan">
                <div class="overflow-y-auto max-h-64">
                    <div v-for="item in packageDist" :key="item.package_id" class="mb-4 last:mb-0">
                        <div class="flex justify-between text-sm mb-1">
                            <span class="font-medium text-slate-700 dark:text-slate-300">{{ item.package?.name || 'Unknown' }}</span>
                            <span class="text-slate-500">{{ item.count }} user ({{ getPercentage(item.count, totalCustomers) }}%)</span>
                        </div>
                        <div class="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                            <div class="bg-blue-500 h-2 rounded-full" :style="{ width: getPercentage(item.count, totalCustomers) + '%' }"></div>
                        </div>
                    </div>
                    <div v-if="packageDist.length === 0" class="text-center py-8 text-slate-400 text-sm">
                        Belum ada data paket layanan
                    </div>
                </div>
            </Card>

            <!-- Metode Pembayaran Tahun Ini -->
            <Card title="Metode Pembayaran Paling Sering (Tahun Ini)">
                <div class="space-y-4 mt-2">
                    <div v-for="item in methodStats" :key="item.payment_method" class="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                        <div class="flex items-center">
                            <div class="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 mr-3">
                                <i class="bi" :class="getMethodIcon(item.payment_method)"></i>
                            </div>
                            <div>
                                <div class="font-medium text-slate-800 dark:text-white">{{ item.payment_method }}</div>
                                <div class="text-xs text-slate-500">{{ item.count }} Transaksi</div>
                            </div>
                        </div>
                        <div class="text-right font-bold text-slate-800 dark:text-white">
                            Rp {{ formatRupiah(item.total) }}
                        </div>
                    </div>
                    <div v-if="methodStats.length === 0" class="text-center py-8 text-slate-400 text-sm">
                        Belum ada data transaksi tahun ini
                    </div>
                </div>
            </Card>
        </div>
    </AppLayout>
</template>

<script setup>
import { computed } from 'vue';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';

const props = defineProps({
    revenueMonthly: Array,
    customerGrowth: Array,
    packageDist: Array,
    methodStats: Array,
    capabilities: Array
});

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const formatMonthShort = (period) => {
    if (!period) return '';
    const [year, month] = period.split('-');
    const date = new Date(year, parseInt(month) - 1, 1);
    return new Intl.DateTimeFormat('id-ID', { month: 'short', year: '2-digit' }).format(date);
};

// Revenue Chart calculations
const maxRevenue = computed(() => {
    if (!props.revenueMonthly || props.revenueMonthly.length === 0) return 1;
    return Math.max(...props.revenueMonthly.map(i => i.total)) || 1;
});

const getRevenueHeight = (amount) => {
    const minHeight = 5; // minimal 5% agar bar tetap terlihat
    return Math.max(minHeight, (amount / maxRevenue.value) * 100);
};

// Customer Growth Chart calculations
const maxCustomerGrowth = computed(() => {
    if (!props.customerGrowth || props.customerGrowth.length === 0) return 1;
    return Math.max(...props.customerGrowth.map(i => i.count)) || 1;
});

const getCustomerHeight = (count) => {
    const minHeight = 5;
    return Math.max(minHeight, (count / maxCustomerGrowth.value) * 100);
};

// Package Distribution
const totalCustomers = computed(() => {
    if (!props.packageDist) return 0;
    return props.packageDist.reduce((sum, item) => sum + item.count, 0);
});

const getPercentage = (count, total) => {
    if (!total) return 0;
    return Math.round((count / total) * 100);
};

// Payment Method Icon
const getMethodIcon = (method) => {
    const m = method.toLowerCase();
    if (m.includes('tunai') || m.includes('cash')) return 'bi-cash-coin';
    if (m.includes('transfer') || m.includes('bank')) return 'bi-bank';
    if (m.includes('ovo') || m.includes('gopay') || m.includes('dana') || m.includes('qris') || m.includes('wallet')) return 'bi-qr-code-scan';
    return 'bi-credit-card';
};
</script>
