<template>
    <AppLayout title="Arus Kas">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Arus Kas (Cash Flow) Harian</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Pemantauan detail pemasukan dan pengeluaran setiap hari dalam satu bulan.</p>
            </div>
            
            <div class="flex items-center space-x-2">
                <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Bulan:</label>
                <input type="month" v-model="filterMonth" @change="applyFilter" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Card class="bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800">
                <div class="text-sm font-medium text-emerald-800 dark:text-emerald-300 mb-1">Total Kas Masuk</div>
                <div class="text-2xl font-bold text-emerald-900 dark:text-white">Rp {{ formatRupiah(totalMasuk) }}</div>
            </Card>
            <Card class="bg-rose-50 dark:bg-rose-900/20 border-rose-100 dark:border-rose-800">
                <div class="text-sm font-medium text-rose-800 dark:text-rose-300 mb-1">Total Kas Keluar</div>
                <div class="text-2xl font-bold text-rose-900 dark:text-white">Rp {{ formatRupiah(totalKeluar) }}</div>
            </Card>
        </div>

        <Card title="Rincian Harian" bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tanggal</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-emerald-600">Kas Masuk (Rp)</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-rose-600">Kas Keluar (Rp)</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Net (Rp)</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="date in combinedDates" :key="date" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">
                                {{ formatDate(date) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right font-medium text-emerald-600 dark:text-emerald-400">
                                {{ getMasuk(date) > 0 ? formatRupiah(getMasuk(date)) : '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right font-medium text-rose-600 dark:text-rose-400">
                                {{ getKeluar(date) > 0 ? formatRupiah(getKeluar(date)) : '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right font-bold" :class="getNet(date) >= 0 ? 'text-indigo-600 dark:text-indigo-400' : 'text-red-600 dark:text-red-400'">
                                {{ formatRupiah(getNet(date)) }}
                            </td>
                        </tr>
                        <tr v-if="combinedDates.length === 0">
                            <td colspan="4" class="px-6 py-8 text-center text-slate-500">Tidak ada arus kas masuk/keluar pada bulan ini.</td>
                        </tr>
                    </tbody>
                    <tfoot v-if="combinedDates.length > 0" class="bg-slate-100 dark:bg-slate-800 border-t-2 border-slate-200 dark:border-slate-700">
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-slate-900 dark:text-white uppercase">Total</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-emerald-600 dark:text-emerald-400">{{ formatRupiah(totalMasuk) }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-rose-600 dark:text-rose-400">{{ formatRupiah(totalKeluar) }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-indigo-600 dark:text-indigo-400">{{ formatRupiah(totalMasuk - totalKeluar) }}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { ref, computed } from 'vue';
import { router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';

const props = defineProps({
    pemasukan: Array,
    pengeluaranHarian: Array,
    totalMasuk: Number,
    totalKeluar: Number,
    month: String,
    capabilities: Array
});

const filterMonth = ref(props.month);

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const formatDate = (dateString) => {
    if (!dateString) return '-';
    // Format: 12 Jan 2023
    const d = new Date(dateString);
    return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }).format(d);
};

const combinedDates = computed(() => {
    const dates = new Set();
    props.pemasukan.forEach(p => dates.add(p.tanggal));
    props.pengeluaranHarian.forEach(p => dates.add(p.tanggal));
    return Array.from(dates).sort();
});

const getMasuk = (date) => {
    const p = props.pemasukan.find(x => x.tanggal === date);
    return p ? p.total : 0;
};

const getKeluar = (date) => {
    const p = props.pengeluaranHarian.find(x => x.tanggal === date);
    return p ? p.total : 0;
};

const getNet = (date) => {
    return getMasuk(date) - getKeluar(date);
};

const applyFilter = () => {
    router.get(route('reports.cashflow'), { month: filterMonth.value }, { preserveState: true });
};
</script>
