<template>
    <AppLayout title="Laporan Kinerja Mitra">
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Laporan Kinerja Mitra (Sales / Teknisi)</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Tinjauan performa penagihan dan jumlah setoran dana masing-masing mitra.</p>
            </div>
            
            <div class="flex items-center space-x-2">
                <label class="text-sm font-medium text-slate-700 dark:text-slate-300">Bulan:</label>
                <input type="month" v-model="filterMonth" @change="applyFilter" class="rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
            </div>
        </div>

        <Card title="Rincian Kinerja Mitra" bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Mitra</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider text-blue-600">Trx Tertagih</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-blue-600">Total Ditagih (Rp)</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-green-600">Disetor ke Kasir (Rp)</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider text-amber-600">Belum Disetor (Rp)</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="sales in salesData" :key="sales.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ sales.name }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-center font-medium text-blue-600 dark:text-blue-400">
                                {{ sales.collected_count || 0 }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-blue-600 dark:text-blue-400">
                                {{ formatRupiah(sales.collected_total) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-green-600 dark:text-green-400">
                                {{ formatRupiah(sales.deposit_total) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right" :class="(sales.collected_total - sales.deposit_total) > 0 ? 'text-red-600 dark:text-red-400' : 'text-slate-500'">
                                {{ formatRupiah(sales.collected_total - sales.deposit_total) }}
                            </td>
                        </tr>
                        <tr v-if="salesData.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">Tidak ada aktivitas penagihan mitra pada bulan ini.</td>
                        </tr>
                    </tbody>
                    <tfoot v-if="salesData.length > 0" class="bg-slate-50 dark:bg-slate-800/50 border-t-2 border-slate-200 dark:border-slate-700">
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-slate-900 dark:text-white text-right uppercase">
                                Total Keseluruhan
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-center text-blue-700 dark:text-blue-400">
                                {{ salesData.reduce((s, a) => s + (a.collected_count || 0), 0) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-blue-700 dark:text-blue-400">
                                Rp {{ formatRupiah(salesData.reduce((s, a) => s + (a.collected_total || 0), 0)) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-green-700 dark:text-green-400">
                                Rp {{ formatRupiah(salesData.reduce((s, a) => s + (a.deposit_total || 0), 0)) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-right text-amber-700 dark:text-amber-400">
                                Rp {{ formatRupiah(salesData.reduce((s, a) => s + ((a.collected_total || 0) - (a.deposit_total || 0)), 0)) }}
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <div class="p-4 bg-amber-50 dark:bg-amber-900/10 border-t border-amber-200 dark:border-amber-800/30 text-xs text-amber-800 dark:text-amber-400">
                <i class="bi bi-info-circle mr-1"></i> Kolom "Belum Disetor" merupakan selisih antara uang yang berhasil ditagih oleh mitra dengan uang yang disetorkan ke kasir. Jika ada selisih, berarti dana tersebut masih dipegang oleh mitra atau dibayar via transfer langsung ke rekening utama tanpa melalui mitra.
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';

const props = defineProps({
    salesData: Array,
    month: String,
    capabilities: Array
});

const filterMonth = ref(props.month);

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const applyFilter = () => {
    router.get(route('reports.mitra'), { month: filterMonth.value }, { preserveState: true });
};
</script>
