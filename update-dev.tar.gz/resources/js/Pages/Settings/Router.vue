<template>
    <AppLayout title="Pengaturan Router MikroTik">
        <div class="mb-6 flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Pengaturan Router MikroTik</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Kelola daftar router MikroTik yang digunakan untuk PPPoE dan Hotspot.</p>
            </div>
            <Button @click="openModal(null)">
                <i class="bi bi-plus-lg mr-2"></i> Tambah Router
            </Button>
        </div>

        <Card class="!p-0 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama Router</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">IP Address</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Port (API)</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200 dark:divide-slate-700 bg-white dark:bg-slate-800">
                        <tr v-for="router in routers" :key="router.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span v-if="router.is_active" class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">Aktif</span>
                                <span v-else class="px-2 py-1 text-xs font-medium rounded-full bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300">Nonaktif</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap font-medium text-slate-900 dark:text-white">
                                {{ router.name }}
                                <div class="text-xs text-slate-500 font-normal">{{ router.location }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono">{{ router.ip_address }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono">{{ router.port }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button @click="testConnection(router)" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 mr-3" title="Test Koneksi">Test</button>
                                <button @click="openModal(router)" class="text-blue-600 hover:text-blue-900 dark:text-blue-400 mr-3">Edit</button>
                                <button @click="deleteRouter(router)" class="text-red-600 hover:text-red-900 dark:text-red-400">Hapus</button>
                            </td>
                        </tr>
                        <tr v-if="routers.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">Belum ada data router.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { router as inertiaRouter } from '@inertiajs/vue3';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';

const props = defineProps({
    routers: Array
});

const openModal = (router) => {
    alert('Fitur edit/tambah router sedang dalam pengembangan UI. Gunakan seeder untuk dev.');
};

const deleteRouter = (router) => {
    if (confirm(`Hapus router ${router.name}?`)) {
        inertiaRouter.delete(route('settings.routers.destroy', router.id));
    }
};

const testConnection = async (routerItem) => {
    try {
        const res = await axios.post(route('settings.routers.test', routerItem.id));
        alert(res.data.message);
    } catch (e) {
        alert('Gagal test koneksi.');
    }
};
</script>
