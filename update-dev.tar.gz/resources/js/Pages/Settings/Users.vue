<template>
    <AppLayout title="Pengaturan Pengguna">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Manajemen Pengguna</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Kelola akun dan peran pengguna untuk sistem ini.</p>
            </div>
            <Button v-if="capabilities.can_manage_users" @click="openModal(null)">
                <i class="bi bi-person-plus mr-2"></i> Tambah Pengguna
            </Button>
        </div>

        <Card bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama & Kontak</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Username</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Role</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="u in users" :key="u.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-10 w-10 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-bold">
                                        {{ u.name.charAt(0).toUpperCase() }}
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-medium text-slate-900 dark:text-white">
                                            {{ u.name }}
                                            <span v-if="u.is_default_sales" class="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800">Default Sales</span>
                                        </div>
                                        <div class="text-sm text-slate-500">{{ u.phone || u.email || '-' }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-slate-900 dark:text-slate-300">{{ u.username }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">
                                    {{ u.role ? u.role.name : 'Superadmin' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <span :class="u.is_active ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'" class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
                                    {{ u.is_active ? 'Aktif' : 'Nonaktif' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                <template v-if="capabilities.can_manage_users">
                                    <button @click="openModal(u)" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300">Edit</button>
                                    <button v-if="!u.is_system_admin" @click="toggleStatus(u)" :class="u.is_active ? 'text-red-600 hover:text-red-900 dark:text-red-400' : 'text-green-600 hover:text-green-900 dark:text-green-400'">
                                        {{ u.is_active ? 'Nonaktifkan' : 'Aktifkan' }}
                                    </button>
                                    <button v-if="!u.is_default_sales && !u.is_system_admin" @click="setAsDefaultSales(u)" class="text-amber-600 hover:text-amber-900 dark:text-amber-400 ml-2">Jadikan Sales</button>
                                </template>
                            </td>
                        </tr>
                        <tr v-if="users.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">Tidak ada pengguna ditemukan.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>

        <Modal :show="showModal" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-medium text-slate-900 dark:text-white mb-4">
                    {{ isEditing ? 'Edit Pengguna' : 'Tambah Pengguna Baru' }}
                </h2>
                
                <form @submit.prevent="submitForm">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <Input label="Nama Lengkap" v-model="form.name" :error="form.errors.name" required />
                        </div>
                        <div>
                            <Input label="Username" v-model="form.username" :error="form.errors.username" required :disabled="isEditing" />
                        </div>
                        <div>
                            <Input label="No Telepon" v-model="form.phone" :error="form.errors.phone" />
                        </div>
                        <div>
                            <Input label="Email" type="email" v-model="form.email" :error="form.errors.email" />
                        </div>
                        <div>
                            <Input label="Password" type="password" v-model="form.password" :error="form.errors.password" :required="!isEditing" :placeholder="isEditing ? 'Kosongkan jika tidak diubah' : ''" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Role/Peran</label>
                            <select v-model="form.role_id" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="" disabled>-- Pilih Role --</option>
                                <option v-for="r in roles" :key="r.id" :value="r.id">{{ r.name }}</option>
                            </select>
                            <div v-if="form.errors.role_id" class="mt-1 text-sm text-red-600">{{ form.errors.role_id }}</div>
                        </div>
                        
                        <div class="md:col-span-2 border-t border-slate-200 dark:border-slate-700 pt-4 mt-2">
                            <h3 class="text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">Pengaturan Fee Kolektor (Opsional)</h3>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <Input label="Fee Persen (%)" type="number" step="0.1" v-model="form.fee_persen" :error="form.errors.fee_persen" />
                                <Input label="Fee Nominal (Rp)" type="number" v-model="form.fee_fix" :error="form.errors.fee_fix" />
                            </div>
                        </div>
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="closeModal">Batal</Button>
                        <Button type="submit" :disabled="form.processing">
                            {{ form.processing ? 'Menyimpan...' : 'Simpan Pengguna' }}
                        </Button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { useForm, router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    users: Array,
    roles: Array,
    capabilities: Object,
});

const showModal = ref(false);
const isEditing = ref(false);
const targetUserId = ref(null);

const form = useForm({
    name: '',
    username: '',
    email: '',
    phone: '',
    password: '',
    role_id: '',
    fee_persen: 0,
    fee_fix: 0,
});

const openModal = (user = null) => {
    isEditing.value = !!user;
    if (user) {
        targetUserId.value = user.id;
        form.name = user.name;
        form.username = user.username;
        form.email = user.email || '';
        form.phone = user.phone || '';
        form.password = '';
        form.role_id = user.role_id || '';
        form.fee_persen = user.fee_persen || 0;
        form.fee_fix = user.fee_fix || 0;
    } else {
        targetUserId.value = null;
        form.reset();
    }
    showModal.value = true;
};

const closeModal = () => {
    showModal.value = false;
    form.reset();
    form.clearErrors();
};

const submitForm = () => {
    if (isEditing.value) {
        form.put(route('settings.users.update', targetUserId.value), {
            onSuccess: () => closeModal()
        });
    } else {
        form.post(route('settings.users.store'), {
            onSuccess: () => closeModal()
        });
    }
};

const toggleStatus = (user) => {
    if (confirm(`Apakah Anda yakin ingin ${user.is_active ? 'menonaktifkan' : 'mengaktifkan'} pengguna ini?`)) {
        router.post(route('settings.users.toggle', user.id), {}, { preserveScroll: true });
    }
};

const setAsDefaultSales = (user) => {
    if (confirm(`Jadikan ${user.name} sebagai Penanggung Jawab Default?`)) {
        router.post(route('settings.users.default_sales', user.id), {}, { preserveScroll: true });
    }
};
</script>
