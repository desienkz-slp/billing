<template>
    <AppLayout title="Template Nota / Struk">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white">🧾 Template Nota (Struk)</h1>
            <p class="text-sm text-slate-500 dark:text-slate-400">Konfigurasi cetakan struk penerimaan pembayaran.</p>
        </div>

        <Card>
            <p class="text-sm text-slate-600 dark:text-slate-400 mb-6">
                Template nota digunakan untuk format cetak struk penerimaan tagihan via printer kasir / thermal. Anda dapat mengatur informasi header dan footer yang akan muncul pada struk.
            </p>
            
            <div class="p-12 text-center bg-slate-50 dark:bg-slate-800/50 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700">
                <div class="text-6xl mb-4">🖨️</div>
                <h3 class="text-xl font-bold text-slate-800 dark:text-white mb-2">Fitur Segera Hadir</h3>
                <p class="text-slate-500 dark:text-slate-400">
                    Fitur editor struk kasir termal saat ini masih dalam tahap penyempurnaan UI/UX. Silakan cek kembali dalam waktu dekat!
                </p>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
</script>
