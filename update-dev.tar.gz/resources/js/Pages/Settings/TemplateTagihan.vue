<template>
    <AppLayout title="Template Tagihan">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white">📄 Template Tagihan</h1>
            <p class="text-sm text-slate-500 dark:text-slate-400">Konfigurasi format laporan tagihan bulanan.</p>
        </div>

        <Card>
            <p class="text-sm text-slate-600 dark:text-slate-400 mb-6">
                Template tagihan digunakan untuk format cetak atau PDF tagihan bulanan pelanggan. Konfigurasi ini akan diterapkan secara global untuk semua laporan tagihan pada tenant Anda.
            </p>
            
            <div class="p-12 text-center bg-slate-50 dark:bg-slate-800/50 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700">
                <div class="text-6xl mb-4">📋</div>
                <h3 class="text-xl font-bold text-slate-800 dark:text-white mb-2">Fitur Segera Hadir</h3>
                <p class="text-slate-500 dark:text-slate-400">
                    Fitur kustomisasi template tagihan tingkat lanjut saat ini sedang dalam pengembangan. Nantikan pembaruan berikutnya!
                </p>
            </div>
        </Card>
    </AppLayout>
</template>

<script setup>
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
</script>
