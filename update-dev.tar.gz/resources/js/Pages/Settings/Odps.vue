<template>
    <AppLayout title="Manajemen ODP">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Optical Distribution Point (ODP)</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Pusat distribusi jaringan optik untuk alokasi port pelanggan.</p>
            </div>
            <Button v-if="capabilities.can_manage_odp" @click="openModal()">
                <i class="bi bi-diagram-3 mr-2"></i> Tambah ODP
            </Button>
        </div>

        <Card bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ODP / Kode</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Lokasi & Area</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Kapasitas (Port)</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Pelanggan Aktif</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="o in odps" :key="o.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ o.name }}</div>
                                <div class="text-xs text-slate-500 font-mono">{{ o.code || '-' }}</div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-sm text-slate-900 dark:text-slate-300">{{ o.location || '-' }}</div>
                                <div class="text-xs text-indigo-600 dark:text-indigo-400 font-medium">{{ o.area?.name || 'Area tidak diset' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <span class="px-2 py-1 rounded bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-sm">
                                    {{ o.total_ports }} Port
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <div class="flex items-center justify-center">
                                    <div class="w-full bg-slate-200 rounded-full h-2.5 dark:bg-slate-700 max-w-[4rem] mr-2">
                                        <div class="bg-indigo-600 h-2.5 rounded-full" :style="{ width: ((o.customers_count / (o.total_ports || 1)) * 100) + '%' }"></div>
                                    </div>
                                    <span class="text-sm font-medium text-slate-700 dark:text-slate-300">{{ o.customers_count }}</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-3">
                                <template v-if="capabilities.can_manage_odp">
                                    <button @click="deleteOdp(o)" class="text-red-600 hover:text-red-900 dark:text-red-400"><i class="bi bi-trash"></i> Hapus</button>
                                </template>
                            </td>
                        </tr>
                        <tr v-if="odps.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">Belum ada perangkat ODP yang ditambahkan.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>

        <!-- Form Modal -->
        <Modal :show="showModal" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-medium text-slate-900 dark:text-white mb-4">
                    Tambah ODP Baru
                </h2>
                
                <form @submit.prevent="submitForm">
                    <div class="space-y-4">
                        <Input label="Nama ODP" v-model="form.name" :error="form.errors.name" required placeholder="ODP-M-01" />
                        <Input label="Kode Identitas (Opsional)" v-model="form.code" :error="form.errors.code" />
                        
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Area / Wilayah</label>
                            <select v-model="form.area_id" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="" disabled>-- Pilih Area --</option>
                                <option v-for="a in areas" :key="a.id" :value="a.id">{{ a.name }}</option>
                            </select>
                            <div v-if="form.errors.area_id" class="text-sm text-red-600 mt-1">{{ form.errors.area_id }}</div>
                        </div>

                        <Input label="Lokasi Detail / Alamat" v-model="form.location" :error="form.errors.location" />
                        <Input label="Kapasitas Port" type="number" min="1" max="128" v-model="form.total_ports" :error="form.errors.total_ports" required />
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="closeModal">Batal</Button>
                        <Button type="submit" :disabled="form.processing">Simpan ODP</Button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { useForm, router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    odps: Array,
    areas: Array,
    capabilities: Object,
});

const showModal = ref(false);

const form = useForm({
    name: '',
    code: '',
    area_id: '',
    location: '',
    total_ports: 8,
});

const openModal = () => {
    form.reset();
    showModal.value = true;
};

const closeModal = () => {
    showModal.value = false;
    form.reset();
    form.clearErrors();
};

const submitForm = () => {
    form.post(route('settings.odps.store'), {
        onSuccess: () => closeModal()
    });
};

const deleteOdp = (odp) => {
    if (confirm(`Hapus ODP ${odp.name}?`)) {
        router.delete(route('settings.odps.destroy', odp.id), { preserveScroll: true });
    }
};
</script>
