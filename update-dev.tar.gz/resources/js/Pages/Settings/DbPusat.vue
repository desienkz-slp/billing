<template>
    <AppLayout title="Pengaturan Database Pusat">
        <div class="max-w-4xl mx-auto">
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Pengaturan Database Pusat</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Konfigurasi koneksi ke server RADIUS pusat (FreeRADIUS / RadiusDesk / daloRADIUS).</p>
            </div>

            <Card>
                <form @submit.prevent="submit" class="space-y-6">
                    <div class="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                        <div class="sm:col-span-2">
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300">Radius Database Host</label>
                            <div class="mt-1">
                                <input type="text" v-model="form.radius_db_host" class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-slate-300 rounded-md dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300">Radius Database Port</label>
                            <div class="mt-1">
                                <input type="text" v-model="form.radius_db_port" class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-slate-300 rounded-md dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300">Radius Database Name</label>
                            <div class="mt-1">
                                <input type="text" v-model="form.radius_db_name" class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-slate-300 rounded-md dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300">Radius Database User</label>
                            <div class="mt-1">
                                <input type="text" v-model="form.radius_db_user" class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-slate-300 rounded-md dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300">Radius Database Password</label>
                            <div class="mt-1">
                                <input type="password" v-model="form.radius_db_pass" class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-slate-300 rounded-md dark:bg-slate-900 dark:border-slate-600 dark:text-white">
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-700 mt-6">
                        <Button type="button" variant="secondary" @click="testConnection" :disabled="testing">
                            <i class="bi bi-arrow-repeat mr-2" :class="{'animate-spin': testing}"></i>
                            {{ testing ? 'Menguji...' : 'Test Koneksi' }}
                        </Button>
                        <Button type="submit" :disabled="form.processing">
                            Simpan Pengaturan
                        </Button>
                    </div>
                </form>
            </Card>
        </div>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { useForm } from '@inertiajs/vue3';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';

const props = defineProps({
    configs: Object
});

const form = useForm({
    radius_db_host: props.configs.radius_db_host || '127.0.0.1',
    radius_db_port: props.configs.radius_db_port || '3306',
    radius_db_name: props.configs.radius_db_name || 'radius',
    radius_db_user: props.configs.radius_db_user || 'radius',
    radius_db_pass: props.configs.radius_db_pass || '',
});

const testing = ref(false);

const submit = () => {
    form.post(route('settings.db-pusat.update'), {
        preserveScroll: true,
        onSuccess: () => alert('Konfigurasi database berhasil disimpan.'),
    });
};

const testConnection = async () => {
    testing.value = true;
    try {
        const res = await axios.post(route('settings.db-pusat.test'), form.data());
        alert(res.data.message);
    } catch (e) {
        alert('Gagal test koneksi ke database.');
    } finally {
        testing.value = false;
    }
};
</script>
