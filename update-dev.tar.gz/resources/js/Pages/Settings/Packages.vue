<template>
    <AppLayout title="Paket Layanan">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Manajemen Paket</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Daftar layanan dan sinkronisasi profil router/database pusat.</p>
            </div>
            <Button v-if="capabilities.can_manage_packages" @click="openModal(null)">
                <i class="bi bi-plus-lg mr-2"></i> Tambah Paket
            </Button>
        </div>

        <Card bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Paket</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Harga & PPN</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Router Profile</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">DB Pusat Profile</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="p in packages" :key="p.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ p.name }}</div>
                                <div class="text-xs text-slate-500">{{ p.description || '-' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-slate-900 dark:text-white font-semibold">Rp {{ formatNumber(p.price) }}</div>
                                <div class="text-xs text-slate-500">PPN: {{ p.is_ppn ? 'Ya (' + p.ppn_percentage + '%)' : 'Tidak' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                                <div><span class="font-medium">Router:</span> {{ p.router ? p.router.name : 'Tidak Terhubung' }}</div>
                                <div><span class="font-medium">Profile:</span> {{ p.router_profile || 'Tidak diset' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">
                                {{ p.db_pusat_profile || 'Tidak diset' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-3">
                                <template v-if="capabilities.can_manage_packages">
                                    <button @click="openModal(p)" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400">Edit</button>
                                    <button @click="deletePackage(p)" class="text-red-600 hover:text-red-900 dark:text-red-400">Hapus</button>
                                </template>
                            </td>
                        </tr>
                        <tr v-if="packages.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">Belum ada data paket layanan.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>

        <!-- Form Modal -->
        <Modal :show="showModal" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-medium text-slate-900 dark:text-white mb-4">
                    {{ isEditing ? 'Edit Paket' : 'Tambah Paket' }}
                </h2>
                
                <form @submit.prevent="submitForm">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="md:col-span-2">
                            <Input label="Nama Paket" v-model="form.name" :error="form.errors.name" required />
                        </div>
                        <div class="md:col-span-2">
                            <Input label="Deskripsi" v-model="form.description" :error="form.errors.description" />
                        </div>
                        <div>
                            <Input label="Harga (Rp)" type="number" v-model="form.price" :error="form.errors.price" required />
                        </div>
                        <div>
                            <Input label="PPN (%)" type="number" step="0.1" v-model="form.ppn_percentage" :error="form.errors.ppn_percentage" :disabled="!form.is_ppn" />
                            <label class="inline-flex items-center mt-2">
                                <input type="checkbox" v-model="form.is_ppn" class="rounded border-slate-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" />
                                <span class="ml-2 text-sm text-slate-600 dark:text-slate-400">Aktifkan PPN</span>
                            </label>
                        </div>
                        
                        <div class="md:col-span-2 border-t border-slate-200 dark:border-slate-700 mt-4 pt-4">
                            <h3 class="text-md font-medium text-slate-700 dark:text-slate-300 mb-3">Integrasi (Opsional)</h3>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Router Mikrotik</label>
                            <select v-model="form.router_id" @change="fetchRouterProfiles" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Tanpa Router --</option>
                                <option v-for="r in routers" :key="r.id" :value="r.id">{{ r.name }} ({{ r.host }})</option>
                            </select>
                            <div v-if="form.errors.router_id" class="text-sm text-red-600 mt-1">{{ form.errors.router_id }}</div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Profile Mikrotik (Hotspot/PPPoE)</label>
                            <select v-model="form.router_profile" :disabled="!form.router_id || fetchingProfiles" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Pilih Profile --</option>
                                <option v-for="p in routerProfiles" :key="p" :value="p">{{ p }}</option>
                            </select>
                            <div v-if="form.errors.router_profile" class="text-sm text-red-600 mt-1">{{ form.errors.router_profile }}</div>
                        </div>

                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Profile Database Pusat</label>
                            <select v-model="form.db_pusat_profile" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="">-- Tanpa Sinkronisasi --</option>
                                <option v-for="dbp in db_pusat_profiles" :key="dbp" :value="dbp">{{ dbp }}</option>
                            </select>
                            <div v-if="form.errors.db_pusat_profile" class="text-sm text-red-600 mt-1">{{ form.errors.db_pusat_profile }}</div>
                        </div>
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="closeModal">Batal</Button>
                        <Button type="submit" :disabled="form.processing">Simpan Paket</Button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>

<script setup>
import { ref, watch } from 'vue';
import { useForm, router } from '@inertiajs/vue3';
import axios from 'axios';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    packages: Array,
    routers: Array,
    db_pusat_profiles: Array,
    capabilities: Object,
});

const showModal = ref(false);
const isEditing = ref(false);
const targetId = ref(null);
const routerProfiles = ref([]);
const fetchingProfiles = ref(false);

const form = useForm({
    name: '',
    description: '',
    price: 0,
    is_ppn: false,
    ppn_percentage: 11,
    router_id: '',
    router_profile: '',
    db_pusat_profile: '',
});

const formatNumber = (num) => {
    return new Intl.NumberFormat('id-ID').format(num);
};

const openModal = (pkg = null) => {
    isEditing.value = !!pkg;
    routerProfiles.value = [];
    if (pkg) {
        targetId.value = pkg.id;
        form.name = pkg.name;
        form.description = pkg.description || '';
        form.price = pkg.price;
        form.is_ppn = pkg.is_ppn;
        form.ppn_percentage = pkg.ppn_percentage || 11;
        form.router_id = pkg.router_id || '';
        form.router_profile = pkg.router_profile || '';
        form.db_pusat_profile = pkg.db_pusat_profile || '';
        
        if (pkg.router_id) {
            fetchRouterProfiles();
        }
    } else {
        targetId.value = null;
        form.reset();
    }
    showModal.value = true;
};

const closeModal = () => {
    showModal.value = false;
    form.reset();
    form.clearErrors();
};

const submitForm = () => {
    if (isEditing.value) {
        form.put(route('settings.packages.update', targetId.value), {
            onSuccess: () => closeModal()
        });
    } else {
        form.post(route('settings.packages.store'), {
            onSuccess: () => closeModal()
        });
    }
};

const deletePackage = (pkg) => {
    if (confirm(`Hapus paket ${pkg.name}? Pelanggan yang menggunakan paket ini mungkin terdampak.`)) {
        router.delete(route('settings.packages.destroy', pkg.id), { preserveScroll: true });
    }
};

const fetchRouterProfiles = async () => {
    if (!form.router_id) {
        routerProfiles.value = [];
        form.router_profile = '';
        return;
    }
    
    fetchingProfiles.value = true;
    try {
        const response = await axios.get(route('settings.packages.router-profiles', form.router_id));
        routerProfiles.value = response.data;
    } catch (e) {
        alert("Gagal mengambil daftar profile dari router. Pastikan koneksi API router aktif.");
        console.error(e);
    } finally {
        fetchingProfiles.value = false;
    }
};
</script>
