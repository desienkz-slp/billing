<template>
    <AppLayout title="Manajemen ODC">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Optical Distribution Cabinet (ODC)</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Lemari distribusi optik untuk menyalurkan koneksi dari OLT ke ODP.</p>
            </div>
            <Button v-if="capabilities.can_manage_odp" @click="openModal(null)">
                <i class="bi bi-box mr-2"></i> Tambah ODC
            </Button>
        </div>

        <Card bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ODC / Kode</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Lokasi & Area</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Kapasitas (Port)</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">ODP Terhubung</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="o in odcs" :key="o.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white">{{ o.name }}</div>
                                <div class="text-xs text-slate-500 font-mono">{{ o.code || '-' }}</div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-sm text-slate-900 dark:text-slate-300">{{ o.location || '-' }}</div>
                                <div class="text-xs text-indigo-600 dark:text-indigo-400 font-medium">{{ o.area?.name || 'Area tidak diset' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <span class="px-2 py-1 rounded bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-sm">
                                    {{ o.total_ports }} Port
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <div class="flex items-center justify-center">
                                    <span class="text-sm font-bold text-slate-700 dark:text-slate-300">{{ o.odps_count }}</span>
                                    <span class="text-xs text-slate-500 ml-1">/ {{ o.total_ports }}</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-3">
                                <template v-if="capabilities.can_manage_odp">
                                    <button @click="openModal(o)" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400">Edit</button>
                                    <button @click="deleteOdc(o)" class="text-red-600 hover:text-red-900 dark:text-red-400">Hapus</button>
                                </template>
                            </td>
                        </tr>
                        <tr v-if="odcs.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">Belum ada perangkat ODC yang ditambahkan.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>

        <!-- Form Modal -->
        <Modal :show="showModal" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-medium text-slate-900 dark:text-white mb-4">
                    {{ isEditing ? 'Edit ODC' : 'Tambah ODC Baru' }}
                </h2>
                
                <form @submit.prevent="submitForm">
                    <div class="space-y-4">
                        <Input label="Nama ODC" v-model="form.name" :error="form.errors.name" required placeholder="ODC-M-01" />
                        <Input label="Kode Identitas (Opsional)" v-model="form.code" :error="form.errors.code" />
                        
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Area / Wilayah</label>
                            <select v-model="form.area_id" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="" disabled>-- Pilih Area --</option>
                                <option v-for="a in areas" :key="a.id" :value="a.id">{{ a.name }}</option>
                            </select>
                            <div v-if="form.errors.area_id" class="text-sm text-red-600 mt-1">{{ form.errors.area_id }}</div>
                        </div>

                        <Input label="Lokasi Detail / Alamat" v-model="form.location" :error="form.errors.location" />
                        <Input label="Kapasitas Port" type="number" min="1" max="1024" v-model="form.total_ports" :error="form.errors.total_ports" required />
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="closeModal">Batal</Button>
                        <Button type="submit" :disabled="form.processing">Simpan ODC</Button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { useForm, router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    odcs: Array,
    areas: Array,
    capabilities: Object,
});

const showModal = ref(false);
const isEditing = ref(false);
const targetId = ref(null);

const form = useForm({
    name: '',
    code: '',
    area_id: '',
    location: '',
    total_ports: 16,
});

const openModal = (odc = null) => {
    isEditing.value = !!odc;
    if (odc) {
        targetId.value = odc.id;
        form.name = odc.name;
        form.code = odc.code || '';
        form.area_id = odc.area_id || '';
        form.location = odc.location || '';
        form.total_ports = odc.total_ports;
    } else {
        targetId.value = null;
        form.reset();
    }
    showModal.value = true;
};

const closeModal = () => {
    showModal.value = false;
    form.reset();
    form.clearErrors();
};

const submitForm = () => {
    if (isEditing.value) {
        form.put(route('settings.odcs.update', targetId.value), {
            onSuccess: () => closeModal()
        });
    } else {
        form.post(route('settings.odcs.store'), {
            onSuccess: () => closeModal()
        });
    }
};

const deleteOdc = (odc) => {
    if (confirm(`Hapus ODC ${odc.name}?`)) {
        router.delete(route('settings.odcs.destroy', odc.id), { preserveScroll: true });
    }
};
</script>
