<template>
    <AppLayout title="Manajemen Area">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Wilayah & Area</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Kelola zona layanan untuk memetakan pelanggan dan ODP.</p>
            </div>
            <Button v-if="capabilities.can_manage_areas" @click="openModal(null)">
                <i class="bi bi-geo-alt mr-2"></i> Tambah Area
            </Button>
        </div>

        <Card bodyClass="!p-0">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Nama Area</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Deskripsi</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Total Pelanggan</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="a in areas" :key="a.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-slate-900 dark:text-white"><i class="bi bi-geo-alt-fill text-red-500 mr-2"></i>{{ a.name }}</div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-sm text-slate-500 dark:text-slate-400">{{ a.description || '-' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-center">
                                <span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">
                                    {{ a.customers_count }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <!-- Example aksi, bisa diedit jika controller mendukung update -->
                                <span class="text-slate-400 text-xs italic">Read-only view</span>
                            </td>
                        </tr>
                        <tr v-if="areas.length === 0">
                            <td colspan="4" class="px-6 py-8 text-center text-slate-500">Belum ada area yang ditambahkan.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>

        <!-- Form Modal -->
        <Modal :show="showModal" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-medium text-slate-900 dark:text-white mb-4">
                    Tambah Area Baru
                </h2>
                
                <form @submit.prevent="submitForm">
                    <div class="space-y-4">
                        <Input label="Nama Area" v-model="form.name" :error="form.errors.name" required placeholder="Contoh: Perumahan Graha 1" />
                        <Input label="Deskripsi" v-model="form.description" :error="form.errors.description" />
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="closeModal">Batal</Button>
                        <Button type="submit" :disabled="form.processing">Simpan Area</Button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { useForm, router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    areas: Array,
    capabilities: Object,
});

const showModal = ref(false);

const form = useForm({
    name: '',
    description: '',
});

const openModal = () => {
    form.reset();
    showModal.value = true;
};

const closeModal = () => {
    showModal.value = false;
    form.reset();
    form.clearErrors();
};

const submitForm = () => {
    form.post(route('settings.areas.store'), {
        onSuccess: () => closeModal()
    });
};
</script>
