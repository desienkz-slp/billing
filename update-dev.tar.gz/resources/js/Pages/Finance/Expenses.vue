<template>
    <AppLayout title="Manajemen Pengeluaran">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Pengeluaran Operasional</h1>
                <p class="text-sm text-slate-500 dark:text-slate-400">Catat dan kelola semua biaya pengeluaran bulanan.</p>
            </div>
            <Button @click="openModal()">
                <i class="bi bi-plus-lg mr-2"></i> Tambah Pengeluaran
            </Button>
        </div>

        <Card bodyClass="!p-0 mb-6">
            <div class="p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex flex-wrap gap-4 items-end">
                <div class="w-full sm:w-auto">
                    <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Periode Bulan</label>
                    <input type="month" v-model="filter.bulan" @change="applyFilter" class="block w-full sm:w-48 rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
                </div>
                <div class="flex-grow flex justify-end items-center">
                    <div class="text-right">
                        <div class="text-sm text-slate-500">Total Pengeluaran Bulan Ini</div>
                        <div class="text-xl font-bold text-red-600 dark:text-red-400">Rp {{ formatRupiah(total) }}</div>
                    </div>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tanggal</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Kategori</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Keterangan</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Nominal (Rp)</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="expense in expenses.data" :key="expense.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-900 dark:text-slate-300">
                                {{ expense.expense_date }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300">
                                    {{ expense.category }}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-900 dark:text-slate-300">
                                {{ expense.description }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-red-600 dark:text-red-400 text-right">
                                {{ formatRupiah(expense.amount) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button @click="deleteExpense(expense)" class="text-red-600 hover:text-red-900 dark:text-red-400">Hapus</button>
                            </td>
                        </tr>
                        <tr v-if="expenses.data.length === 0">
                            <td colspan="5" class="px-6 py-8 text-center text-slate-500">Belum ada catatan pengeluaran pada bulan ini.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50" v-if="expenses.links && expenses.links.length > 3">
                <!-- Pagination placeholder -->
                <div class="flex flex-wrap gap-1 justify-center">
                    <template v-for="(link, key) in expenses.links" :key="key">
                        <Link v-if="link.url" :href="link.url" class="px-3 py-1 text-sm border rounded hover:bg-slate-200 dark:hover:bg-slate-700" :class="link.active ? 'bg-indigo-600 text-white border-indigo-600 hover:bg-indigo-700' : 'bg-white text-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-600'" v-html="link.label"></Link>
                        <span v-else class="px-3 py-1 text-sm border rounded bg-slate-100 text-slate-400 cursor-not-allowed dark:bg-slate-800/50 dark:border-slate-700" v-html="link.label"></span>
                    </template>
                </div>
            </div>
        </Card>

        <!-- Form Modal -->
        <Modal :show="showModal" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-medium text-slate-900 dark:text-white mb-4">
                    Tambah Pengeluaran
                </h2>
                
                <form @submit.prevent="submitForm">
                    <div class="space-y-4">
                        <Input label="Tanggal" type="date" v-model="form.expense_date" :error="form.errors.expense_date" required />
                        
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Kategori</label>
                            <select v-model="form.category" required class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white">
                                <option value="" disabled>-- Pilih Kategori --</option>
                                <option v-for="c in categories" :key="c" :value="c">{{ c }}</option>
                            </select>
                            <div v-if="form.errors.category" class="text-sm text-red-600 mt-1">{{ form.errors.category }}</div>
                        </div>

                        <Input label="Nominal (Rp)" type="number" min="1" v-model="form.amount" :error="form.errors.amount" required />
                        <Input label="Keterangan" v-model="form.description" :error="form.errors.description" required placeholder="Contoh: Beli kabel FO 1 roll" />
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="closeModal">Batal</Button>
                        <Button type="submit" :disabled="form.processing">Simpan Pengeluaran</Button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { useForm, router, Link } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    expenses: Object,
    total: Number,
    bulan: String,
    categories: Array
});

const filter = ref({
    bulan: props.bulan
});

const showModal = ref(false);

const form = useForm({
    expense_date: new Date().toISOString().split('T')[0],
    category: '',
    description: '',
    amount: '',
});

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const applyFilter = () => {
    router.get(route('expenses.index'), { bulan: filter.value.bulan }, { preserveState: true });
};

const openModal = () => {
    form.reset();
    form.expense_date = new Date().toISOString().split('T')[0];
    showModal.value = true;
};

const closeModal = () => {
    showModal.value = false;
    form.reset();
    form.clearErrors();
};

const submitForm = () => {
    form.post(route('expenses.store'), {
        onSuccess: () => closeModal()
    });
};

const deleteExpense = (expense) => {
    if (confirm(`Hapus catatan pengeluaran "${expense.description}" sebesar Rp ${formatRupiah(expense.amount)}?`)) {
        router.delete(route('expenses.destroy', expense.id), { preserveScroll: true });
    }
};
</script>
