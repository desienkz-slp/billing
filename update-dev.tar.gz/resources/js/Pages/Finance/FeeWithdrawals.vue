<template>
    <AppLayout title="Pencairan Fee Mitra">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white">Pencairan Fee (Komisi)</h1>
            <p class="text-sm text-slate-500 dark:text-slate-400">Kelola dan catat pencairan fee untuk Sales dan Kolektor.</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div class="lg:col-span-1">
                <Card title="Filter Periode" class="h-full">
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Pilih Bulan</label>
                        <input type="month" v-model="filter.bulan" @change="applyFilter" class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
                    </div>
                    <div class="text-sm text-slate-500 dark:text-slate-400">
                        Menampilkan rekapitulasi fee (komisi) yang didapatkan oleh masing-masing user pada bulan yang dipilih.
                    </div>
                </Card>
            </div>

            <div class="lg:col-span-2">
                <Card title="Rekapitulasi Fee Belum Dicairkan" class="h-full">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                            <thead>
                                <tr>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Mitra</th>
                                    <th class="px-4 py-2 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Total Fee</th>
                                    <th class="px-4 py-2 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Telah Dicairkan</th>
                                    <th class="px-4 py-2 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Sisa / Belum Dicairkan</th>
                                    <th class="px-4 py-2 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                                <tr v-for="(fee, userId) in userFees" :key="userId" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                    <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">
                                        {{ fee.user ? fee.user.name : 'Unknown' }}
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-500 text-right">
                                        Rp {{ formatRupiah(fee.total) }}
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm text-green-600 dark:text-green-400 text-right">
                                        Rp {{ formatRupiah(fee.withdrawn) }}
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm font-bold text-red-600 dark:text-red-400 text-right">
                                        Rp {{ formatRupiah(fee.sisa) }}
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-center">
                                        <button v-if="fee.sisa > 0" @click="openWithdrawModal(userId, fee)" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 text-sm font-medium">
                                            Cairkan
                                        </button>
                                        <span v-else class="text-xs text-slate-400 italic">Lunas</span>
                                    </td>
                                </tr>
                                <tr v-if="Object.keys(userFees).length === 0">
                                    <td colspan="5" class="px-4 py-6 text-center text-slate-500 text-sm">Tidak ada data fee di bulan ini.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </Card>
            </div>
        </div>

        <Card title="Riwayat Pencairan Bulan Ini">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                    <thead class="bg-slate-50 dark:bg-slate-800/50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Tanggal</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Mitra Penerima</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Diproses Oleh</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Keterangan</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Nominal (Rp)</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                        <tr v-for="wd in withdrawals" :key="wd.id" class="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-900 dark:text-slate-300">
                                {{ new Date(wd.created_at).toLocaleString('id-ID') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">
                                {{ wd.user?.name }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                {{ wd.processor?.name }}
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-500">
                                {{ wd.notes || '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-slate-900 dark:text-white text-right">
                                Rp {{ formatRupiah(wd.amount) }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button @click="deleteWithdrawal(wd)" class="text-red-600 hover:text-red-900 dark:text-red-400">Batal</button>
                            </td>
                        </tr>
                        <tr v-if="withdrawals.length === 0">
                            <td colspan="6" class="px-6 py-8 text-center text-slate-500">Belum ada pencairan di bulan ini.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Card>

        <!-- Form Modal -->
        <Modal :show="showModal" @close="closeModal">
            <div class="p-6">
                <h2 class="text-lg font-medium text-slate-900 dark:text-white mb-4">
                    Pencairan Fee
                </h2>
                
                <div v-if="selectedUser" class="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg mb-6">
                    <div class="text-sm text-slate-600 dark:text-slate-400 mb-1">Mitra:</div>
                    <div class="font-bold text-lg text-slate-900 dark:text-white mb-3">{{ selectedUser.user?.name }}</div>
                    
                    <div class="flex justify-between border-t border-blue-200 dark:border-blue-800 pt-2 text-sm">
                        <span class="text-slate-600 dark:text-slate-400">Total Fee Bulan {{ filter.bulan }}</span>
                        <span class="font-semibold">Rp {{ formatRupiah(selectedUser.total) }}</span>
                    </div>
                    <div class="flex justify-between text-sm mt-1">
                        <span class="text-slate-600 dark:text-slate-400">Telah Dicairkan</span>
                        <span class="font-semibold text-green-600 dark:text-green-400">- Rp {{ formatRupiah(selectedUser.withdrawn) }}</span>
                    </div>
                    <div class="flex justify-between text-base font-bold border-t border-blue-200 dark:border-blue-800 pt-2 mt-2">
                        <span class="text-slate-800 dark:text-slate-200">Sisa Bisa Dicairkan</span>
                        <span class="text-red-600 dark:text-red-400">Rp {{ formatRupiah(selectedUser.sisa) }}</span>
                    </div>
                </div>

                <form @submit.prevent="submitForm">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Nominal Pencairan (Rp)</label>
                            <input type="number" v-model="form.amount" :max="selectedUser?.sisa" min="1" required
                                class="block w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" />
                            <div v-if="form.errors.amount" class="text-sm text-red-600 mt-1">{{ form.errors.amount }}</div>
                            <div class="text-xs text-slate-500 mt-1">Maksimal Rp {{ formatRupiah(selectedUser?.sisa) }}</div>
                        </div>

                        <Input label="Catatan Tambahan (Opsional)" v-model="form.notes" :error="form.errors.notes" placeholder="Contoh: Pencairan via Transfer Mandiri" />
                    </div>

                    <div class="mt-6 flex justify-end space-x-3">
                        <Button type="button" variant="secondary" @click="closeModal">Batal</Button>
                        <Button type="submit" :disabled="form.processing">Proses Pencairan</Button>
                    </div>
                </form>
            </div>
        </Modal>
    </AppLayout>
</template>

<script setup>
import { ref } from 'vue';
import { useForm, router } from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';
import Card from '@/Components/Card.vue';
import Button from '@/Components/Button.vue';
import Input from '@/Components/Input.vue';
import Modal from '@/Components/Modal.vue';

const props = defineProps({
    withdrawals: Array,
    userFees: Object,
    bulan: String
});

const filter = ref({
    bulan: props.bulan
});

const showModal = ref(false);
const selectedUserId = ref(null);
const selectedUser = ref(null);

const form = useForm({
    user_id: '',
    periode: '',
    amount: '',
    notes: '',
});

const formatRupiah = (number) => {
    return new Intl.NumberFormat('id-ID').format(number || 0);
};

const applyFilter = () => {
    router.get(route('fee_withdrawals.index'), { bulan: filter.value.bulan }, { preserveState: true });
};

const openWithdrawModal = (userId, feeData) => {
    selectedUserId.value = userId;
    selectedUser.value = feeData;
    
    form.reset();
    form.user_id = userId;
    form.periode = props.bulan;
    form.amount = feeData.sisa; // Default isi dengan sisa maksimal
    showModal.value = true;
};

const closeModal = () => {
    showModal.value = false;
    selectedUserId.value = null;
    selectedUser.value = null;
    form.reset();
    form.clearErrors();
};

const submitForm = () => {
    form.post(route('fee_withdrawals.store'), {
        onSuccess: () => closeModal()
    });
};

const deleteWithdrawal = (wd) => {
    if (confirm(`Batalkan pencairan Rp ${formatRupiah(wd.amount)} untuk ${wd.user?.name}? Dana akan dikembalikan ke saldo Fee.`)) {
        router.delete(route('fee_withdrawals.destroy', wd.id), { preserveScroll: true });
    }
};
</script>
